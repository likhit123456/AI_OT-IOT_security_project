# SCRAM: the complete project learning guide

Prepared from the local workspace on 1 November 2026. This is a reading and code-navigation guide, not a new experimental run. Numerical evaluation results are identified as saved evidence. The accompanying inventory records file sizes, source line counts and SHA-256 hashes for the exact snapshot.

## 1. How to use this book

Read chapters 2 through 10 first to rebuild your mental model. Then follow the file catalogue in chapter 19 while opening the source companion. The catalogue covers every Git-tracked file, in path order. Python entries include a symbol map with source locations; the separate Source Companion contains numbered source and a mechanically extracted explanation of each function's control structure. Source-derived notes are navigation aids, not a substitute for the conceptual explanations in this book.

The first file to understand is contracts.py, but the first file executed for the main application is live/__main__.py. There is no single 'last file': this is a set of persistent services, browser programs, training tools and experimental entry points. The primary runtime ends only when its loop is stopped. Files under experiments/ and training/ are separate programs, not successive steps in ordinary application startup.

Scope: all 298 tracked files are catalogued. All tracked, readable code and configuration are included in the source companion, including historical implementations. Large datasets and tokenizer/model tables are described by their structure rather than printing millions of values. Binary images, PCAPs and video are catalogued as assets. The generated Unity loader is included in the TXT source companion, but its minified implementation is omitted from the PDF to keep it usable. Local dependencies, Git objects, model weights and generated runtime files are counted separately in workspace-summary.json; they are not treated as project-authored code. The notebook's code cells are included separately.

## 2. What you built

SCRAM is an AI-supervised chemical-process simulation. A simulated reactor produces measurements; an AI or deterministic policy proposes operating targets; conventional control turns those targets into valve positions. Several independent checks constrain or reject commands before they reach the process. The application demonstrates why plausible AI output, anomaly detection, command authentication and physical safety are different responsibilities.

The four manipulated valves are feed 1, feed 2, purge and product. Opening feed valves adds reactants. Opening purge releases vapor and helps lower pressure. Opening product drains liquid inventory. These relationships explain the signs in the control equations and the cause-specific safety actions. Closing every valve is not a universal safe action: a pressure excursion needs a relief path, while low inventory needs the product outlet closed.

The main control room is live/ on port 8765. The reactor studio is sim_app/ on port 8770. Both can address the same simulator on port 55555, but the studio directly controls the simulator without SCRAM's Keel, provenance gate or L0 interlock. Studying them as interchangeable frontends would be a serious misunderstanding of this codebase.

The project includes three local language-model roles: scram-operator proposes setpoints, scram-observer evaluates proposal history, and scram-observer-v3 evaluates telemetry windows. A small CPU forest adds a fourth, non-language-model role: it corrects advisory telemetry classifications using process features. Model training and evaluation are separate from runtime control.

@figure architecture.png | Main runtime and trust boundaries. The browser requests actions; the engine owns control. The telemetry classification branch does not feed authority.

## 3. Repository geography and execution paths

contracts.py defines shared data. l3_brain/ owns policy and authority blending. monitor/ contains rule monitoring, model observers, governance and CPU telemetry inference. l1_regulator.py implements the current PI controller. enforcer/keel.py constrains commands using the safety channel. l0_plant/ connects to the simulator, verifies command origin and enforces trips.

live/ composes these pieces into a continuously running application. sim_app/ is the separate manual/rescue station. training/ produces datasets and models. model/ contains serving configuration, adapters' metadata, CPU forests and evaluation reports. experiments/ holds scenario runners and saved results. scripts/ contains reset, validation and collection utilities. tests/ captures intended behavior and regression cases.

simulation/ is inherited simulator source, remote-I/O bridges and visualization assets. packaging/ provides a Debian/systemd distribution path. reference/sim_cpp_unused/ is a shelved reactor variant. artifacts/ preserves evaluations, frozen candidate evidence and cleanup manifests. images/ contains inherited GRFICS screenshots; these are not screenshots of the current SCRAM control room.

There are four useful reading journeys: runtime (live -> L3 -> L1 -> Keel -> L0); a sensor reading (simulator -> PlantState -> observers -> UI); a model (recordings -> labels -> chat examples -> fine-tuning -> GGUF -> Ollama); and a regression (test case -> fake dependency -> assertion -> implementation).

## 4. Contracts, units and the two sensor views

PlantState is a frozen dataclass containing measured pressure, level, flows, compositions, actuator feedback, cost, interlock status, optional truth and a timestamp. Frozen dataclasses discourage accidental in-place mutation. as_dict() makes them convenient for JSON and logs. SupervisoryTargets contains pressure_sp, level_sp, production_rate_sp, a_comp_sp, authority and rationale. A None setpoint means hold that loop; it does not mean a zero target.

ControlCommand contains four absolute valve percentages plus seq and auth_tag. is_finite() rejects NaN and infinities. clamped() returns a copy restricted to 0..100, preserving the provenance fields. The check must precede clamping because ordinary min/max expressions can give misleading results with NaN. The signer must sign the final values after any downstream edits.

Units: pressure is kPa; inventory level and valve position are percent; flows are kmol/hour; measured A/B/C composition is a fraction from 0 to 1. The composition target is mol percent: 0.47 measured means 47.0 for a_comp_sp. L1's _a_pct() and the authority blend make this conversion explicitly. The ordinary Python control path uses engineering units; the legacy Modbus bridges perform 16-bit register scaling separately.

The deployed simulator interface supplies outputs (the independent simulated safety-channel view), measured (the faultable instrumentation view), and state (actuator feedback). PlantService._to_state() publishes measured fields and retains outputs in PlantState.truth. The name 'truth' is historical: the current implementation also deliberately uses it for L0 safety and Keel. The AI prompt and measured-only detectors must not consume it.

@figure signals.png | One physical process, two different observation paths. A fault in ordinary instrumentation can mislead the controller while the safety channel still observes a limit crossing.

The safety channel is independent by simulation assumption, not physically independent hardware. The detector may use truth to assign evaluation labels while still keeping truth out of model features. That distinction is how you evaluate a detector without leaking the answer into its input.

## 5. Startup and one complete control cycle

python -m live resolves live/__main__.py. main() parses port, brain selection, production limits, reset behavior, browser behavior and explicit Ollama configuration. plant_up() probes port 55555. If the simulator is unreachable, startup invokes docker compose up -d simulation and waits. An unavailable operator model causes a baseline fallback. Ordinary startup does not persistently reconfigure Ollama; --configure-ollama opts into that operation.

Engine.start() launches a control worker. _connect() optionally calls reset_and_settle(), creates a fresh provenance gate, starts PlantService with SafeHold, clears fault injections, constructs L1, Keel, rule monitors and Governor, loads an approved telemetry specialist, and selects the brain. Attaching with --no-reset skips a simulator restart but still clears sensor/actuator faults during connection; it is not a read-only attachment.

The engine uses a bounded action queue of 64 entries. HTTP threads validate and enqueue actions rather than sharing a plant socket freely. The control worker executes them. Shared snapshots are protected with a lock; stop uses a threading.Event. LLM calls run on background threads so a slow response does not block normal PI regulation. The loop has a nominal 0.05-second polling cadence, not a hard real-time scheduling guarantee.

During _cycle(), the brain receives the latest measured PlantState and emits authority-blended targets. BehaviorMonitor checks measurements and targets. SequentialMonitor scores the original pre-blend intent, preventing the authority blend itself from looking like a new staircase attack. The split observer receives both proposal history and measured telemetry paired with the preceding command.

Governor updates its applied authority ceiling from corroborated proposal-side evidence and sequential rules. L1 regulates the already-produced targets using actual elapsed time. Manual overrides replace selected L1 valve requests. Keel evaluates those requests against SisFrame. L1 then signs Keel's final command. PlantService audits readback, admits or rejects provenance, applies a normal or protective write, and returns the next PlantState.

The ordering matters: targets are computed before the current governor update, so updated authority generally affects subsequent targets. Telemetry is paired with the command that produced the sample, not the command about to be issued. After actuation, the engine records trips, gate events, trends, model decisions and recovery state for browser polling. Deliberate attack scenarios can inject a separate forged write or replace the final signed command to demonstrate failure boundaries.

@figure cycle.png | The normal cycle. A trip overrides upstream requests; signing occurs after Keel changes the valves.

Engine._run() distinguishes action errors from connection failures, reconnects as needed and maintains status. read() returns incremental histories and events using sequence cursors. run_id lets the browser detect a new engine session; stale measurements must not be displayed as fresh connected data. History is bounded to 3,600 samples at approximately two samples per second, about 30 minutes.

## 6. L3: policies, prompts, validation and authority

Policy is a small interface: decide(state) returns SupervisoryTargets. BaselineOperator is a deterministic fallback. LLMOperator supplies scheduling, cached results, parsing and failure behavior; OllamaOperator supplies the local HTTP request to /api/chat. make_policy() and the engine choose between implementations. Runtime model choice is different from whether a training checkpoint exists on disk: Ollama must have the requested model registered.

prompt_format.py is shared by training and serving. measured_dict() selects allowed fields and rounding, state_to_json() serializes the user turn, and system_prompt() supplies role, design targets and response contract. Sharing this code prevents a fine-tuned model from receiving a different input format at inference. A standing operator note is appended through the policy interface, and decision logs retain which note produced a response.

parse_llm_targets() extracts a JSON object, reads only recognized setpoint fields, rejects booleans and non-finite numeric values, treats missing/null setpoints as hold, and clamps finite values to Envelope. Pressure targets are 2400..2900 kPa, level 30..70%, production 60..180 kmol/h, and A composition 40..55%. Rationale is bounded. Extra keys, including invented valve commands, do not become actuations.

An inference failure becomes hold targets. This differs from startup fallback: if Ollama is unavailable at selection, the engine may select the baseline policy; a malformed response from an already-selected model is handled by that policy's hold behavior. The current Ollama operator normally refreshes about every five seconds while the fast control cycle reuses its cached decision.

AIOperator.step() saves last_intent before applying authority. Effective authority is min(operator slider, Keel budget, Governor applied ceiling). At A=1 the request is unchanged. At A=0 all setpoints become None. Between those extremes, each numeric target becomes current*(1-A) + requested*A. Example: measured pressure 2700, requested 2800 and A=0.25 yields a 2725 kPa target. Composition uses percent on both sides of the blend. Non-finite authority fails closed to zero.

Authority is permission to deviate, not a probability that the model is correct. Holding a valve is also not an emergency stop: an existing unsafe lineup can remain unsafe. Independent downstream protection is necessary even if the AI emits only holds.

## 7. L1: understand the controller mathematically

PI implements u = kp*error + integral. Each call conditionally integrates ki*error*dt and clamps u between its output limits. If the controller is saturated and the error would push farther into saturation, it stops accumulating integral. This is anti-windup: without it, a valve could remain pinned long after the measured process comes back toward target.

Pressure uses error measured-pressure minus target-pressure. Positive error opens purge. Its controller output range is -6..100. Negative output means purge is already closed, so a split-range trim raises the feeds up to 50% above their base requests to rebuild pressure. The purge valve itself never receives a negative position.

Level also uses measured minus target. A high measured level opens product and drains inventory. Production uses feedforward DESIGN_F1*production_target/100 plus a slow PI trim on desired minus measured product flow. While pressure is borrowing feed authority through split range, the production integrator is held to avoid fighting pressure recovery. Composition uses target A-percent minus measured A-percent to move feed 2.

The four gain pairs (kp, ki) are pressure (0.30, 0.003), level (4.0, 0.04), production (0.02, 0.002), and composition (1.5, 0.02). These gains belong to this simulator and its units. dt is clamped to 0..1 second to bound integral updates after a pause. Output values are clamped again in ControlCommand.

Bumpless transfer means matching controller memory to the currently applied valve position. PI.track(u,e) sets integral=u-kp*e. L1Regulator.bumpless() seeds all loops on connection/re-arm. A loop with a None target holds its associated actuator and marks itself held; _resume() seeds it when the target returns. This avoids a sudden command jump caused by old integral memory.

Worked example: pressure=2750 and target=2700 gives error=50. With integral=0.3926, the proportional-plus-integral request is approximately 15.3926% purge before the next integral update. This is an illustrative calculation of PI, not a recorded plant response. Keel and L0 can still change what is actually applied.

l1_stub.py remains for older experiments. It is not the current live controller, and saved results using the stub should not be attributed automatically to the new L1 regulator. The studio's sim_app.ai.regulate() is another separate controller with its own rescue policy.

## 8. Keel, provenance and the L0 safety interlock

Keel receives a proposed ControlCommand, measured state, trusted SisFrame, and explicit time. It maintains rolling safety-channel histories. It checks proximity to trip limits, least-squares pressure/level rates, projected time to trip, cumulative pressure rise or level loss, and persistent disagreement between measured and safety readings. A divergence finding costs authority but has severity zero; it is not itself used to choose a physical safe lineup.

Default soft pressure margin is 150 kPa inside the hard trip. Rate limits are 2 kPa/s pressure rise and 0.01 percentage-points/s level loss. The pressure rise budget is 150 kPa in 120 seconds; the level drop budget is 3 percentage points in 300 seconds. Rate estimates need multiple samples and sufficient span. These checks catch trajectories that can evade single-step limits.

Keel.step() updates authority, chooses the strongest hazard severity, blends selected valves toward a cause-specific lineup, limits ordinary valve slew, and returns Decision. Safety-directed moves are exempt from ordinary slew limits. Its own authority loses budget on physics evidence or provenance rejections and recovers after a clean period. Low authority sustained long enough sets divert. The live integration passes zero L2 suspicion to Keel; L2 operates through Governor instead. Older comments describing direct L2-to-Keel routing are historical.

EventLog appends canonical JSON bodies with the previous MAC and signs each body with HMAC-SHA256. Verification can detect modification and broken links within a supplied retained sequence. Because the deque is bounded and verification accepts its first previous-MAC anchor, this is not proof that an attacker did not truncate an entire prefix/suffix. Tamper-evident logging is not a durable externally anchored audit service.

CommandSigner increments seq and signs the four float values using exact float.hex representations. ProvenanceGate.admit() rejects non-finite, unsigned-in-strict-mode, stale/replayed or incorrectly tagged commands. Admitted commands become clamped last_good. A rejected command falls back to last_good; without a seeded fallback the service holds rather than applying an invalid request. Production live wiring uses the gate, although PlantService can be constructed with gate=None for legacy callers.

Readback audit detects a different issue: writes sent directly to the unauthenticated simulator bypass admit(). It compares actuator feedback and E-stop with expected state, allowing 0.5% valve tolerance. It records mismatches, and the normal following write reasserts control. This is polling-based detection and correction, not prevention or a strict timing guarantee during disconnects. A stolen signing key can authenticate an attacker command; the stolen-key scenario deliberately demonstrates that the safety interlock must still protect the process.

PlantService.read() translates a state and evaluates the safety channel. apply() audits provenance, chooses admitted/fallback commands, checks the latched safety state, performs a normal/protective write, then translates the response and evaluates safety again. A newly discovered post-write trip is therefore latched for the next protective actuation; the Python loop is not asynchronous hardware protection.

TripLimits defaults: pressure >=3000 kPa, level <=5% or >=95%. Reset requires finite pressure <=2800 and level within 15..85%. The live demo instead raises the low trip to 40% and low re-arm to 42% to make slow inventory attacks observable in a reasonable demonstration. --production-limits restores base thresholds.

SafetyInterlock preserves the first trip cause for diagnosis but continues evaluating secondary hazards. Missing or non-finite safety readings latch sensor-fault protection. A low-level trip closes product and holds other valve requests. Pressure/high-level trips use classic E-stop unless configured with SafeHold. The live engine supplies SafeHold: feeds go to 60% of design, purge regulates toward 2650 kPa and product toward 50% level. Pressure at or above 3050 escalates to latched E-stop.

Combined high pressure and low inventory shuts feeds, opens purge, and closes product. That combination matters because this simulator's E-stop opens both purge and product; blindly using E-stop on low inventory would drain more liquid. Sensor-fault protection takes precedence over this combined-hazard mode.

@figure safety.png | Protective action selection. First-cause diagnosis is retained, but secondary hazards can change protection.

The base reset API is explicit and checks the safety channel again. The live demo additionally attempts automatic re-arm after ten continuous seconds in the valid band, with at most three automatic re-arms in 600 seconds before lockout. Re-arm restores design valves, seeds controllers, clears stale monitoring evidence and initially caps AI authority at 0.5. Clearing faults, clearing a standing model note, resetting the interlock and restarting the simulator are four distinct actions.

## 9. Monitoring and governance

BehaviorMonitor observes measured bounds, implausibly fast changes, suspiciously stale signals and setpoint steps. A settling grace period suppresses stale-signal checks during expected connection/recovery behavior, while other checks remain. A frozen value is not automatically proof of an attack: a stable process may legitimately have nearly constant level.

SequentialMonitor examines the trajectory of requested setpoints. It keeps positive/negative cumulative sums per channel, same-direction run length, a small lexical screen of rationale text, and corroborating Keel event codes. Evidence decays with elapsed time. Reversal reduces opposite-direction evidence; reissuing an identical target does not count as another move. Its score is suspicion, not a protective command.

The split observer uses v2 for proposal checks and v3 for telemetry. Proposal fallback is rule-monitor-only, not v3, because the saved proposal replay found v3 unsuitable for this role. Telemetry can fall back from v3 to v2 and then no model verdict. Worker generation counters discard late results after reset. A shared in-flight gate limits concurrent observer inference. Stale evidence expires instead of holding authority indefinitely.

Proposal-side labels provenance_violation, rationale_mismatch and setpoint_drift can contribute suspicion. A model's 'provenance_violation' label is a judgment about proposal content; it is not the cryptographic verification performed by ProvenanceGate. Telemetry labels normal, excursion, sensor_fault and actuator_fault are advisory in this integration.

Governor requires repeated evidence: two consecutive qualifying samples from a monitor, with rule calls sampled roughly once per second. It maps corroborated suspicion to a piecewise ceiling and rate-limits applied authority downward at 0.25 per second and upward at 0.03 per second. Recovery additionally needs 15 clean seconds and intent near the design envelope. Observer evidence becomes stale after 30 seconds. Accumulated residual rule evidence can decay faster once the proposal returns to the envelope; new evidence still counts.

@figure governance.png | Actual static ceiling() mapping from monitor/governance.py. Applied authority follows this target with separate drop/recovery rates and recovery conditions.

At suspicion below 0.30 the target ceiling is 1.0; it falls toward 0.55 by 0.60 and toward 0.25 just below 0.90. At 0.90 or greater the floor is 0.15, or 0.10 for provenance_violation. Note the deliberate step at the final threshold. These are maximum permissions, and the human cap or Keel can impose a lower value.

## 10. CPU telemetry detector and release evidence

telemetry_classifier.py implements dependency-free forest inference. It validates the window, constructs features, checks feature count, walks every exported tree by comparing a feature with a threshold, averages leaf probabilities, and selects the highest-probability class. Its score is 1 minus the normal-class probability. A forest confidence is not a guarantee that its class is correct.

The old specialist only upgrades an otherwise normal LLM verdict to a sufficiently confident sensor/actuator finding. It preserves existing alarms. PhysicsDetector overrides that correction policy: its result can replace either a normal or abnormal parsed LLM verdict, while retaining the original as llm_label. The specialist is invoked only after a valid telemetry LLM response; it is not a standalone always-on safety detector when Ollama is absent.

physics_features.py compares measured valve positions with commanded positions, and measured flow with expected valve-flow relationships. Feed expectations are cv*position; purge/product expectations additionally use sqrt(max(pressure-100,0)). Rounding tolerance is subtracted before residuals are normalized, so ordinary two-decimal measurement formatting does not create fake faults.

It also estimates vapor inventory as pressure*(122-0.3*level)/(8.314*373), liquid inventory as 2.49*level, and checks aggregate/species balances over full, half and overlapping short windows. Rates convert seconds to hours to match kmol/hour. Flux intervals use adjacent-sample minima/maxima to allow legitimate steps between samples. Pressure slope and soft excursion indicators add hazard information. Scenario names, known fault labels and safety truth are not features.

approved_specialist() first tries approved_physics_detector(). policy.json must enable it, final-holdout-evaluation.json must report a passed gate, and SHA-256 digests for model, feature implementation, validation and final report must match. An enabled-but-modified release raises an error; it does not silently pretend to be approved. The engine reports the specialist unavailable. Explicitly absent/disabled physics policy allows the older specialist path to be considered.

The frozen final holdout contains 215 windows: 31 normal, 117 sensor faults, 47 actuator faults and 20 excursions. Saved evidence reports 200 correct (93.02%); sensor recall 105/117, actuator recall 44/47, and 31/31 normal classified correctly. A saved paired replay on identical windows compares the previous pipeline's 138/215 with the new pipeline's 200/215. Those are pipeline results; the LLM weights were not improved by this classifier change.

@figure evaluation.png | Saved final-holdout class recall, with sample counts. Data comes from model/telemetry-physics/final-holdout-evaluation.json; this documentation task did not rerun inference.

Remaining errors are meaningful: six frozen-level cases were missed, two analyzer-dropout cases were missed, and four purge-flow faults were called actuator faults. Zero false alarms in 31 normal windows does not establish a population false-alarm rate of zero. Some cases share base trajectories and some faults are synthetic. This evaluation does not validate industrial deployment.

## 11. HTTP, browser code and operator actions

live/server.py uses ThreadingHTTPServer from the standard library and binds to loopback. GET /api/state?h=...&e=... returns a snapshot and incremental histories/events. POST /api/action validates JSON, allowed action name, body size and arguments, then submits work to the engine. A successful submission is acceptance into the queue, not necessarily completion of a plant action. Static paths are resolved under live/static; GRFICS/Unity assets are proxied from the plant web service on port 80.

live/commands.py is the control-room chat router. Recognized valve commands become manual overrides, release phrases drop overrides, setpoint phrases become canonical instructions, and free text becomes a model note. A manual override still passes Keel, signing and L0. The operator LLM itself never chooses the direct override valve values.

live/static/index.html defines the page structure and element IDs. control-room.js owns application state, poll cursors, event filters, tabs, chat, action handlers, gauges and Canvas trends. renderInstruments() updates pressure/tank indicators; renderRecovery() explains interlock state; renderStack() shows layers; renderBrain()/renderObservers() show model evidence. chart()/spark()/draw() turn accumulated series into plots. A lost connection should affect status rather than quietly keep an old green snapshot.

telemetry-workspace.js adds signal selection, table/chart modes and a read-only exploration view of the same stream. CSS files separate base control-room layout, shared visual styling and workspace-specific presentation; inspect stylesheet order when tracing which rule wins. reactor.html embeds the Unity scene independently of the inherited dashboard. The renderer is a visualization consumer, not the controller of record.

sim_app/server.py uses FastAPI/Pydantic and a shared Plant object. It serializes socket operations and write-sensitive transitions, tracks current values/history, handles reset/reconnect, and exposes state, manipulation, natural-language command, rescue and stop endpoints. A rupture flag latches at the app's 3100 kPa threshold and resets with the plant. It mirrors a UI convention; the C++ simulator clamps pressure and does not implement an actual explosion state.

sim_app/static/app.js polls around every 0.5 seconds, creates valve controls/gauges, renders activity cards and charts, queues natural-language commands, and fits the embedded 3D view. JSDoc annotations and tsconfig.json support static checking without a frontend build step. index.html supplies the controls; style.css, nocturne.css and workspace.css provide the presentation.

The studio's parse_commands() calls stock qwen2.5:1.5b with a constrained action schema, bounds action count to eight, and then grounds each action in the user's real words. 'to 40' means absolute set; 'by 5' means relative adjustment. Direction words settle signs; unsupported/invented actuators and negated valve clauses are rejected. Mixed supported and unsupported clauses can report partial success. Unknown commands return 422, unavailable parsing 503, malformed input 400, and refused control actions 409 as appropriate.

Rescue is a separate approximately two-second model/control loop. It uses scram-operator targets and the studio's deterministic regulate() mapping. It finishes after three consecutive near-design decisions and restores the design lineup. Stop and E-stop are different: Stop AI relinquishes rescue; E-stop cancels rescue, blocks late AI writes and requires deliberate release. Generation/run identity and serialized writes protect against stop/restart races. Failed E-stop transmission remains pending and is reasserted on reconnect.

## 12. Simulator, protocols and deployment variants

docker-compose.yml uses the prebuilt fortiphyd/grfics-simulation image with pull_policy: missing. It does not build simulation/Dockerfile. Ports 80 and 55555 publish on 127.0.0.1. A bridge subnet gives the container 192.168.95.45 and NET_ADMIN permits its inherited interface setup. A read-only supervisord override starts the simulator and web services without the Modbus writers that would otherwise compete with SCRAM.

GrficsClient owns a TCP socket and a binary file wrapper. _txn() writes one JSON object plus newline, flushes, reads a complete response line and decodes JSON. read() sends request=read; write_inputs() sends request=write with data.inputs. Timeouts and disconnect errors propagate so the engine can reconnect. A transport client does not decide safety.

The bundled C++ main.cc supports up to 30 client slots using select(). A pending string buffer per client handles fragmented TCP frames and multiple newline-delimited frames in one read. Inputs are checked for finite valve percentages in 0..100 and boolean/0-or-1 E-stop. Oversized pending frames close a connection. send_frame() handles partial writes and interrupted sends. SCRAM_SIM_PORT supports isolated simulator checks on a temporary port.

TE_process.h declares process state, parameters and methods. TE::TE() initializes constants and calls steady_state(). steady_state() solves a three-variable linear system with LAPACKE to determine steady flows and valve positions. The corrected purge expression uses b[2]. update() applies E-stop or provided setpoints, computes elapsed wall-clock hours, calculates volume/pressure/flow/composition, advances species inventories using Euler integration, clamps outputs, and updates an economic cost. print_outputs() is diagnostic; get_state_json() serializes outputs/state.

Physics: total vapor moles are A+B+C; pressure follows NV*R*T/vapor_volume. Liquid D determines inventory level. Reaction consumes A and C and produces D. Feed 1 contains A, B and C, while feed 2 contributes A; inert B must leave through purge. The reaction law is kpar*(partial pressure A)^1.2*(partial pressure C)^ncpar. Flow coefficients and gas/volume constants are mirrored by the telemetry features, which is why changing the simulator can invalidate the detector.

Important source/runtime distinction: the bundled simulation/simulation/TE_process.cc serializes outputs and state but does not implement the deployed faultable measured channel. The prebuilt image, the local basic source, the historical reference variant, and the accelerated fault-enabled evaluation source under artifacts/accuracy-v2/simulator are different artifacts. Compiling the local basic source does not automatically provide the full interface expected by live/. Its isolated protocol tests do not establish full runtime equivalence.

The inherited Modbus device files bridge the JSON process to holding/input registers. feed1/feed2/purge/product handlers write valve setpoints from holding registers and publish scaled position/flow input registers; tank and analyzer publish corresponding measurements. modbusdevice.py owns async server setup and simulator transport helpers. remote_io.py/server_async.py preserve older pymodbus.server.async imports, which are invalid Python 3 syntax now that async is reserved. They are historical compatibility code, not current live entry points.

simulation/web_visualization includes UnityLoader.js, build metadata, templates, PHP data/version endpoints and an MP4. Generated loader code boots a prebuilt Unity application; original Unity scene/C# sources are not present in this tracked tree. data/index.php bridges HTTP to the simulator's JSON socket. The browser explosion effect is separate from physical state integration. The local frontend and the prebuilt image may ship different asset sets.

packaging/build-simulation-deb.sh builds a Debian package; DEBIAN/control supplies package metadata, postinst/prerm manage install/removal lifecycle, systemd units start simulator/Modbus/interface setup, nginx serves visualization, and vm-overlay.js adds VM-oriented presentation. This is an alternate deployment route, not part of python -m live startup.

@figure plant.png | Existing images/sim.png: inherited GRFICS 3D plant view. Included to orient you to the simulated process, not as a newly captured SCRAM screenshot.

## 13. Data collection, labels, fine-tuning and export

collect_states.py runs named simulator rollouts with a controlled target schedule or expert policy, samples measured state at 2 Hz, and retains truth_eval_only for scoring. Completed rollouts are appended atomically from temporary files; reruns can skip completed recordings. collect_observer_states.py adds fault recordings with the command actually sent beside each measured response, which is essential for actuator-fault examples.

expert_policy.py labels operator examples. It loads design targets from training/design_point.json and uses production TripLimits to back off near hazards, hold on unusable measurements/trips, or maintain design operation. This is imitation learning from a rule-based expert, not learning an unconstrained optimal control policy directly from reward.

build_dataset.py deduplicates states, separates contiguous 10-second blocks into train/validation, balances rare rules by limiting the design-hold share, and constructs system/user/assistant chat turns using prompt_format.py. A block split reduces immediate-neighbor leakage but is weaker than withholding entire independent operating scenarios. The code checks exact prompt overlap and train/serve formatting.

build_observer_dataset.py retains v2 proposal examples and creates v3 telemetry with longer windows, all flows and command/position pairs. It combines recorded faults with synthetic corruptions of real windows and holds out selected scenarios/channels/fault shapes. build_clean_observer_dataset.py later strengthens the split using whole recordings and exact deduplication, recording assignments/hashes in observer_clean/manifest.json. Original v2/v3 datasets remain historical evidence for their respective trained weights.

@figure training.png | Training and release lifecycle. Operator fine-tuning and telemetry forest training are separate paths with different labels and deployment artifacts.

train_local.py fine-tunes Qwen2.5-1.5B with 4-bit base loading and rank-16 LoRA adapters. Batch size one with gradient accumulation eight reduces GPU memory pressure. Gradient checkpointing trades computation for memory. The configured run uses one epoch, learning rate 2e-4 and response-only training. Training, evaluation and export are selectable stages. The export merges adapters to a temporary 16-bit model, converts it with llama.cpp and quantizes to GGUF q4_k_m for Ollama.

The notebook scram_observer_finetune.ipynb is the observer training route. Its cells include setup, dataset/format checks, training, evaluation and export; the source companion preserves code-cell order. It defaults to clean input data and a separate candidate destination. A notebook is executable state: re-running a later cell with stale earlier variables can differ from a clean top-to-bottom run.

Modelfile tells Ollama which GGUF to load and supplies model/template parameters. adapter_config.json describes LoRA/base-model configuration; tokenizer.json maps text pieces to token IDs; tokenizer_config.json and chat_template.jinja control tokenization/chat rendering. These are model infrastructure data, not custom process-control algorithms. GGUF and safetensors weights are local/ignored and not included in a normal Git checkout.

train_physics_telemetry.py constructs physical features, trains tree ensembles and selects using validation metrics, then exports numerical tree arrays to JSON. Training depends on numpy/scikit-learn; deployed inference does not. evaluate_physics_holdout.py verifies a frozen candidate and scores a sealed holdout against declared criteria. Editing the feature code or model without renewed evidence invalidates the release hashes. Reproduction scripts can overwrite default outputs, so study them before using the release directories as experiment destinations.

benchmark_command_parser.py performs non-actuating language-command replay. eval_ollama.py compares deployed operator behavior with labels and probes. benchmark_observer.py and benchmark_physics_pair.py preserve prompt hashes/raw responses to compare pipelines. They are evaluations, not hidden startup tasks. Saved metrics should always be read with the dataset, model identity, sampling protocol and exact scorer that produced them.

## 14. Experiments: what each family demonstrates

adversarial_policy.py scripts individually plausible target ramps. adversarial_eval.py compares no enforcement, measured-monitor-only and SIS interlock conditions under compromised instrumentation, then sweeps pressure thresholds. eval_plant.py provides research-only counterfactual paths; it is intentionally different from production PlantService and should not be used to infer that the live interlock has a bypass switch.

level_drift_eval.py studies a level transmitter drifting high while true inventory falls. level_frontier.py sweeps low-level trip thresholds and records preserved inventory margin versus time spent protected. The accelerated 40% demo threshold differs from the production 5% low limit. frontier_results.csv and level_frontier_results*.json are saved observations, not universal plant constants.

provenance_demo.py exercises unsigned, forged, replayed and direct-socket writes. capstone_demo.py combines command-origin attacks and level drift. llm_operator_demo.py swaps the brain among real Ollama and a clearly labeled scripted stand-in to show that enforcement should not depend on intelligence or honesty of the brain.

observer_v3_live.py, observer_split_live.py and observer_v3_proposal_replay.py test format parity, routing, model residency and proposal suitability. demo_rehearsal.py executes the demonstration sequence through Engine; safe_hold_tune.py explores recovery settings. Their JSON companions preserve historical runs. They commonly reset/write the simulator; reading these files does not require executing them.

## 15. Tests and verification strategy

The test suite is executable documentation. Unit tests construct PlantState/targets, fake clients and fake model responses, then assert invariants. This lets you learn a component without Docker or model weights. tests/test_interlock_truth.py is different: its two integration tests reset and manipulate a real running simulator, so the normal offline command excludes it.

test_safety_unit.py and test_quality_hardening.py cover latching, reset bands, sensor loss, combined hazards and races. test_provenance_gate.py tests tampering/replay/readback/NaN. test_keel.py covers rate/load-line/divergence/authority/slew/log behavior. test_l1_regulator.py covers directions, holding and bumpless transfer. test_governance.py and test_sequential_monitor.py explain corroboration, drift and recovery.

Observer format/dataset/wrapper tests check formatting parity, no truth leakage, command/sample pairing, invalid outputs, stale evidence and fallback. test_physics_detector.py verifies release hashes and advisory routing. Parser/studio tests cover action grounding, partial failures, E-stop, reset and concurrent rescue cancellation. Review/workspace regression tests cover previously found edge cases and session state.

frontend_smoke.cjs uses Playwright to exercise browser behavior with local test endpoints, including disconnected states and hostile markup. scripts/check_simulator.py launches an isolated compiled simulator on a temporary port and tests framing/input behavior. .github/workflows/quality.yml runs offline Python tests, JavaScript syntax checks, browser smoke checks and a Linux C++ compile with warnings treated as errors.

Commands recorded in the repository include python -m pytest -q --ignore=tests/test_interlock_truth.py and node tests/frontend_smoke.cjs after browser dependencies are installed. This documentation generation validates the documents and source coverage; it does not claim a fresh full application/test/inference run. Historical test counts in accuracy reports are historical evidence.

## 16. Relearning walkthroughs

Normal operation: begin with pressure around 2700 kPa, level around 44.2%, production around 100 kmol/h and A fraction near 0.47. The brain asks for design setpoints; L1 produces a small purge opening and normal feed/product lineup; Keel allows or slew-limits; the signed command passes the gate; no interlock trip exists. Observe that the UI displays both requested intent and downstream protection decisions.

Level-drift thought experiment: ordinary measured level drifts upward. The controller believes the vessel has too much liquid and opens product. Actual inventory falls. Measured-only detection can miss a sufficiently plausible drift, but Keel compares it with the independent channel and loses authority. If true level reaches the configured low trip, L0 closes product. When studying the trace, compare measured level, safety level, requested product command, actual product position and protection mode separately.

Forged-command thought experiment: an otherwise reasonable valve command has no valid HMAC. The gate rejects it even if pressure and level are safe. A valid signature with a reused sequence is also rejected. This proves origin/freshness protection, not physical safety. In contrast, a stolen-key command can pass admission and still be overridden by the interlock when the safety channel reaches a trip.

Slow-proposal attack: each pressure target step is below a one-step alarm threshold. SequentialMonitor accumulates same-direction intent and Governor reduces authority after corroboration. Because it examines pre-blend intent, the attack cannot disappear merely because governance has already damped the output. Keel independently watches physical trends; telemetry LLM labels do not decide the safety outcome.

Studio command: 'set feed 1 to 40% and close purge' goes through model parsing, clause grounding, ordered action execution and the studio's write lock. It does not go through the control-room command router, Keel or provenance gate. A subsequent 'save the reactor' starts Rescue. E-stop during inference cancels the run and prevents that late result from writing valves.

## 17. Misleading comments, historical code and practical boundaries

ARCHITECTURE.md describes early ownership and open items that no longer match current wiring: governance and real L1 now exist, composition conversion is implemented, Keel uses the safety channel, and secondary hazards can change protection while retaining first-cause diagnosis. Some module docstrings also describe older routing. Prefer the current engine and tested implementation when these disagree.

The code is a simulation control prototype, not a certified safety system. Network access to port 55555, signing-key integrity, service availability and the assumed independent safety channel define its trust boundary. Loopback publishing reduces exposure; it does not add authentication to the simulator protocol. A broken plant connection can stop corrective writes, and polling intervals are not hard deadlines.

Source presence does not imply execution: local Dockerfile, prebuilt image, historical reference simulator and evaluation fork are separate. Raw models and training environments can exist locally without being tracked. A hash-gated model cannot be edited casually without invalidating evidence. Cleaning artifacts or normalizing line endings can also invalidate hashes, which is why .gitattributes preserves evidence bytes.

When you next change code, follow the boundary: contract changes affect all layers; prompt changes affect datasets and serving; physical constants affect simulator/features/validation; control changes affect PI/Keel/tests; frontend changes affect DOM IDs, polling and browser tests. Keep the smaller tests closest to the changed contract in mind.

## 18. Glossary and a suggested reading schedule

Setpoint: desired process value. Actuator: device that changes the process, here a valve. PI: proportional plus integral feedback control. Anti-windup: prevent unusable integral buildup at saturation. Bumpless transfer: seed control state to avoid a jump when switching modes. SIS: the simulated independent safety-instrumented channel and protection policy. SCRAM: a protective trip. Hysteresis: different trip and reset thresholds to prevent chatter.

Provenance: command origin/authenticity. Replay: resubmitting an old authenticated command. HMAC: shared-secret message authentication code. CUSUM: cumulative evidence of sustained directional change. Authority: permission budget for AI deviation. GGUF: a model-serving weight format. LoRA: small trainable adapter matrices. QLoRA: low-bit base-model fine-tuning using adapters. Holdout: examples withheld from model selection. Leakage: information from evaluation entering training or prediction features.

Session one: contracts, startup and one cycle. Session two: L1, Keel, safety and provenance, with their unit tests. Session three: policy, observer formats, governance and model routing. Session four: frontend/API and studio differences. Session five: data collection, training, evaluation, simulator variants and packaging. After each session, explain one walkthrough aloud using the relevant source locations rather than memorizing class names.

## 19. Complete file-by-file catalogue

The following section is generated from the inspected snapshot. Every tracked path appears once as a file entry. Descriptions explain its role; Python symbols include line ranges so you can find the corresponding implementation in the source companion. Data schemas list top-level fields, not every repeated record or learned numerical parameter. Generated source maps are explicitly structural and do not override the current-runtime distinctions explained above.


### .gitattributes

Line-ending/LFS rules. JSON/JSONL evidence is kept byte-stable so integrity hashes survive checkout.

Snapshot: 721 bytes; 20 lines.

### .github/FUNDING.yml

Repository funding metadata displayed by GitHub.

Snapshot: 66 bytes; 4 lines.

### .github/ISSUE_TEMPLATE/bug_report.md

Contributor issue-report template used by GitHub, with no application runtime effect.

Snapshot: 1,045 bytes; 44 lines.

### .github/ISSUE_TEMPLATE/feature_request.md

Contributor issue-report template used by GitHub, with no application runtime effect.

Snapshot: 595 bytes; 20 lines.

### .github/workflows/quality.yml

CI definition: Python regressions, JS syntax/browser smoke and isolated Linux C++ compilation/protocol checks.

Snapshot: 1,207 bytes; 27 lines.

### .gitignore

Excludes local weights, environments, tools/caches and generated output from Git. Ignored local files are not missing project source.

Snapshot: 1,937 bytes; 80 lines.

### ACCURACY_IMPROVEMENTS.md

Later parser/physics-detector results, paired evaluation, release scope and remaining weaknesses.

Snapshot: 5,656 bytes; 46 lines.

### ACCURACY_REPORT.md

Earlier accuracy review and historical pipeline evidence; do not subtract scores on different datasets to claim improvement.

Snapshot: 4,338 bytes; 68 lines.

### ARCHITECTURE.md

Original design/trust discussion with historical open items. Read the corrections in this guide before treating it as a current implementation reference.

Snapshot: 12,854 bytes; 222 lines.

### CODE_OF_CONDUCT.md

Contributor/community conduct expectations; no runtime effect.

Snapshot: 5,225 bytes; 128 lines.

### DEMO_RUNBOOK.md

Operator demonstration sequence for the live engine and scenarios. Describes active plant manipulations.

Snapshot: 12,124 bytes; 160 lines.

### FRONTEND_REDESIGN.md

Frontend design rationale and interaction/layout notes for the implemented control-room/studio interfaces.

Snapshot: 3,787 bytes; 27 lines.

### LICENSE

GPL license text retained with the inherited GRFICS/TE source. This entry explains repository provenance, not legal advice.

Snapshot: 35,129 bytes; 674 lines.

### PROJECT_REVIEW.md

Historical repository review findings and priorities. Tests/current implementation determine which observations remain applicable.

Snapshot: 17,774 bytes; 138 lines.

### QUALITY_IMPROVEMENTS.md

Reliability fixes and evidence, including fault combinations, concurrency, provenance and stale-state handling.

Snapshot: 9,975 bytes; 177 lines.

### README.md

Current top-level startup, component map, model setup, verification and limitations entry point.

Snapshot: 6,644 bytes; 140 lines.

### README_GRFICS.md

Upstream/inherited GRFICS lab documentation and attribution, broader than the current plant-only SCRAM deployment.

Snapshot: 1,715 bytes; 37 lines.

### SECURITY.md

Project security reporting and scope documentation.

Snapshot: 2,777 bytes; 74 lines.

### artifacts/accuracy-scorecard.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 5,423 bytes; 193 lines.

Data structure: operator, proposal_observer_v2, telemetry_observer_v3, deployed_telemetry_with_specialist, standalone_telemetry_specialist, command_parser, deterministic_systems, limits.

### artifacts/accuracy-v2/improvement-scorecard.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 1,402 bytes; 52 lines.

Data structure: date, telemetry, parser, unchanged, limitations.

### artifacts/accuracy-v2/paired-final.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 176,034 bytes; 4,155 lines.

Data structure: model, n, results, baseline, physics.

### artifacts/accuracy-v2/paired-progress.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 142,072 bytes; 1 lines.

Data structure: {"type": "list", "length": 215}.

### artifacts/accuracy-v2/parser-baseline.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 23,343 bytes; 1,122 lines.

Data structure: {"type": "list", "length": 52}.

### artifacts/accuracy-v2/parser-before.py

Frozen parser implementation from before grounding corrections, preserved for baseline comparison. Current studio code is sim_app/ai.py.

Snapshot: 25,753 bytes; 469 lines.

Dependencies: import json; import re; import threading; import time; import urllib.request; from collections import deque; from typing import Callable, Optional; from contracts import PlantState, SupervisoryTargets; from l3_brain.policy import OllamaOperator; from l3_brain.prompt_format import DESIGN_POINT; from scripts.reset_plant import DESIGN_PURGE_VALVE_PCT.

Source documentation: AI operator for the clean sim. Two capabilities, no interlock or enforcer: 1. parse_command(text): the STOCK qwen2.5:1.5b (Ollama) turns plain English into one JSON action {action, valve, amount}, constrained by a JSON schema. A small grammar check then settles "to N" (absolute) vs "by N" (relative), which a 1.5B model mixes up; any correction is reported, never hidden. 2. Rescue: the TRAINED scram-operator (Ollama, via l3_brain.policy.OllamaOperator - same prompt format, parse, validate and envelope clamp it was trained for) runs closed-loop every ~2 s. It reads the measured state and emits setpoints; `regulate()` turns them into valve positions; the loop applies them and stops once pressure and level are back near the design point. regulate() is deliberately simple and directionally correct for this TE model: pressure above setpoint -> open purge, cut both feeds, open product a little at setpoint -> purge at its design opening (vents feed 1's inert B) pressure below setpoint -> pu...

- _direction (L88-92): Source docstring: +1 / -1 if the sentence only uses opening / closing words, 0 if it uses both or neither (e.g. "open the purge to lower the pressure": the goal is not the valve).

- _post (L95-98): Structural note: Returns json.loads(r.read()). Key operations: urllib.request.Request, urllib.request.urlopen, r.read.

- _check (L101-133): Source docstring: Validate one parsed action and settle what a 1.5B model mixes up, using the words of its own clause: "to/at N" = set, "by N" = adjust, and the sign of an adjust when the clause only uses opening or only closing words. Returns (action, valve, amount, corrections).

- _ask (L136-144): Structural note: Returns ((resp.get('message') or {}).get('content', ''), round(time.monotonic() - t0, 2)). Key operations: post.

- parse_command (L147-156): Source docstring: Plain English -> ONE action {action, valve, amount, model_output, corrections, latency_s}.

- _clause_for (L207-219): Source docstring: The words to grammar-check an action against: the model's clause if it is really part of the command, else the command segment that names this valve; with a single action, the whole command.

- parse_commands (L222-257): Source docstring: Plain English -> several actions, in order: {actions: [{clause, action, valve, amount, corrections}], model_output, latency_s}.

- _clamp (L274-275): Structural note: Returns max(0.0, min(100.0, v)).

- regulate (L278-297): Source docstring: Setpoints -> valve positions (absolute %). None = the model holds.

- plant_state (L300-310): Structural note: Returns PlantState(pressure=m.get('pressure', 0.0), level=m.get('liquid_level', 0.0), f1_flow=m.get('f1_f....

- Activity (L313-326): Source docstring: Bounded feed of what the AI did, read by the page.

- Activity.__init__ (L316-317): Structural note: Key operations: threading.Lock.

- Activity.add (L319-322): Structural note: Coordinates the statements shown in the source companion.

- Activity.since (L324-326): Structural note: Returns [x for x in self.items if x['id'] > i].

- Rescue (L329-469): Source docstring: Closed loop: trained model -> regulate() -> valves, every TICK_S. Each engagement gets its own stop event and run id, so a quick Stop -> Save cannot leave an old loop running beside the new one, and an old loop can never change the state of a newer one when it exits.

- Rescue.__init__ (L336-342): Structural note: Key operations: threading.Lock, threading.RLock.

- Rescue.start (L344-352): Structural note: Key operations: threading.Thread(target=self._run, args=(run_id, stop), name=f'ai-rescue-{run_id}', daemon=True).start, threading.Event, threading.Thread.

- Rescue.stop (L354-361): Structural note: Coordinates the statements shown in the source companion.

- Rescue._apply (L363-368): Structural note: Returns True; False. Key operations: self.plant.apply_valves.

- Rescue._finish (L370-376): Source docstring: End this run, unless it was already stopped or superseded by a newer run.

- Rescue._run (L378-469): Structural note: Key operations: regulate, self.plant.read, outcome.startswith, self._apply.

### artifacts/accuracy-v2/parser-corrected.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 23,379 bytes; 1,122 lines.

Data structure: {"type": "list", "length": 52}.

### artifacts/accuracy-v2/parser-holdout-manifest.json

Reproducibility/cleanup manifest: records file identity, split/collection provenance or prior housekeeping actions. It is evidence, not runtime code.

Snapshot: 153 bytes; 6 lines.

Data structure: n, seed, sha256, locked_before_parser_changes.

### artifacts/accuracy-v2/parser-holdout.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 8,491 bytes; 614 lines.

Data structure: {"type": "list", "length": 52}.

### artifacts/accuracy-v2/physics-final-frozen-candidate.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 525 bytes; 16 lines.

Data structure: model_sha256, features_sha256, validation_sha256, criteria, selection_used_holdout.

### artifacts/accuracy-v2/physics-first-frozen-model.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 417,063 bytes; 1 lines.

Data structure: feature_version, n_features, classes, trees, normal_below_confidence.

### artifacts/accuracy-v2/physics-first-holdout-evaluation.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 89,674 bytes; 2,625 lines.

Data structure: freeze, holdout_sha256, score, passed_release_gate, by_kind, predictions.

### artifacts/accuracy-v2/physics-first-validation.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 10,925 bytes; 385 lines.

Data structure: selection, fit_n, feature_count, validation_gate_passed, selected, trials, model_sha256, model_bytes.

### artifacts/accuracy-v2/physics-frozen-candidate.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 525 bytes; 16 lines.

Data structure: model_sha256, features_sha256, validation_sha256, criteria, selection_used_holdout.

### artifacts/accuracy-v2/physics-local-validation.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 11,176 bytes; 386 lines.

Data structure: selection, fit_n, native_training_windows_added, feature_count, validation_gate_passed, selected, trials, model_sha256, model_bytes.

### artifacts/accuracy-v2/physics-second-validation.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 10,744 bytes; 385 lines.

Data structure: selection, fit_n, feature_count, validation_gate_passed, selected, trials, model_sha256, model_bytes.

### artifacts/accuracy-v2/physics-third-validation.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 10,798 bytes; 385 lines.

Data structure: selection, fit_n, feature_count, validation_gate_passed, selected, trials, model_sha256, model_bytes.

### artifacts/accuracy-v2/simulator/TE_process.cc

Test-only accelerated/fault-enabled TE variant used for isolated holdout collection. It is neither the active prebuilt image nor the basic local simulator source.

Snapshot: 10,628 bytes; 314 lines.

Code landmarks: L11: TE::TE() {; L36: void TE::steady_state() {; L107: void TE::update(Json::Value inputs) {; L264: void TE::print_outputs() {; L286: Json::Value TE::get_state_json() {.

### artifacts/accuracy-v2/simulator/TE_process.h

Test-only accelerated/fault-enabled TE variant used for isolated holdout collection. It is neither the active prebuilt image nor the basic local simulator source.

Snapshot: 2,782 bytes; 75 lines.

### artifacts/accuracy-v2/telemetry-final-holdout.jsonl

Sealed telemetry evaluation windows with labels/provenance and measured input. Kept separate from training; the manifest binds the exact bytes.

Snapshot: 485,174 bytes; 215 lines.

Data structure: id, label, source, kind, window. Records: 215.

### artifacts/accuracy-v2/telemetry-final-holdout.manifest.json

Reproducibility/cleanup manifest: records file identity, split/collection provenance or prior housekeeping actions. It is evidence, not runtime code.

Snapshot: 1,731 bytes; 52 lines.

Data structure: seed, profile, time_scale, n, by_label, sha256, sources, fit_use, notes.

### artifacts/accuracy-v2/telemetry-holdout.jsonl

Sealed telemetry evaluation windows with labels/provenance and measured input. Kept separate from training; the manifest binds the exact bytes.

Snapshot: 503,000 bytes; 223 lines.

Data structure: id, label, source, kind, window. Records: 223.

### artifacts/accuracy-v2/telemetry-holdout.manifest.json

Reproducibility/cleanup manifest: records file identity, split/collection provenance or prior housekeeping actions. It is evidence, not runtime code.

Snapshot: 1,673 bytes; 50 lines.

Data structure: seed, time_scale, n, by_label, sha256, sources, fit_use, notes.

### artifacts/cleanup-manifest.json

Reproducibility/cleanup manifest: records file identity, split/collection provenance or prior housekeeping actions. It is evidence, not runtime code.

Snapshot: 1,714 bytes; 82 lines.

Data structure: {"type": "list", "length": 16}.

### artifacts/command-parser-accuracy.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 19,173 bytes; 805 lines.

Data structure: model, n, method, rows, exact_command_accuracy, raw_model_exact_accuracy, by_category.

### artifacts/fresh-observer-benchmark.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 23,602 bytes; 549 lines.

Data structure: dataset_sha256, seed, kind, rows, installed_models, baseline, hybrid.

### artifacts/ollama-quality-smoke.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 704 bytes; 32 lines.

Data structure: {"type": "list", "length": 2}.

### artifacts/permanent-cleanup-manifest.json

Reproducibility/cleanup manifest: records file identity, split/collection provenance or prior housekeeping actions. It is evidence, not runtime code.

Snapshot: 3,131 bytes; 162 lines.

Data structure: {"type": "list", "length": 32}.

### artifacts/preserved-models-manifest.json

Reproducibility/cleanup manifest: records file identity, split/collection provenance or prior housekeeping actions. It is evidence, not runtime code.

Snapshot: 1,134 bytes; 32 lines.

Data structure: {"type": "list", "length": 6}.

### artifacts/quality-summary.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 3,334 bytes; 128 lines.

Data structure: initial_cleanup_bytes, offline_tests_passed, warnings, browser_smoke, cpp_compile, isolated_cpp_protocol_checks, historical_replay, fresh_48_window_benchmark, original_llm_weights_retrained, telemetry_specialist_bytes, limits.

### artifacts/restricted-temp-cleanup-manifest.json

Reproducibility/cleanup manifest: records file identity, split/collection provenance or prior housekeeping actions. It is evidence, not runtime code.

Snapshot: 189 bytes; 12 lines.

Data structure: {"type": "list", "length": 2}.

### artifacts/review_inventory.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 721 bytes; 37 lines.

Data structure: tracked_files, by_directory, python_files_parsed, syntax_errors, dataset_overlap.

### artifacts/telemetry-evaluation-summary.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 8,002 bytes; binary asset.

### artifacts/verification-cleanup-manifest.json

Reproducibility/cleanup manifest: records file identity, split/collection provenance or prior housekeeping actions. It is evidence, not runtime code.

Snapshot: 1,880 bytes; 92 lines.

Data structure: {"type": "list", "length": 18}.

### contracts.py

The cross-layer data contract. PlantState carries observations, SupervisoryTargets carries intent and ControlCommand carries actuations plus authentication. Read this before following imports elsewhere.

Snapshot: 5,640 bytes; 140 lines.

Dependencies: import math; from dataclasses import dataclass, field, asdict, replace; from typing import Optional; import time.

- PlantState (L44-80): Source docstring: What L0 reports upward. This is the MEASURED view (what a PLC/HMI would actually see) plus actuator feedback. L3 and L2 consume this. `truth` carries the un-faulted physical values. L0 fills it so the Guardian (L2) can be scored against ground truth during development, but production detection logic must rely only on the measured fields - treat `truth` as a debug/eval channel, not a signal source.

- PlantState.as_dict (L79-80): Structural note: Returns asdict(self).

- SupervisoryTargets (L84-102): Source docstring: L3's output. The AI operator expresses INTENT as setpoints, never as valve positions. L1 is responsible for regulating the plant to these targets. `authority` is a 0..1 scalar the governance layer (teammate) writes to advertise how much freedom the brain currently has; L3 reads it so it can behave conservatively when de-authorized, but L1/governance is what actually enforces the clamp. Fields left None mean "no ch...

- SupervisoryTargets.as_dict (L101-102): Structural note: Returns asdict(self).

- ControlCommand (L106-140): Source docstring: L1's output and L0's input: absolute valve positions in percent [0,100]. L0 clamps these to the physical range and may override them entirely when the safety interlock is tripped.

- ControlCommand.is_finite (L126-128): Structural note: Returns all((math.isfinite(float(v)) for v in (self.f1_valve, self.f2_valve, self.purge_valve, self.produ....

- ControlCommand.clamped (L130-137): Source docstring: Clamp to [0, 100]. A non-finite value raises: NaN would otherwise clamp to 100% open (min(100, nan) is 100). Callers check is_finite().

- ControlCommand.as_dict (L139-140): Structural note: Returns asdict(self).

### docker-compose.yml

Active deployment configuration: prebuilt simulator image, loopback ports, fixed bridge IP, NET_ADMIN and simulator-only supervisor mount. No local Dockerfile build is invoked.

Snapshot: 1,508 bytes; 39 lines.

### docker/supervisord.sim-only.conf

Active supervisor override omitting Modbus writers so they do not overwrite SCRAM actuator commands.

Snapshot: 565 bytes; 13 lines.

### enforcer/INTEGRATION.md

Directory-specific setup, background or saved-model documentation. Read in context of the current source and the historical distinctions in this guide.

Snapshot: 2,770 bytes; 53 lines.

### enforcer/__init__.py

Package initializer. Establishes the import namespace; inspect any exports below. An empty initializer contains no control logic.

Snapshot: 0 bytes; 0 lines.

### enforcer/keel.py

Deterministic physical constraint layer, authority budget and chained event log. Uses SisFrame for hazard checks and measured values only for divergence evidence.

Snapshot: 18,568 bytes; 368 lines.

Dependencies: import hashlib; import hmac; import json; import math; from collections import deque; from dataclasses import dataclass, field, replace; from typing import Deque, Dict, List, Optional, Tuple; from contracts import ControlCommand, PlantState; from l0_plant.safety import TripLimits.

- KeelLimits (L54-85): Structural note: Class (no explicit base class). Declared data: trip, pressure_margin_kpa, level_margin_pct, pressure_rate_max, level_rate_max, rate_window_s, rate_min_span_s, horizon_s, window_s, pressure_rise_budget_kpa, level_window_s, level_drop_budget_pct, pressure_div_kpa, level_div_pct, div_cycles, slew_max_pct_per_s, loss_per_s, gate_reject_loss, recover_per_s, recover_after_clean_s, l2_floor, divert_below, divert_hold_s.

- SisFrame (L89-101): Source docstring: The independent safety-channel reading (PlantState.truth). Trusted-only.

- SisFrame.from_state (L95-98): Structural note: Returns SisFrame(pressure=float(tr.get('pressure', math.nan)), level=float(tr.get('liquid_level', math.na....

- SisFrame.valid (L100-101): Structural note: Returns math.isfinite(self.pressure) and math.isfinite(self.level).

- Reason (L105-109): Structural note: Class (no explicit base class). Declared data: code, hazard, severity, detail.

- Decision (L113-118): Structural note: Class (no explicit base class). Declared data: verdict, command, authority, severity, reasons.

- EventLog (L122-150): Source docstring: Append-only, hash-chained, HMAC-tagged. verify() detects edit/delete/reorder.

- EventLog.__init__ (L125-127): Structural note: Updates (self._key, self._prev, self._n).

- EventLog.append (L129-137): Structural note: Returns ev.

- EventLog.verify (L140-150): Structural note: Returns True; False.

- _ramp (L154-158): Source docstring: 0 at/below lo, 1 at/above hi, linear between.

- Keel (L161-368): Structural note: Class (no explicit base class). Groups related methods/state.

- Keel.__init__ (L162-174): Structural note: Updates self.lim, self.log, self._div_n, self._A, self.divert.

- Keel.authority (L177-179): Source docstring: Plug into AIOperator(authority_fn=keel.authority).

- Keel.note_gate_rejection (L181-185): Source docstring: Call when ProvenanceGate rejects a command (impulse authority loss).

- Keel.rearm (L187-201): Source docstring: Operator re-armed the SIS (a deliberate, trusted action): start again from the plant's current valves with full authority. If a real hazard is still present the next step() re-clamps, so this never skips a check.

- Keel.step (L203-232): Structural note: Returns d. Key operations: self._evaluate.

- Keel._evaluate (L235-291): Structural note: Returns out; [Reason('sis_invalid', 'pressure_high', 1.0, f'SIS reading invalid {sis}')].

- Keel._update_authority (L294-311): Structural note: Updates lim, rates, loss, l2_loss.

- Keel._update_divert (L313-320): Structural note: Coordinates the statements shown in the source companion.

- Keel.safe_lineup (L324-330): Source docstring: Cause-specific safe valves, mirroring SafetyInterlock.safe_state_inputs().

- Keel._toward_safe (L332-334): Structural note: Returns replace(cmd, **{v: getattr(cmd, v) + sev * (tgt - getattr(cmd, v)) for v, tgt in safe.items()}).

- Keel._slew_limit (L336-349): Source docstring: Authority scales how far a valve may move per cycle. Valves that the active hazard is driving toward the safe lineup (`exempt`) are not throttled.

- Keel._push (L353-356): Structural note: Coordinates the statements shown in the source companion.

- Keel._rate (L358-368): Source docstring: Least-squares slope over the last rate_window_s (robust to sensor noise, unlike an endpoint difference).

### experiments/__init__.py

Package initializer. Establishes the import namespace; inspect any exports below. An empty initializer contains no control logic.

Snapshot: 0 bytes; 0 lines.

### experiments/adversarial_eval.py

Red-team evaluation: does SCRAM's SIS-grounded interlock survive a combined attack that a behavior-only monitor cannot - a scripted, individually-legal adversarial setpoint sequence (experiments/adversarial_policy.py) PLUS a frozen pressure sensor (the simulator's own native fault interface, l0_plant/fault_injection.py), reset to the designed operating point before every run for reproducibility (scripts/reset_plant.py). Calibration (see scratchpad calib*.py during development, same container): * the simulator's physics run on WALL-CLOCK time, not request count - with feeds pinned open and purge/product pinned shut, truth pressure climbs at ~3.7-3.8 kPa/s regardless of poll rate. * the model hard-clamps truth pressure at 3200 kPa (confirmed empirically by driving it there with no enforcer and watching it saturate). * under e_stop (forced-safe), truth pressure falls at roughly 15-17 kPa/s; level barely moves, so re-arm eligibility (pressure back under the re-arm band) typically comes within ~10-15s of a trip in this scenario. Three conditions, same scenario, same reset point: (a) no... Saved result files in the same directory describe particular historical runs.

Snapshot: 14,323 bytes; 330 lines.

Dependencies: import argparse; import csv; import sys; import time; from dataclasses import dataclass; from pathlib import Path; from typing import List, Optional; from l0_plant import fault_injection as fi; from l0_plant.safety import TripLimits; from l1_stub import L1ControlStub; from monitor.behavior_monitor import BehaviorMonitor; from scripts.reset_plant import reset_and_settle; from experiments.adversarial_policy import AdversarialRamp; from experiments.eval_plant import EvalPlant.

- RunResult (L76-90): Structural note: Class (no explicit base class). Declared data: name, enforce, used_monitor, cycles_run, wall_s, peak_truth_pressure, tripped, wall_s_of_trip, rearmed, wall_s_forced_safe, monitor_ever_flagged, monitor_flag_count, monitor_sample_flags, trace.

- _setup (L94-107): Source docstring: Reset to the designed operating point, clear faults, freeze the pressure sensor, and hand back a ready-to-run (plant, policy, l1).

- run_condition (L110-225): Source docstring: Lightly paced (~20 Hz, POLL_S): the simulator's physics runs on wall-clock time, not request count (confirmed empirically - see module docstring), so a modest pace keeps the request rate sane without slowing anything that actually matters - the L1 PI loops still saturate the valves within a few seconds of wall time either way, and everything that governs this run (trip detection, the re-arm wait, the cutoffs below...

- run_three_way_comparison (L228-243): Structural note: Returns results.

- run_frontier_sweep (L246-306): Structural note: Returns out_csv. Key operations: open, csv.DictWriter, writer.writeheader, writer.writerow.

- main (L309-326): Structural note: Returns 0.

### experiments/adversarial_policy.py

Scripted "adversarial" L3 policy for the red-team evaluation (experiments/adversarial_eval.py) only - this is not a real L3 policy and is not wired into run_demo.py. It issues a smoothly ramped pressure/production setpoint sequence. Each individual request is unremarkable on its own - it never asks for anything above the monitor's own legal ceiling (monitor.behavior_monitor.MonitorLimits .pressure_max_kpa) and never jumps by more than a plausible step per cycle. It stands in for an operator (human or AI) that is simply pushing too hard, not for a compromised/malicious L3 - the point of the evaluation is that this "merely too aggressive, but individually legal" ask, combined with a frozen pressure sensor, is already enough to blind a behavior-only monitor and drive the plant toward the hard limit, with nothing unusual for such a monitor to catch anywhere in the request stream. Saved result files in the same directory describe particular historical runs.

Snapshot: 2,063 bytes; 46 lines.

Dependencies: from contracts import PlantState, SupervisoryTargets.

- AdversarialRamp (L23-46): Structural note: Class (no explicit base class). Groups related methods/state.

- AdversarialRamp.__init__ (L24-33): Structural note: Updates self.start_kpa, self.plateau_kpa, self.ramp_cycles, self.production_target, self.a_comp_target, self.level_target, self._k.

- AdversarialRamp.decide (L35-46): Structural note: Returns SupervisoryTargets(pressure_sp=pressure_sp, level_sp=self.level_target, production_rate_sp=self.p....

### experiments/capstone_demo.py

Capstone safety validation of the full two-ground enforcer: both attack channels at once, against the live plant, one timeline. Ground 1 - command-origin integrity (l0_plant/provenance_gate.py): forged / unsigned / replayed commands injected at the enforcer by a "compromised agent" are rejected at admission and never reach the plant (last-good is re-asserted). Ground 2 - physics (l0_plant/safety.py): the basic-control level transmitter drifts high (the simulator's NATIVE drift fault), so the measured level looks fine while the true level falls; the SIS interlock, reading the independent safety channel, trips on true physics, closes product, and the level recovers to the re-arm band. The production path is used as-is: PlantService(gate=..., limits=...) with a signing L1. The only test-only knob is the 40% low-level trip (physics caps the drain at ~0.013 %/s; see level_drift_eval.py) - the production default is 5%. Reset to the operating point first. Results: experiments/capstone_results.json. Usage: python -m experiments.capstone_demo Saved result files in the same directory describe particular historical runs.

Snapshot: 8,032 bytes; 176 lines.

Dependencies: import json; import sys; import time; from dataclasses import replace; from pathlib import Path; from typing import Optional; from contracts import ControlCommand; from l0_plant import fault_injection as fi; from l0_plant.plant_service import PlantService; from l0_plant.provenance_gate import CommandSigner, ProvenanceGate; from l1_stub import L1ControlStub; from scripts.reset_plant import reset_and_settle; from experiments.level_drift_eval import DRIFT_RATE_PCT_PER_HR, SIS_LIMITS, decide.

- main (L51-172): Source docstring: brain: optional AIOperator-like object with .step(state) -> SupervisoryTargets; default None uses the fixed legal operator ask (level_drift_eval.decide).

- main.new_gate_events (L75-81): Structural note: Returns new.

- main.log (L83-85): Structural note: Coordinates the statements shown in the source companion.

### experiments/capstone_llm_results.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 100,552 bytes; 5,366 lines.

Data structure: summary, events, timeline.

### experiments/capstone_results.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 90,552 bytes; 4,828 lines.

Data structure: summary, events, timeline.

### experiments/capstone_trained_results.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 120,690 bytes; 6,442 lines.

Data structure: summary, events, timeline.

### experiments/demo_rehearsal.py

Dry run of DEMO_RUNBOOK.md on the live engine (same Engine the control room drives), with the same actions in the same order, recording what the audience would see at each step. python experiments/demo_rehearsal.py [--from N] [--out FILE] (default out: experiments/demo_rehearsal_results.json) Steps (DEMO_RUNBOOK.md): 1 clean -> 2 forged commands -> 3 operator injection -> 4 product valve fault -> 5 level-sensor drift (Keel catches the measured/safety-channel divergence) -> 6 stolen key (SIS trips on the true pressure) -> re-arm. --from N starts at step N. Saved result files in the same directory describe particular historical runs.

Snapshot: 4,544 bytes; 98 lines.

Dependencies: import argparse; import json; import sys; import time; from live.engine import Engine.

- p (L28-29): Structural note: Coordinates the statements shown in the source companion.

- snap (L32-40): Structural note: Returns {'t': s['t'], 'authority_brain': round(min(eng.authority, s['keel']['authority'], g.get('applied'....

- step (L43-69): Structural note: Returns rec. Key operations: open.

### experiments/demo_rehearsal_results.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 429,707 bytes; 20,182 lines.

Data structure: steps.

### experiments/demo_rehearsal_results_part2.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 304,546 bytes; 13,450 lines.

Data structure: steps.

### experiments/eval_plant.py

Research-only plant wrapper for the red-team evaluation harness (experiments/adversarial_eval.py). This is NOT the production L0 service. l0_plant/plant_service.py always enforces its interlock and has no bypass - that's intentional and this file does not change it. EvalPlant exists only so the evaluation can run its two counterfactual baseline conditions ("no enforcer" and "behavior-monitor-only") without a protective action in the loop, while still privately running the exact same SIS-grounded trip logic (l0_plant.safety.SafetyInterlock, evaluated against outputs/truth, never measured) every cycle for shadow scoring - so even the un-enforced runs can report "the real interlock would have tripped here." enforce=True reproduces PlantService.apply's behavior exactly (same class, same force-safe-via-e_stop action). Saved result files in the same directory describe particular historical runs.

Snapshot: 3,926 bytes; 91 lines.

Dependencies: from typing import Optional; from contracts import PlantState, ControlCommand; from l0_plant.grfics_client import GrficsClient; from l0_plant.safety import SafetyInterlock, TripLimits.

- EvalPlant (L26-91): Structural note: Class (no explicit base class). Groups related methods/state.

- EvalPlant.__init__ (L27-31): Structural note: Updates self.client, self.safety, self.enforce.

- EvalPlant.start (L33-35): Structural note: Returns self.

- EvalPlant.stop (L37-38): Structural note: Coordinates the statements shown in the source companion.

- EvalPlant._to_state (L40-67): Structural note: Returns PlantState(pressure=m.get('pressure', 0.0), level=m.get('liquid_level', 0.0), f1_flow=m.get('f1_f.... Key operations: self.safety.evaluate.

- EvalPlant.read (L69-70): Structural note: Returns self._to_state(self.client.read()). Key operations: self.client.read.

- EvalPlant.apply (L72-86): Structural note: Returns self._to_state(raw). Key operations: self.client.write_inputs.

- EvalPlant.reset_interlock (L88-91): Structural note: Returns self.safety.reset(o.get('pressure', 0.0), o.get('liquid_level', 0.0)). Key operations: self.client.read, self.safety.reset.

### experiments/frontier_results.csv

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 671 bytes; 7 lines.

### experiments/level_drift_eval.py

Instrumentation-fault test: SIS low-level interlock vs. a high-drifting basic-control-system LEVEL transmitter. Scenario -------- The operator asks for a lower, perfectly legal level (level_sp = 30%). The basic-control level transmitter (`tank_level`, the `measured` view) is put into the simulator's NATIVE drift mode, which biases `measured` upward. L1 regulates on `measured`, so it sees a level that is high / in-band, keeps the product valve open, and the TRUE level (the independent safety-grade channel, `outputs`) keeps falling toward the 5% low-level safety setpoint. Expected: (a) a measured-only monitor (band / rate / setpoint-legality / staleness) registers nothing: measured level moves plausibly and stays in-band. (b) the SIS interlock, reading the safety-grade channel, trips at 5%. Only the simulator's native fault interface is used (l0_plant/fault_injection .drift on `tank_level`); there is no signal-corruption code here. The plant is reset to its designed operating point before every run. Physics notes (calibrated against the live container, see ARCHITECTURE.md): * the si... Saved result files in the same directory describe particular historical runs.

Snapshot: 11,451 bytes; 264 lines.

Dependencies: import argparse; import json; import sys; import time; from dataclasses import dataclass, asdict; from pathlib import Path; from typing import List, Optional; from contracts import PlantState, SupervisoryTargets; from l0_plant import fault_injection as fi; from l1_stub import L1ControlStub; from l0_plant.safety import TripLimits; from monitor.behavior_monitor import BehaviorMonitor, MonitorLimits; from scripts.reset_plant import reset_and_settle; from experiments.eval_plant import EvalPlant.

- decide (L71-78): Source docstring: Legal, steady operator ask: hold pressure, reduce level to 30%, hold feeds (production/comp = None -> L1 freezes feed valves; the stub's production loop would otherwise close feed 1 and let pressure sag, slowing the drain).

- RunResult (L82-105): Structural note: Class (no explicit base class). Declared data: name, enforce, used_monitor, wall_s, min_truth_level, final_truth_level, sis_tripped, wall_s_of_trip, truth_level_at_trip, measured_level_at_trip, measured_level_min, measured_level_max, max_pressure_truth, monitor_flagged, monitor_flag_count, monitor_sample_flags, trace, level_stale_evaluated, level_stale_flagged, min_truth_after_trip, rearmed, wall_s_to_rearm, fault.

- run_condition (L108-210): Structural note: Returns res. Key operations: reset_and_settle, EvalPlant(enforce=enforce, limits=SIS_LIMITS).start, plant.read, l1.regulate, plant.apply, plant.safety.can_reset, plant.reset_interlock.

- main (L220-260): Structural note: Returns 0. Key operations: out.write_text, out.read_text.

### experiments/level_drift_results.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 13,809 bytes; 728 lines.

Data structure: no_enforcer, monitor_only, sis_interlock.

### experiments/level_frontier.py

Low-level trip-threshold sweep under a persistent native drift fault on the basic-control level transmitter: damage prevented vs. throughput lost. Under the persistent fault, L1 regulates on a transmitter that reads high, so after every SIS trip -> product closed -> level recovers -> re-arm, L1 reopens the product valve and drains the vessel back to the trip point. The SIS thus cycles trip -> re-arm -> re-trip, and the fraction of time spent in the safed (tripped) state is the throughput given up. Per threshold (reset to the operating point first, native fault only): * low-level trip = threshold, re-arm = threshold + 2 (same hysteresis as the 40/42 run in level_drift_eval.py); the behaviour monitor's soft low limit is threshold + 2, so it tracks just above the trip it is being compared to. * the run continues until WINDOW_S seconds after the FIRST trip (an equal limit-cycle window for every threshold; time before the first trip is the approach drain and differs by threshold, so it is reported separately). * damage prevented = threshold - HAZARD_FLOOR_PCT (level margin preserved ab... Saved result files in the same directory describe particular historical runs.

Snapshot: 7,160 bytes; 170 lines.

Dependencies: import argparse; import json; import sys; import time; from pathlib import Path; from typing import List, Optional; from l0_plant import fault_injection as fi; from l0_plant.safety import TripLimits; from l1_stub import L1ControlStub; from monitor.behavior_monitor import BehaviorMonitor, MonitorLimits; from scripts.reset_plant import reset_and_settle; from experiments.eval_plant import EvalPlant; from experiments.level_drift_eval import DRIFT_RATE_PCT_PER_HR, decide.

- run_threshold (L56-148): Structural note: Returns row. Key operations: reset_and_settle, EvalPlant(enforce=True, limits=limits).start, plant.read, l1.regulate, plant.apply, plant.safety.can_reset, plant.reset_interlock.

- main (L151-166): Structural note: Returns 0. Key operations: OUT.write_text, OUT.read_text.

### experiments/level_frontier_results.40pct.bak.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 491 bytes; 19 lines.

Data structure: {"type": "list", "length": 1}.

### experiments/level_frontier_results.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 150,478 bytes; 9,122 lines.

Data structure: {"type": "list", "length": 2}.

### experiments/level_monitor_controls.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 3,062 bytes; 108 lines.

Data structure: frozen, none.

### experiments/llm_operator_demo.py

LLM operator demo: (1) closed loop from the operating point under normal operation; (2) the capstone attack (forged commands + drifting level transmitter) with the LLM operator as the brain. Model source (--brain, default auto): * ollama - the operator model fine-tuned in this repo (training/ -> model/ scram-operator-gguf), served locally by Ollama (l3_brain.policy.OllamaOperator). Also selected by SCRAM_OPERATOR=ollama. * auto - ollama if SCRAM_OPERATOR=ollama and it is up, else the scripted stand-in. * scripted - (or the auto fallback) a clearly-labelled SCRIPTED STAND-IN with the same `client.messages.create` interface is used. It is not a language model: it returns canned JSON (plus injected glitches - unparseable text and out-of-envelope values) so the plumbing, the validator/clamp, the hold-fallback and the enforcer can be exercised end to end. The thesis under test: the enforcer's guarantee (provenance gate + SIS interlock) does not depend on what the brain is. Each model decision is logged with what the brain SAW (measured level) next to the truth (eval-only), so a fooled ... Saved result files in the same directory describe particular historical runs.

Snapshot: 8,521 bytes; 188 lines.

Dependencies: import argparse; import json; import os; import time; from pathlib import Path; from types import SimpleNamespace; from l0_plant.plant_service import PlantService; from l0_plant.provenance_gate import CommandSigner, ProvenanceGate; from l1_stub import L1ControlStub; from l3_brain.operator import AIOperator; from l3_brain.policy import Envelope, LLMOperator, OllamaOperator, ollama_available; from scripts.reset_plant import reset_and_settle; from experiments import capstone_demo.

- ScriptedStandIn (L51-72): Source docstring: NOT a language model. Canned replies with injected failure modes.

- ScriptedStandIn.__init__ (L54-55): Structural note: Updates (self.mode, self.calls, self.messages).

- ScriptedStandIn.create (L57-72): Structural note: Returns SimpleNamespace(stop_reason='end_turn', content=[SimpleNamespace(type='text', text=text)]).

- WatchedBrain (L78-104): Source docstring: AIOperator wrapper: when the model returns a new decision, record what it saw (measured) beside the truth (eval-only; the brain never reads it).

- WatchedBrain.__init__ (L82-84): Structural note: Updates (self.brain, self.op, self.decisions, self._seen), self._asked.

- WatchedBrain.step (L86-104): Structural note: Returns targets.

- make_operator (L107-121): Structural note: Returns (WatchedBrain(AIOperator(policy=op), op), op, source).

- part1 (L124-156): Structural note: Returns res. Key operations: reset_and_settle, PlantService(gate=gate).start, svc.read, CommandSigner, svc.apply, signer.sign, l1.regulate.

- part2 (L159-166): Structural note: Returns {'source': source, 'model_calls': op.calls, 'summary': summary, 'decisions': brain.decisions}.

- main (L169-184): Structural note: Returns 0. Key operations: res.write_text.

### experiments/llm_operator_demo_results.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 9,348 bytes; 362 lines.

Data structure: part1, part2.

### experiments/observer_split_live.py

Split-serving live check (python experiments/observer_split_live.py): proposals on v2 (feeds authority), telemetry on v3 (display only), operator brain on Ollama too - three models resident. Valve-fault phases (product cv, product stuck), then a short operator injection. Audits every v3 telemetry prompt against the parity gate and every observer verdict handed to governance; samples peak VRAM, the resident model set (/api/ps) and the control-loop cycle time. Saved result files in the same directory describe particular historical runs.

Snapshot: 8,470 bytes; 170 lines.

Dependencies: import json, sys, time; from collections import Counter; from test_observer_v3_format import rebuild, telemetry_key_order; from live.engine import Engine; import subprocess, threading, urllib.request.

- _sys_sampler (L17-38): Structural note: Key operations: urllib.request.urlopen, json.loads(r.read()).get, r.read.

- wrap_gov (L47-57): Structural note: Returns orig(t, rule_score, rule_source, obs_verdict, obs_suspicion, intent).

- wrap_gov.upd (L52-55): Structural note: Returns orig(t, rule_score, rule_source, obs_verdict, obs_suspicion, intent).

- p (L60-61): Structural note: Coordinates the statements shown in the source companion.

- tick (L64-101): Structural note: Updates o, g.

- phase (L104-129): Structural note: Returns rec. Key operations: save.

- save (L132-144): Structural note: Key operations: open.

### experiments/observer_split_live_results.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 341,747 bytes; 8,093 lines.

Data structure: phases, sample_input, routing, audit, system, observer_model.

### experiments/observer_v3_live.py

Phase 4b live sanity set (python experiments/observer_v3_live.py), in-process on live.engine.Engine Audits every telemetry prompt against the v3 parity gate and every observer verdict handed to governance. Writes JSON results to argv[1] (default: experiments/observer_v3_live_results.json). Saved result files in the same directory describe particular historical runs.

Snapshot: 5,659 bytes; 131 lines.

Dependencies: import json, sys, time; from collections import Counter; from test_observer_v3_format import rebuild, telemetry_key_order; from live.engine import Engine.

- wrap_gov (L19-29): Structural note: Returns orig(t, rule_score, rule_source, obs_verdict, obs_suspicion, intent).

- wrap_gov.upd (L24-27): Structural note: Returns orig(t, rule_score, rule_source, obs_verdict, obs_suspicion, intent).

- p (L32-33): Structural note: Coordinates the statements shown in the source companion.

- tick (L36-71): Structural note: Updates o, g.

- phase (L74-92): Structural note: Returns rec. Key operations: save.

- save (L95-106): Structural note: Key operations: open.

### experiments/observer_v3_live_results.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 217,778 bytes; 9,420 lines.

Data structure: phases, sample_input, routing, audit, observer_model.

### experiments/observer_v3_proposal_replay.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 42,105 bytes; 234 lines.

Data structure: {"type": "list", "length": 29}.

### experiments/observer_v3_proposal_replay.py

Capture live proposal inputs (clean, then product cv fault) and replay each through v3 and v2. python experiments/observer_v3_proposal_replay.py [OUT] (default: experiments/observer_v3_proposal_replay.json) Saved result files in the same directory describe particular historical runs.

Snapshot: 2,115 bytes; 51 lines.

Dependencies: import json, sys, time, urllib.request; from live.engine import Engine; from monitor import observer_v2_format as V2, observer_v3_format as V3.

- grab (L16-24): Structural note: Updates end.

- ask (L34-41): Structural note: Returns v['label'] if v else None. Key operations: urllib.request.Request, urllib.request.urlopen(req, timeout=120).read, urllib.request.urlopen.

### experiments/provenance_demo.py

Provenance-gate demonstration: the case physics cannot catch. The injected command is individually inside every physical limit, so the SIS interlock never trips on it - only command-origin integrity can tell it apart from a legitimate command. Each scenario resets the plant to its operating point first; everything uses first-class interfaces only (the enforcer's apply() path, and the plant's own write protocol for the out-of-band case). A legit authorized L1 (signed) issues command C -> admitted, applied B forged an unsigned copy of the identical C reaches the enforcer -> rejected, last-good held C oob+gate C written directly to :55555, bypassing the enforcer, gate active -> detected, last-good re-asserted D oob+nogate same direct write, no gate (legacy) -> undetected, SIS silent Usage: python -m experiments.provenance_demo Saved result files in the same directory describe particular historical runs.

Snapshot: 4,584 bytes; 102 lines.

Dependencies: import json; import time; from pathlib import Path; from contracts import ControlCommand; from l0_plant.grfics_client import GrficsClient; from l0_plant.plant_service import PlantService; from l0_plant.provenance_gate import CommandSigner, ProvenanceGate; from scripts.reset_plant import reset_and_settle.

- _valves (L37-40): Structural note: Returns {k: round(s[k], 2) for k in ('f1_valve_pos', 'f2_valve_pos', 'purge_valve_pos', 'product_valve_po....

- run (L43-91): Structural note: Returns out; st. Key operations: reset_and_settle, PlantService(gate=gate).start, CommandSigner, name.startswith, svc.apply, svc.client.read, signer.sign, sign, rogue.write_inputs.

- run.cycle (L60-66): Structural note: Returns st. Key operations: svc.apply.

- main (L94-98): Structural note: Returns 0. Key operations: OUT.write_text.

### experiments/provenance_demo_results.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 3,488 bytes; 152 lines.

Data structure: {"type": "list", "length": 4}.

### experiments/safe_hold_tune.py

Tune the SIS closed-loop safe-hold on the live simulator (the control room must be stopped). For each candidate gain set: reset the plant, drive it with the stolen-key lineup until the safety channel reads >= 3000 kPa, then run the safe-hold law from l0_plant/safety.py for `--hold` seconds and report whether / when the plant settles inside the re-arm band. python -m experiments.safe_hold_tune [--hold 150] Saved result files in the same directory describe particular historical runs.

Snapshot: 3,131 bytes; 80 lines.

Dependencies: import argparse; import json; import time; from l0_plant.grfics_client import GrficsClient; from l0_plant.safety import SafeHold, SafetyInterlock, TripLimits; from scripts.reset_plant import reset_and_settle.

- truth (L24-26): Structural note: Returns (float(o.get('pressure', 0.0)), float(o.get('liquid_level', 0.0))).

- run (L29-33): Structural note: Returns _run(c, hold, hold_s). Key operations: reset_and_settle.

- _run (L36-62): Structural note: Returns {'hold': hold.__dict__, 'takeover_s': round(t1 - t0, 1), 'settled_at_s': settled_at, 'p_min': min.... Key operations: sis.evaluate, sis.can_reset, c.write_inputs.

- main (L65-76): Structural note: Key operations: reset_and_settle, open.

### experiments/safe_hold_tune_results.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 1,098 bytes; 68 lines.

Data structure: {"type": "list", "length": 3}.

### experiments/trained_operator_demo_results.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 40,645 bytes; 1,490 lines.

Data structure: part1, part2.

### fuzz1.pcap

Binary packet capture retained from Modbus/network experimentation. Contains traffic evidence, not executable application code; packet-level interpretation requires a capture reader.

Snapshot: 4,289 bytes; binary asset.

### images/caldera.png

Visual asset: inherited GRFICS documentation screenshot.

Snapshot: 81,757 bytes; binary asset.

### images/dashboard.png

Visual asset: inherited GRFICS documentation screenshot.

Snapshot: 892,692 bytes; binary asset.

### images/diagram.png

Visual asset: inherited GRFICS documentation screenshot.

Snapshot: 2,457,789 bytes; binary asset.

### images/ew.png

Visual asset: inherited GRFICS documentation screenshot.

Snapshot: 102,432 bytes; binary asset.

### images/firewall.png

Visual asset: inherited GRFICS documentation screenshot.

Snapshot: 48,458 bytes; binary asset.

### images/hmi.png

Visual asset: inherited GRFICS documentation screenshot.

Snapshot: 64,924 bytes; binary asset.

### images/kali.png

Visual asset: inherited GRFICS documentation screenshot.

Snapshot: 372,667 bytes; binary asset.

### images/plc.png

Visual asset: inherited GRFICS documentation screenshot.

Snapshot: 49,099 bytes; binary asset.

### images/sim.png

Visual asset: inherited GRFICS documentation screenshot.

Snapshot: 346,259 bytes; binary asset.

### images/vulns.png

Visual asset: inherited GRFICS documentation screenshot.

Snapshot: 100,071 bytes; binary asset.

### l0_plant/__init__.py

Package initializer. Establishes the import namespace; inspect any exports below. An empty initializer contains no control logic.

Snapshot: 0 bytes; 0 lines.

### l0_plant/fault_injection.py

Names and writes simulator-native ordinary-sensor fault modes/severities, including clearing faults. It does not corrupt the independent safety channel.

Snapshot: 3,304 bytes; 95 lines.

Dependencies: from enum import IntEnum; from l0_plant.grfics_client import GrficsClient.

- FaultMode (L35-40): Structural note: Class (IntEnum). Groups related methods/state.

- set_fault (L54-62): Source docstring: Write a channel's fault mode/severity. Returns the resulting state.

- freeze (L65-67): Source docstring: Measured holds at its current reading regardless of how truth moves.

- drift (L70-72): Source docstring: Measured accumulates an offset from truth at rate_per_hour units/hour.

- noise (L75-77): Source docstring: Measured = truth +/- uniform(amplitude) each tick.

- dropout (L80-82): Source docstring: Measured reads 0 for a `duty` fraction (0..1) of each 10s window.

- clear (L85-87): Source docstring: Return a channel to healthy (measured tracks truth again).

- clear_all (L90-95): Source docstring: Clear every channel's fault. Returns the final state.

### l0_plant/grfics_client.py

Newline-delimited JSON socket adapter. Manages connection lifetime and synchronous request/response framing; it deliberately contains no safety policy.

Snapshot: 2,695 bytes; 78 lines.

Dependencies: import json; import socket; from typing import Optional.

- GrficsClient (L30-78): Structural note: Class (no explicit base class). Groups related methods/state.

- GrficsClient.__init__ (L31-37): Structural note: Updates self.host, self.port, self.timeout, self._f.

- GrficsClient.connect (L39-44): Structural note: Returns self.

- GrficsClient.close (L46-54): Structural note: Coordinates the statements shown in the source companion.

- GrficsClient.__enter__ (L56-57): Structural note: Returns self.connect().

- GrficsClient.__exit__ (L59-60): Structural note: Coordinates the statements shown in the source companion.

- GrficsClient._txn (L62-70): Structural note: Returns json.loads(line.decode()). Key operations: self._f.write, self._f.readline.

- GrficsClient.read (L72-74): Source docstring: Return the raw state object from the simulator.

- GrficsClient.write_inputs (L76-78): Source docstring: Send one or more named inputs; returns the post-update state.

### l0_plant/plant_service.py

Translates raw simulator dictionaries to PlantState, runs the interlock, audits command origin, applies admitted/fallback/protective writes and guards reset with safety-channel readings.

Snapshot: 7,296 bytes; 153 lines.

Dependencies: import sys; import os; from contracts import PlantState, ControlCommand; from l0_plant.grfics_client import GrficsClient; from l0_plant.safety import SafeHold, SafetyInterlock, TripLimits; from l0_plant.provenance_gate import ProvenanceGate.

- PlantService (L39-153): Structural note: Class (no explicit base class). Groups related methods/state.

- PlantService.__init__ (L40-49): Structural note: Updates self.client, self.safety, self._sis_reading, self.gate, self._connected.

- PlantService.start (L51-56): Structural note: Returns self. Key operations: self.client.read().get, self.client.read.

- PlantService.stop (L58-60): Structural note: Updates self._connected.

- PlantService._to_state (L63-94): Structural note: Returns PlantState(pressure=m.get('pressure', 0.0), level=m.get('liquid_level', 0.0), f1_flow=m.get('f1_f.... Key operations: self.safety.evaluate.

- PlantService.read (L97-98): Structural note: Returns self._to_state(self.client.read()). Key operations: self.client.read.

- PlantService.apply (L100-141): Source docstring: Apply an L1 control command. If the interlock is tripped, the command is ignored and the plant is driven to its safe state instead. The AI has no way to override this path - that is the whole point.

- PlantService.reset_interlock (L143-153): Source docstring: Deliberate operator reset; only clears if the SIS channel is back inside the re-arm band. Reads outputs directly (not PlantState.pressure/level, which are measured and could be faulted) for the same reason the trip itself reads the SIS channel: re-arm must not be spoofable either.

### l0_plant/provenance_gate.py

Exact-float HMAC signing, increasing sequence admission, last-good fallback and out-of-band actuator/E-stop audit. Does not authenticate the simulator socket itself.

Snapshot: 7,287 bytes; 161 lines.

Dependencies: import hashlib; import hmac; from collections import deque; from dataclasses import dataclass, field, replace; from typing import Deque, Dict, List, Optional, Tuple; from contracts import ControlCommand.

- _tag (L49-52): Structural note: Returns hmac.new(key, msg.encode(), hashlib.sha256).hexdigest().

- CommandSigner (L55-64): Source docstring: L1-side: stamps each outgoing command with a sequence number and tag.

- CommandSigner.__init__ (L58-60): Structural note: Updates self._key, self._seq.

- CommandSigner.sign (L62-64): Structural note: Returns replace(cmd, seq=self._seq, auth_tag=_tag(self._key, self._seq, cmd)).

- GateEvent (L68-71): Structural note: Class (no explicit base class). Declared data: kind, detail, id.

- ProvenanceGate (L75-161): Structural note: Class (no explicit base class). Declared data: key, strict, last_seq, last_good, expect_e_stop, events, n_events.

- ProvenanceGate.seed (L86-89): Source docstring: Initial last-good = what the plant holds when the enforcer takes over.

- ProvenanceGate.admit (L91-103): Structural note: Returns self._accept(cmd); self._reject('non-finite valve value'); self._reject(f'replayed/stale sequence {cmd.seq} (last {self.last_seq})'); self._reject('invalid provenance tag'); self._reject('unsigned command (no provenance tag)').

- ProvenanceGate._accept (L105-107): Structural note: Returns (True, 'ok').

- ProvenanceGate._reject (L109-111): Structural note: Returns (False, why).

- ProvenanceGate.clear_e_stop (L113-121): Source docstring: The enforcer is releasing e_stop. The plant's valves are where e_stop left them, not at the pre-trip last-good, so reseed last-good from the readback - otherwise the first post-trip audit false-flags them.

- ProvenanceGate._event (L123-125): Structural note: Coordinates the statements shown in the source companion.

- ProvenanceGate.note_safe_state (L127-140): Source docstring: Record what the interlock's cause-specific safe state wrote, so the audit expects it (e_stop for pressure/high level; product closed with the other valves held for low level).

- ProvenanceGate.audit (L142-161): Source docstring: Compare the plant's own readback (raw["state"]) with what the enforcer last wrote. Returns the mismatches (empty = clean). Valve positions are not compared while e_stop is the expected state, since e_stop deliberately overrides them.

### l0_plant/safety.py

Trip thresholds, reset hysteresis, optional closed-loop SafeHold and the latched interlock state machine. First cause persists while secondary hazards can escalate protection.

Snapshot: 10,084 bytes; 203 lines.

Dependencies: import math; from dataclasses import dataclass.

- _valid (L42-43): Structural note: Returns isinstance(x, (int, float)) and (not isinstance(x, bool)) and math.isfinite(x).

- SafeHold (L51-67): Source docstring: Closed-loop safe-hold law, run by the SIS on its own (safety-channel) readings.

- SafeHold.lineup (L60-67): Structural note: Returns {'e_stop': 0, 'f1_valve_sp': clamp(d['f1'] * self.feed_frac), 'f2_valve_sp': clamp(d['f2'] * self....

- TripLimits (L71-83): Structural note: Class (no explicit base class). Declared data: pressure_high, level_low, level_high, pressure_rearm, level_low_rearm, level_high_rearm.

- SafetyInterlock (L86-203): Structural note: Class (no explicit base class). Groups related methods/state.

- SafetyInterlock.__init__ (L87-96): Structural note: Updates self.limits, self.safe_hold, self.tripped, self.reason, self.cause, self.escalated, self._sensor_fault, self._combined_low_level.

- SafetyInterlock.evaluate (L98-127): Source docstring: Update interlock state from the latest measured values. Returns True if the plant should currently be forced safe (scrammed).

- SafetyInterlock.can_reset (L129-135): Source docstring: Whether a latched trip is eligible to be cleared right now.

- SafetyInterlock.protection_mode (L138-149): Structural note: Returns 'emergency_stop'; 'armed'; 'combined_hold'; 'inventory_hold'; 'safe_hold'.

- SafetyInterlock.reset (L151-163): Source docstring: Deliberate operator reset. Only succeeds if variables are back inside the re-arm band; otherwise the trip stays latched.

- SafetyInterlock.safe_state_inputs (L165-198): Source docstring: Simulator write-inputs that put the plant in the safe state for the latched trip cause. The right safe state depends on the hazard: * pressure_high / level_high: e_stop (feeds shut, purge and product open) - relieves pressure and drains an overfull vessel. * level_low: e_stop would OPEN the product valve and keep draining a vessel that is already too low. Instead close product to stop the drain and leave the feed/...

- SafetyInterlock._trip (L200-203): Structural note: Updates self.tripped, self.reason, self.cause.

### l1_regulator.py

Current live four-loop PI controller. Includes anti-windup, pressure split-range feed assistance, production feedforward, composition conversion, hold/resume tracking and final command signing.

Snapshot: 8,811 bytes; 167 lines.

Dependencies: from dataclasses import replace; from typing import Optional; from contracts import ControlCommand, PlantState, SupervisoryTargets; from l0_plant.provenance_gate import CommandSigner.

- PI (L59-75): Source docstring: u = kp*e + i, clamped to [lo, hi]; the integral only moves when that does not push further into saturation (conditional integration).

- PI.__init__ (L63-65): Structural note: Updates (self.kp, self.ki, self.lo, self.hi), self.i.

- PI.__call__ (L67-71): Structural note: Returns max(self.lo, min(self.hi, self.kp * e + self.i)).

- PI.track (L73-75): Source docstring: Bumpless: make the current output equal u.

- _a_pct (L78-79): Structural note: Returns state.a_in_purge * 100.0.

- L1Regulator (L82-167): Structural note: Class (no explicit base class). Groups related methods/state.

- L1Regulator.__init__ (L83-91): Structural note: Key operations: CommandSigner.

- L1Regulator.regulate (L94-126): Structural note: Returns ControlCommand(f1_valve=f1 * trim, f2_valve=f2 * trim, purge_valve=purge, product_valve=product).....

- L1Regulator._resume (L128-137): Source docstring: None setpoint -> hold this valve. When a setpoint returns after a hold, seed the loop from the valve the plant holds now so the hand-back does not kick.

- L1Regulator._seed (L139-152): Structural note: Coordinates the statements shown in the source companion.

- L1Regulator.bumpless (L154-160): Source docstring: Re-seed every loop from the valves the plant holds now (connect, re-arm, reconnect).

- L1Regulator.sign (L163-167): Source docstring: Stamp the FINAL command (after the enforcer's clamps) for the provenance gate.

### l1_stub.py

Historical placeholder regulator retained by older demonstrations and dataset collection. Its behavior is not interchangeable with the live L1Regulator.

Snapshot: 3,100 bytes; 66 lines.

Dependencies: from contracts import PlantState, SupervisoryTargets, ControlCommand.

- _PI (L28-41): Structural note: Class (no explicit base class). Groups related methods/state.

- _PI.__init__ (L29-32): Structural note: Updates (self.kp, self.ki, self.lo, self.hi), self.i, self.bias.

- _PI.__call__ (L34-41): Structural note: Returns out.

- L1ControlStub (L44-66): Structural note: Class (no explicit base class). Groups related methods/state.

- L1ControlStub.__init__ (L45-50): Structural note: Updates self.pressure_pi, self.level_pi, self.prod_pi, self.comp_pi.

- L1ControlStub.regulate (L52-66): Structural note: Returns ControlCommand(f1_valve=f1, f2_valve=f2, purge_valve=purge, product_valve=product).clamped().

### l3_brain/__init__.py

Package initializer. Establishes the import namespace; inspect any exports below. An empty initializer contains no control logic.

Snapshot: 0 bytes; 0 lines.

### l3_brain/operator.py

Wraps a swappable Policy, saves unblended last_intent and blends each target according to supplied authority. Zero authority produces None targets.

Snapshot: 5,627 bytes; 118 lines.

Dependencies: import math; import sys; import os; from dataclasses import replace; from typing import Callable, Optional; from contracts import PlantState, SupervisoryTargets; from l3_brain.policy import Policy, BaselineOperator, make_policy.

- AIOperator (L45-107): Structural note: Class (no explicit base class). Groups related methods/state.

- AIOperator.__init__ (L46-53): Structural note: Updates self.policy, self.authority_fn.

- AIOperator._apply_authority (L55-101): Source docstring: Blend the brain's requested setpoints toward a safe hold as authority drops. authority=1 -> full request, unchanged. authority=0 -> hold, meaning every setpoint goes to None: L1 (l1_stub.regulate) treats a None setpoint as "leave that valve where it is", which is a true freeze, not a PI loop quietly re-targeting the current reading. In between, setpoints are interpolated between "current measured value" (0 net cha...

- AIOperator._apply_authority.blend (L84-87): Structural note: Returns current * (1 - a) + req * a; None.

- AIOperator.step (L103-107): Source docstring: One decision cycle. Pure function of state + current authority.

- stub_authority_fn (L110-118): Source docstring: Placeholder for the real L2 governance authority_fn - fixed at full authority. The L2 teammate replaces this with whatever actually detects "the brain is misbehaving" (e.g. anomaly score, policy confidence, a human override switch) and returns a 0..1 value from it; everything downstream in AIOperator already knows what to do with that number.

### l3_brain/policy.py

Policy protocol, deterministic baseline, strict model-output parsing, cached/background LLM decisions, Ollama transport and availability/fallback selection.

Snapshot: 16,869 bytes; 357 lines.

Dependencies: import json; import math; import sys; import os; import threading; import time; from collections import deque; from dataclasses import dataclass; from typing import Callable, Deque, Optional, Protocol, Tuple; from contracts import PlantState, SupervisoryTargets; from l0_plant.safety import TripLimits; from l3_brain.prompt_format import DESIGN_POINT, state_to_json, system_prompt.

- Policy (L32-33): Structural note: Class (Protocol). Groups related methods/state.

- Policy.decide (L33-33): Structural note: Coordinates the statements shown in the source companion.

- BaselineOperator (L36-82): Source docstring: A transparent, non-ML baseline so the whole stack runs end-to-end on day one and later ML policies have something to beat. It nudges the supervisory setpoints toward a safe, economic operating point and backs off hard when either (a) the plant is near a protective limit or (b) governance has reduced the brain's authority. It expresses intent only as setpoints - it never names a valve.

- BaselineOperator.__init__ (L47-55): Structural note: Updates self.pressure_target, self.level_target, self.production_target, self.a_comp_target.

- BaselineOperator.decide (L57-82): Structural note: Returns SupervisoryTargets(pressure_sp=self.pressure_target, level_sp=self.level_target, production_rate_...; SupervisoryTargets(authority=0.0, rationale=f'plant scrammed ({state.scram_reason}); holding').

- Envelope (L103-108): Source docstring: Safe operating envelope for supervisory setpoints (inclusive).

- hold_targets (L120-122): Source docstring: All setpoints None: L1 freezes the valves where they are.

- parse_llm_targets (L125-166): Source docstring: Parse + validate model output into SupervisoryTargets. Returns (targets, note); targets is None on any failure and `note` says why. Pure function, no network. Only the four setpoints and the rationale are read - any other key (including anything resembling a valve) is ignored.

- build_state_prompt (L169-172): Source docstring: The user turn: measured fields only, as JSON (prompt_format.state_to_json). Never touches state.truth.

- LLMOperator (L175-282): Source docstring: Model-backed supervisory policy (base class; the served backend is OllamaOperator below). decide() never blocks on the network and never raises: it returns the cached decision immediately, and when the supervisory interval has elapsed kicks off ONE background model call whose result becomes the new cached decision. L1 keeps regulating every cycle against the cached setpoints in between. `background=False` runs the...

- LLMOperator.__init__ (L188-209): Structural note: Key operations: threading.Lock.

- LLMOperator.decide (L212-231): Structural note: Returns cached; SupervisoryTargets(authority=0.0, rationale=f'plant scrammed ({state.scram_reason}); holding'). Key operations: threading.Thread(target=self._refresh, args=(state, cached), daemon=True).start, threading.Thread.

- LLMOperator._get_client (L234-237): Structural note: Returns self._client.

- LLMOperator._call_model (L239-245): Structural note: Returns next((b.text for b in resp.content if b.type == 'text'), '').

- LLMOperator.set_note (L247-252): Source docstring: Set (or clear, with None/empty) the standing operator instruction. Returns its id.

- LLMOperator._user_prompt (L254-256): Structural note: Returns build_state_prompt(state) + (f'\nOperator instruction: {note}' if note else '').

- LLMOperator._refresh (L258-282): Structural note: Updates t0.

- _http_post_json (L289-294): Structural note: Returns json.loads(r.read()). Key operations: urllib.request.Request, urllib.request.urlopen, r.read.

- OllamaOperator (L297-326): Source docstring: The locally fine-tuned operator (model/scram-operator-gguf, served by Ollama) as the brain. Same prompt_format (system prompt + measured-state JSON) it was trained on, same parse/validate/clamp and hold-on-any-failure as LLMOperator - only the model call differs. Local inference is ~1 s, so the default supervisory interval is shorter. `http_post(url, body, timeout_s)` is injectable (tests mock it; no network).

- OllamaOperator.__init__ (L307-313): Structural note: Updates self.model, self.base_url, self._http_post.

- OllamaOperator._call_model (L315-326): Structural note: Returns msg.get('content', '') if isinstance(msg, dict) else ''. Key operations: self._http_post.

- ollama_available (L329-340): Source docstring: True if the Ollama server answers and has the model registered.

- make_policy (L343-357): Source docstring: Select the brain by argument, SCRAM_OPERATOR or SCRAM_POLICY (default "baseline"). "ollama" = the locally fine-tuned model; when Ollama is down or the model is not registered it falls back to the offline BaselineOperator rather than a permanent hold. Anything else selects BaselineOperator.

### l3_brain/prompt_format.py

Single measured-only operator prompt schema shared by training and serving. Defines design targets, field selection, rounding and system text.

Snapshot: 3,023 bytes; 58 lines.

Dependencies: import json; from l0_plant.safety import TripLimits.

- measured_dict (L32-35): Source docstring: Measured fields of a PlantState (or an already-recorded dict), rounded.

- state_to_json (L38-39): Structural note: Returns json.dumps(measured_dict(state)).

- system_prompt (L42-58): Structural note: Returns f"""You are the supervisory operator for a Tennessee-Eastman reactor. You choose SETPOINTS; a reg....

### live/__init__.py

Package initializer. Establishes the import namespace; inspect any exports below. An empty initializer contains no control logic.

Snapshot: 82 bytes; 1 lines.

Source documentation: SCRAM live control room: the full stack on the live plant (python -m live).

### live/__main__.py

Primary application entry point. CLI, simulator availability/startup, opt-in Ollama setup, Engine lifecycle, HTTP server and optional browser launch.

Snapshot: 7,493 bytes; 178 lines.

Dependencies: import argparse; import os; import shutil; import socket; import subprocess; import sys; import time; import webbrowser; from pathlib import Path; from l0_plant.safety import TripLimits; from l3_brain.policy import ollama_available; from live.engine import DEMO_LIMITS, Engine; from live.server import serve.

- plant_up (L35-40): Structural note: Returns True; False.

- _ollama_up (L47-52): Structural note: Returns True; False.

- _ollama_exe (L55-57): Structural note: Returns shutil.which('ollama') or (str(local) if local.is_file() else None).

- _windows_user_env (L60-73): Source docstring: Read (or, with value, write) a Windows *user* environment variable.

- _start_ollama (L76-85): Structural note: Returns False; True. Key operations: subprocess.Popen.

- ensure_ollama_cache_cap (L88-117): Source docstring: The live stack keeps three models resident (operator, observer v2, observer v3). Ollama's bundled llama-server otherwise keeps a host-RAM prompt cache of up to 8 GB PER MODEL, which exhausted a 16 GB laptop in ~4.5 min (model/README.md). Make sure the Ollama server runs with LLAMA_ARG_CACHE_RAM=0: persist it as a user variable on Windows, and (re)start the server with it if needed.

- main (L120-174): Structural note: Returns 0; 1. Key operations: Engine(brain=a.brain, limits=TripLimits() if a.production_limits else DEMO_LIMITS, reset=not a.no_reset).start, webbrowser.open, threading.Thread(target=srv.serve_forever, daemon=True).start, threading.Thread, engine.read.

### live/commands.py

Deterministic control-room chat routing into protected manual valve overrides, release, canonical target instructions or free-form model notes.

Snapshot: 5,150 bytes; 114 lines.

Dependencies: import re; from typing import Dict, Optional; from l3_brain.prompt_format import DESIGN_POINT.

- _valve_targets (L44-63): Structural note: Returns {v: pct for v in found}; None.

- _setpoints (L66-89): Structural note: Returns out. Key operations: km.start.

- parse (L92-108): Source docstring: Classify an operator command. `current` = the setpoints in force (for relative changes).

- canonical (L111-114): Source docstring: The instruction form the operator model follows: explicit target values.

### live/engine.py

Full-stack composition and control-thread owner. Queues actions, regulates/signs/applies commands, runs monitors/governance, executes demonstrations, manages recovery and publishes bounded snapshots.

Snapshot: 54,699 bytes; 953 lines.

Dependencies: import json; import math; import queue; import inspect; import re; import threading; import time; import uuid; import os; import secrets; from collections import deque; from dataclasses import replace; from pathlib import Path; from typing import Callable, Deque, Optional; from contracts import ControlCommand, PlantState, SupervisoryTargets; from enforcer.keel import Keel, KeelLimits, SisFrame; from l0_plant import fault_injection as fi; from l0_plant.grfics_client import GrficsClient; from l0_plant.plant_service import PlantService; from l0_plant.provenance_gate import CommandSigner, ProvenanceGate; from l0_plant.safety import SafeHold, TripLimits; from l1_regulator import L1Regulator; from l3_brain.operator import AIOperator; from live import commands; from l3_brain.prompt_format import DESIGN_POINT; from l3_brain.policy import BaselineOperator, LLMOperator, OllamaOperator, ollama_available; from monitor.behavior_monitor import BehaviorMonitor, MonitorLimits; from monitor.governance import Governor; from monitor.observer import SplitObserver, make_split_observer; from monitor.sequential_monitor import SequentialMonitor, Suspicion; from monitor.telemetry_classifier import approved_specialist; from scripts.reset_plant import DESIGN_PURGE_VALVE_PCT, reset_and_settle.

- _pct (L100-107): Structural note: Returns x.

- _duration (L110-117): Structural note: Returns x.

- _num (L120-121): Structural note: Returns None if v is None or (isinstance(v, float) and (not math.isfinite(v))) else round(float(v), 3).

- Engine (L124-953): Structural note: Class (no explicit base class). Groups related methods/state.

- Engine.__init__ (L125-161): Structural note: Key operations: threading.Lock, threading.Event.

- Engine._make_brain (L164-176): Structural note: Updates policy, self.brain_kind, self.policy, self._seen_calls, self._chat_pending, self.brain.

- Engine.effective_authority (L178-180): Source docstring: What the brain actually gets: the operator slider, Keel and governance, lowest wins.

- Engine.brain_label (L182-185): Structural note: Returns 'BaselineOperator (rule-based fallback)'; f'Trained scram-operator (Ollama, every {self.policy.interval_s:g}s)'.

- Engine._connect (L187-235): Structural note: Key operations: PlantService(self.host, self.port, limits=self.limits, gate=self.gate, safe_hold=SafeHold()).start, self.svc.read, reset_and_settle.

- Engine.start (L238-240): Structural note: Returns self. Key operations: threading.Thread(target=self._run, name='scram-control', daemon=True).start, threading.Thread.

- Engine.stop (L242-243): Structural note: Coordinates the statements shown in the source companion.

- Engine.submit (L245-262): Structural note: Returns 'queued'; fn(**kw). Key operations: inspect.signature(fn).bind, inspect.signature.

- Engine.now (L264-265): Structural note: Returns time.monotonic() - self.t0.

- Engine.log (L267-270): Structural note: Coordinates the statements shown in the source companion.

- Engine._run (L273-299): Structural note: Updates last_hist.

- Engine._run_action (L301-309): Source docstring: A queued operator action. Its own errors (e.g. a bad argument) are logged as such; only a real plant I/O error is left to the loop's reconnect handler.

- Engine._clear_actuator_faults (L311-313): Structural note: Key operations: self.svc.client.write_inputs.

- Engine._reconnect (L315-330): Structural note: Key operations: self.svc.read, self.svc.client.read().get, self.svc.client.read.

- Engine._cycle (L332-466): Structural note: Key operations: self.l1.regulate, self.l1.sign, self.svc.apply, self.svc.client.write_inputs, self.seq_monitor.reset_all, self.brain._apply_authority.

- Engine._safe_state_label (L468-478): Structural note: Returns 'e_stop (feeds shut, purge + product open)'; 'e_stop (feeds shut, purge + product open; latched)'; 'combined hazard: feeds shut, purge open, product closed'; 'product valve closed, feeds held'; 'closed-loop safe-hold (feeds cut back, purge and product on the safety chan.

- Engine._auto_rearm (L480-499): Source docstring: Re-arm once the safety channel has held inside the re-arm band for AUTO_REARM_S, unless it has already done so AUTO_REARM_MAX times in AUTO_REARM_WINDOW_S.

- Engine._note_decision (L501-524): Structural note: Updates p.

- Engine._note_governance (L526-543): Source docstring: Trace every cycle; hash-chained log at 1 Hz and on any change; event stream on a change of driving label, ceiling tier or recovery state.

- Engine._log_observer_online (L545-549): Structural note: Updates o.

- Engine._note_observer (L551-562): Source docstring: Log each new observer verdict whose label changed, per input type.

- Engine._gate_bookkeeping (L564-587): Structural note: Returns new.

- Engine._inject_forged (L589-605): Structural note: Key operations: self.svc.apply, CommandSigner(ATTACKER_KEY).sign, CommandSigner.

- Engine._record (L607-621): Structural note: Updates (s, tg), tr.

- Engine._snapshot (L623-673): Structural note: Returns {'t': round(self.now(), 1), 'status': self.status, 'error': self.error, 'cycles': self.cycles, 'b.... Key operations: saf.can_reset.

- Engine.read (L675-687): Structural note: Returns snap.

- Engine._act_authority (L690-695): Structural note: Returns 'ok'.

- Engine._act_brain (L697-698): Structural note: Coordinates the statements shown in the source companion.

- Engine._act_level_drift (L700-704): Structural note: Updates self.faults['tank_level'].

- Engine._act_pressure_dropout (L706-710): Structural note: Updates self.faults['tank_pressure'].

- Engine._act_actuator_fault (L712-727): Source docstring: Native simulator actuator fault: the valve freezes where it is (stuck) or passes half its flow (cv). "demo" = cv now, stuck VALVE_STICK_AFTER_S later: at steady state L1 barely moves a valve, so a bare stuck valve looks normal (command and position never part); the capacity loss makes L1 start opening it first.

- Engine._act_forged (L729-733): Structural note: Updates t, self.scenarios['forged'].

- Engine._act_operator_injection (L735-739): Structural note: Updates t, self.scenarios['operator_injection'].

- Engine._check_stolen_key (L741-745): Structural note: Coordinates the statements shown in the source companion.

- Engine._act_stolen_key (L747-756): Structural note: Updates v, t, self.scenarios['stolen_key'].

- Engine._check_oob_write (L758-761): Structural note: Coordinates the statements shown in the source companion.

- Engine._act_oob_write (L763-770): Structural note: Key operations: self._check_oob_write, c.write_inputs.

- Engine._check_sensor_fault (L772-782): Structural note: Coordinates the statements shown in the source companion.

- Engine._act_sensor_fault (L784-792): Source docstring: Any of the simulator's native sensor faults on any channel (custom attack builder).

- Engine._chat_add (L795-798): Structural note: Coordinates the statements shown in the source companion.

- Engine._check_chat (L800-802): Structural note: Coordinates the statements shown in the source companion.

- Engine._act_chat (L804-841): Source docstring: Route an operator command: valve positions become a manual override (the AI never chooses valves), setpoints go to the AI with explicit targets, the rest goes verbatim.

- Engine._release_manual (L843-849): Structural note: Updates names.

- Engine._act_clear_note (L851-856): Structural note: Updates self._chat_pending.

- Engine._chat_defense_report (L858-877): Structural note: Updates o, g, parts, eff, verdict, p, moved.

- Engine._act_clear_faults (L879-892): Structural note: Coordinates the statements shown in the source companion.

- Engine._act_reset_interlock (L894-899): Structural note: Coordinates the statements shown in the source companion.

- Engine._rearm (L901-935): Structural note: Key operations: self.svc.reset_interlock, self.l1.sign, self.svc.apply, self.seq_monitor.reset_all, self.governor.reset, self.observer.reset.

- Engine._act_reset_plant (L937-953): Structural note: Coordinates the statements shown in the source companion.

### live/server.py

Loopback standard-library HTTP server: static assets, incremental state API, validated action submission and same-origin GRFICS proxy.

Snapshot: 5,395 bytes; 111 lines.

Dependencies: import json; import urllib.error; import urllib.request; from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer; from pathlib import Path; from urllib.parse import parse_qs, urlparse; from live.engine import Engine.

- make_handler (L35-105): Structural note: Returns Handler; self._send(200, (STATIC / 'reactor.html').read_bytes(), TYPES['.html']); self._proxy(u.path[len('/grfics'):], u.query); self._proxy(u.path, u.query); self._send(200, json.dumps(data).encode()); self._send(404, b'{"error":"not found"}'); self._send(e.code, b'', . Key operations: self.wfile.write, u.path.startswith, engine.read, f.read_bytes, engine.submit, urllib.request.urlopen, r.read, (STATIC / 'reactor.html').read_bytes, self.rfile.read.

- make_handler.Handler (L36-103): Structural note: Class (BaseHTTPRequestHandler). Groups related methods/state.

- make_handler.Handler.log_message (L37-38): Structural note: Coordinates the statements shown in the source companion.

- make_handler.Handler._send (L40-46): Structural note: Key operations: self.wfile.write.

- make_handler.Handler._proxy (L48-63): Structural note: Returns self._send(e.code, b'', 'text/plain'); self._send(502, b'{"error":"plant web server (:80) not reachable"}'). Key operations: self.wfile.write, urllib.request.urlopen, r.read.

- make_handler.Handler.do_GET (L65-85): Structural note: Returns self._send(200, (STATIC / 'reactor.html').read_bytes(), TYPES['.html']); self._proxy(u.path[len('/grfics'):], u.query); self._proxy(u.path, u.query); self._send(200, json.dumps(data).encode()); self._send(404, b'{"error":"not found"}'); self._send(400, b'{"error":"h and. Key operations: u.path.startswith, engine.read, f.read_bytes, (STATIC / 'reactor.html').read_bytes.

- make_handler.Handler.do_POST (L87-103): Structural note: Returns self._send(404, b'{"error":"not found"}'). Key operations: engine.submit, self.rfile.read.

- serve (L108-111): Structural note: Returns srv. Key operations: ThreadingHTTPServer.

### live/static/control-room.css

Presentation stylesheet: layout, typography, color, component states and responsive rules. It does not make control decisions. Cascade/load order in the matching HTML determines overrides.

Snapshot: 25,429 bytes; 286 lines.

### live/static/control-room.js

Browser state, poll cursors, actions/chat, tabs, event filtering, recovery and layer status, SVG instruments and Canvas histories. Render helpers project backend state into DOM elements.

Snapshot: 43,856 bytes; 673 lines.

Code landmarks: L25: async function act(action, extra = {}) {; L37: function showBanner(msg) { const b = $("banner"); b.textContent = msg; b.hidden = !msg; }; L70: // ---------- tabs (remembered per viewer) ----------; L71: function setTab(name) {; L101: // ---------- chat ----------; L103: async function send(text) {; L112: function spChips(sp) {; L118: function renderChat(s) {; L158: // ---------- attack builder ----------; L180: // ---------- instruments: pressure dial + tank (built once, then only moved) ----------; L182: function el(tag, attrs, parent) {; L191: function arc(r, a1, a2) {; L195: function buildDial(trip, rupture) {; L219: function buildTank(lo, hi) {; L234: function renderInstruments(s) {; L257: function renderDashboard(s) {; L275: function renderRecovery(s) {; L302: function renderConsoleStrip(s, eff) {; L312: function setConn(ok, txt) {; L327: async function poll() {; L360: function logItem(e) {; L368: function renderLog(newEvents) {; L383: function setBar(id, v) { const b = $(id); b.style.width = `${Math.max(1.5, Math.min(1, v) * 100)}%`; b.style.background = state...; L385: function renderSummary(s) {; L427: function render(s) {; L477: function renderStack(s, eff) {; L510: function renderControls(s) {; L520: function renderBrain(s) {; L546: function obsCard(card, lab, rsn, meta, v, s, isProposal) {; L556: function renderObservers(s) {; L569: // ---------- charts ----------; L570: function hexA(col, a) {; L576: function canvasCtx(id) {; L582: function chart(id, series, lines, fixed, minSpan = 0, digits = null) {; L634: function spark(id, pts, col, minSpan = 1, fixed = null) {; L648: function draw() {.

### live/static/index.html

Main control-room document and stable DOM IDs consumed by control-room.js; links layout/style layers and embeds reactor/telemetry views.

Snapshot: 31,601 bytes; 292 lines.

Code landmarks: L38: <section class="workspace-heading">; L125: <section class="strip">; L132: <section class="gcon">; L254: <section class="g2e">; L277: <section class="panel">; L290: <script src="/control-room.js"></script>; L291: <script src="/telemetry-workspace.js"></script></body>.

### live/static/nocturne.css

Presentation stylesheet: layout, typography, color, component states and responsive rules. It does not make control decisions. Cascade/load order in the matching HTML determines overrides.

Snapshot: 13,125 bytes; 242 lines.

### live/static/reactor.html

Standalone full-bleed Unity reactor wrapper, loaded through the live server/proxy.

Snapshot: 2,254 bytes; 44 lines.

Code landmarks: L10: <script src="Build/UnityLoader.js"></script>; L25: <script>.

### live/static/telemetry-workspace.js

Read-only telemetry exploration controls: signal choice, table/graph modes, connection state and rendering from the existing backend feed.

Snapshot: 6,366 bytes; 106 lines.

Code landmarks: L19: function selectSignal(value) {; L26: function setMode(value, focus = false) {; L50: function connection(ok, text) {; L54: function renderTable(rows) {; L75: function render(state) {.

### live/static/workspace.css

Presentation stylesheet: layout, typography, color, component states and responsive rules. It does not make control decisions. Cascade/load order in the matching HTML determines overrides.

Snapshot: 34,150 bytes; 66 lines.

### modbus.pcap

Binary packet capture retained from Modbus/network experimentation. Contains traffic evidence, not executable application code; packet-level interpretation requires a capture reader.

Snapshot: 2,625 bytes; binary asset.

### modbus_test.py

Standalone inherited Modbus exercise. Reads/writes device registers directly; not imported by the current JSON-based control loop.

Snapshot: 378 bytes; 17 lines.

Dependencies: from pymodbus.client.sync import ModbusTcpClient.

### model/README.md

Directory-specific setup, background or saved-model documentation. Read in context of the current source and the historical distinctions in this guide.

Snapshot: 4,106 bytes; 83 lines.

### model/eval_ollama.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 338,571 bytes; 9,646 lines.

Data structure: scram-operator, qwen2.5:1.5b.

### model/eval_val.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 108,784 bytes; 2,897 lines.

Data structure: n, valid_json_all_4_setpoints, valid_json_rate, accepted_by_LLMOperator_parser, mae, mae_n, hold_recall, false_hold_on_action_states, per_rule, secs_per_example, predictions.

### model/scram-observer-gguf/Modelfile

Ollama serving recipe: references local GGUF weights and configures prompt/template or generation behavior. The weight file itself may be ignored by Git.

Snapshot: 1,854 bytes; 7 lines.

### model/scram-observer-v3-gguf/Modelfile

Ollama serving recipe: references local GGUF weights and configures prompt/template or generation behavior. The weight file itself may be ignored by Git.

Snapshot: 2,249 bytes; 7 lines.

### model/scram-observer-v3-gguf/eval_observer_test_unseen.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 118,072 bytes; 2,480 lines.

Data structure: split, n, valid_json, accuracy, per_class_recall, detection_rate, false_alarm_rate, n_normal, confusion, by_kind, predictions.

### model/scram-observer-v3-gguf/eval_observer_val.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 278,843 bytes; 6,140 lines.

Data structure: split, n, valid_json, accuracy, per_class_recall, detection_rate, false_alarm_rate, n_normal, confusion, by_kind, predictions.

### model/scram-observer-v3-gguf/lora/README.md

Directory-specific setup, background or saved-model documentation. Read in context of the current source and the historical distinctions in this guide.

Snapshot: 2,318 bytes; 49 lines.

### model/scram-observer-v3-gguf/lora/adapter_config.json

LoRA adapter/base-model metadata, including rank, target modules and scaling; required to interpret adapter weights.

Snapshot: 1,328 bytes; 55 lines.

Data structure: alora_invocation_tokens, alpha_pattern, arrow_config, auto_mapping, base_model_name_or_path, bias, corda_config, ensure_weight_tying, eva_config, exclude_modules, fan_in_fan_out, inference_mode, init_lora_weights, kasa_config, layer_replication, layers_pattern, layers_to_transform, loftq_config, lora_alpha, lora_bias, lora_dropout, lora_ga_config, megatron_config, megatron_core, modules_to_save, monteclora_config, peft_type, peft_version, qalora_group_size, r, rank_pattern, revision, target_modules, target_parameters, task_type, trainable_token_indices, use_bdlora, use_dora, use_qalora, use_rslora, velora_config.

### model/scram-observer-v3-gguf/lora/chat_template.jinja

Model chat template translating role/content messages into the token layout expected by the base model and fine-tuning.

Snapshot: 2,506 bytes; 53 lines.

### model/scram-observer-v3-gguf/lora/tokenizer.json

Large tokenizer vocabulary/normalizer/pretokenizer and token-ID mapping. Generated model infrastructure, not a handwritten controller; printing every token would obscure the implementation.

Snapshot: 11,422,166 bytes; 757,464 lines.

Data structure: version, truncation, padding, added_tokens, normalizer, pre_tokenizer, post_processor, decoder, model.

### model/scram-observer-v3-gguf/lora/tokenizer_config.json

Tokenizer options, special tokens and chat-format metadata used by the model stack.

Snapshot: 4,412 bytes; 194 lines.

Data structure: add_prefix_space, backend, bos_token, clean_up_tokenization_spaces, eos_token, errors, is_local, local_files_only, model_max_length, pad_token, padding_side, split_special_tokens, tokenizer_class, unk_token, added_tokens_decoder.

### model/scram-observer-v3-gguf/train_metrics.json

Saved training configuration, loss history and resource/quality metrics. Describes a historical training run, not a fresh check of this machine.

Snapshot: 167 bytes; 8 lines.

Data structure: epoch, eval_loss, eval_runtime, eval_samples_per_second, eval_steps_per_second, step.

### model/scram-operator-gguf/Modelfile

Ollama serving recipe: references local GGUF weights and configures prompt/template or generation behavior. The weight file itself may be ignored by Git.

Snapshot: 1,001 bytes; 9 lines.

### model/scram-operator-lora/README.md

Directory-specific setup, background or saved-model documentation. Read in context of the current source and the historical distinctions in this guide.

Snapshot: 2,240 bytes; 47 lines.

### model/scram-operator-lora/adapter_config.json

LoRA adapter/base-model metadata, including rank, target modules and scaling; required to interpret adapter weights.

Snapshot: 1,382 bytes; 55 lines.

Data structure: alora_invocation_tokens, alpha_pattern, arrow_config, auto_mapping, base_model_name_or_path, bias, corda_config, ensure_weight_tying, eva_config, exclude_modules, fan_in_fan_out, inference_mode, init_lora_weights, kasa_config, layer_replication, layers_pattern, layers_to_transform, loftq_config, lora_alpha, lora_bias, lora_dropout, lora_ga_config, megatron_config, megatron_core, modules_to_save, monteclora_config, peft_type, peft_version, qalora_group_size, r, rank_pattern, revision, target_modules, target_parameters, task_type, trainable_token_indices, use_bdlora, use_dora, use_qalora, use_rslora, velora_config.

### model/scram-operator-lora/chat_template.jinja

Model chat template translating role/content messages into the token layout expected by the base model and fine-tuning.

Snapshot: 2,559 bytes; 53 lines.

### model/scram-operator-lora/tokenizer.json

Large tokenizer vocabulary/normalizer/pretokenizer and token-ID mapping. Generated model infrastructure, not a handwritten controller; printing every token would obscure the implementation.

Snapshot: 11,422,166 bytes; 757,464 lines.

Data structure: version, truncation, padding, added_tokens, normalizer, pre_tokenizer, post_processor, decoder, model.

### model/scram-operator-lora/tokenizer_config.json

Tokenizer options, special tokens and chat-format metadata used by the model stack.

Snapshot: 4,607 bytes; 194 lines.

Data structure: add_prefix_space, backend, bos_token, clean_up_tokenization_spaces, eos_token, errors, is_local, local_files_only, model_max_length, pad_token, padding_side, split_special_tokens, tokenizer_class, unk_token, added_tokens_decoder.

### model/telemetry-classifier/README.md

Directory-specific setup, background or saved-model documentation. Read in context of the current source and the historical distinctions in this guide.

Snapshot: 2,398 bytes; 44 lines.

### model/telemetry-classifier/evaluation.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 3,237 bytes; 126 lines.

Data structure: algorithm, seed, train_n, model_bytes, extra_gpu_bytes, benchmark_fit_overlap, validation, clean_unseen, historical_unseen, historical_llm_baseline, comparison_note.

### model/telemetry-classifier/hybrid-evaluation.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 3,998 bytes; 163 lines.

Data structure: activation_policy, correction_ms_per_example, benchmark_sha256, comparison, baseline, corrected, changes.

### model/telemetry-classifier/model.json

Exported CPU forest: feature version/count, ordered class names and per-tree left/right child, feature, threshold and leaf probability arrays. Executed by TelemetryClassifier.predict().

Snapshot: 534,552 bytes; 1 lines.

Data structure: feature_version, n_features, classes, trees, training_manifest_sha256.

### model/telemetry-classifier/policy.json

Deployment enablement/integrity policy. Determines whether the corresponding CPU model is eligible to load; referenced SHA-256 values bind it to evidence.

Snapshot: 486 bytes; 13 lines.

Data structure: enabled, confidence_threshold, validation_corrections, sensor_noise_calibration, noise_candidate_passed, noise_validation_sensor_examples, noise_validation_missed_faults, validation_correction_errors, validation_false_alarms, model_sha256, scope.

### model/telemetry-physics/README.md

Directory-specific setup, background or saved-model documentation. Read in context of the current source and the historical distinctions in this guide.

Snapshot: 2,533 bytes; 49 lines.

### model/telemetry-physics/final-holdout-evaluation.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 86,478 bytes; 2,541 lines.

Data structure: freeze, holdout_sha256, score, passed_release_gate, by_kind, predictions.

### model/telemetry-physics/holdout-evaluation.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 89,674 bytes; 2,625 lines.

Data structure: freeze, holdout_sha256, score, passed_release_gate, by_kind, predictions.

### model/telemetry-physics/model.json

Exported CPU forest: feature version/count, ordered class names and per-tree left/right child, feature, threshold and leaf probability arrays. Executed by TelemetryClassifier.predict().

Snapshot: 235,914 bytes; 1 lines.

Data structure: feature_version, n_features, classes, trees, normal_below_confidence.

### model/telemetry-physics/policy.json

Deployment enablement/integrity policy. Determines whether the corresponding CPU model is eligible to load; referenced SHA-256 values bind it to evidence.

Snapshot: 659 bytes; 19 lines.

Data structure: enabled, model_sha256, features_sha256, validation_sha256, criteria, selection_used_holdout, report_sha256, advisory_only.

### model/telemetry-physics/validation.json

Saved evaluation or experiment data. Read its schema and producing script to distinguish scores, per-example predictions and timeline samples; values are historical evidence.

Snapshot: 10,764 bytes; 386 lines.

Data structure: selection, fit_n, native_training_windows_added, feature_count, validation_gate_passed, selected, trials, model_sha256, model_bytes.

### model/train_log.json

Saved training configuration, loss history and resource/quality metrics. Describes a historical training run, not a fresh check of this machine.

Snapshot: 9,993 bytes; 362 lines.

Data structure: base, lora_r, max_seq, batch, grad_accum, epochs, lr, train_examples, val_examples, train_loss, final_eval_loss, runtime_s, peak_vram_gb, history.

### monitor/__init__.py

Package initializer. Establishes the import namespace; inspect any exports below. An empty initializer contains no control logic.

Snapshot: 0 bytes; 0 lines.

### monitor/behavior_monitor.py

Measured-only bounds, rate, target-step and stale-sensor checks. Its flag stream is diagnostic; it does not own an actuator.

Snapshot: 10,211 bytes; 204 lines.

Dependencies: import time; from collections import deque; from dataclasses import dataclass; from typing import Callable, Deque, List, Optional; import sys; import os; from contracts import PlantState, SupervisoryTargets.

- MonitorLimits (L41-71): Structural note: Class (no explicit base class). Declared data: pressure_max_kpa, level_low_pct, level_high_pct, max_pressure_rate_kpa, max_setpoint_step_kpa, staleness_window, staleness_pressure_eps_kpa, staleness_valve_move_pct, max_level_rate_pct, staleness_level_eps_pct.

- BehaviorMonitor (L74-204): Source docstring: Stateful, one instance per run. Call observe() once per cycle.

- BehaviorMonitor.__init__ (L77-102): Structural note: Updates self.limits, self._clock, self._settle_until, self.flag_count, self._cycle, w, self.level_stale_evaluated, self.level_stale_flagged.

- BehaviorMonitor.arm_settling (L104-109): Source docstring: Bounded grace after an operator re-arm / plant restart: the sim's level reading is legitimately flat while it settles, so the staleness (frozen-sensor) flags are suppressed for `seconds`. Thresholds and windows are unchanged; every other check stays live.

- BehaviorMonitor.settling (L112-113): Structural note: Returns self._clock() < self._settle_until.

- BehaviorMonitor.ever_flagged (L116-117): Structural note: Returns bool(self.flags).

- BehaviorMonitor.observe (L119-204): Source docstring: One cycle. Returns the (possibly empty) list of flags raised now.

### monitor/governance.py

Debounces rule/proposal evidence and turns it into a rate-limited authority ceiling with a nonzero floor and conditional recovery.

Snapshot: 9,170 bytes; 183 lines.

Dependencies: from dataclasses import dataclass; from typing import Optional; from l3_brain.prompt_format import DESIGN_POINT.

- ceiling (L68-77): Source docstring: g(s): corroborated suspicion -> authority ceiling.

- in_envelope (L80-88): Source docstring: True when the proposal is back near design; a hold (None) counts as inside.

- GovState (L92-105): Structural note: Class (no explicit base class). Declared data: t, raw, corroborated, label, ceiling, applied, recovering, envelope_ok.

- GovState.as_dict (L102-105): Structural note: Returns {'t': round(self.t, 2), 'raw': round(self.raw, 3), 'corroborated': round(self.corroborated, 3), '....

- Governor (L108-183): Structural note: Class (no explicit base class). Groups related methods/state.

- Governor.__init__ (L109-110): Structural note: Key operations: self.reset.

- Governor.reset (L112-124): Structural note: Updates self.applied, (self._obs_corr, self._obs_label), (self._rule_corr, self._rule_label), self._rule_sample_t.

- Governor._observer (L126-140): Source docstring: One observer call = one new proposals verdict (invalid ones are skipped).

- Governor._rule (L142-156): Structural note: Updates (dt, self._rule_sample_t), (self._rule_eff, self._rule_raw_prev), self._rule_prev.

- Governor.update (L158-183): Structural note: Returns self.last.

### monitor/observer.py

Background model observer and split-role router, with stale-evidence expiry, reset generation guards, independent fallback chains and telemetry-only specialist correction.

Snapshot: 18,028 bytes; 336 lines.

Dependencies: import json; import threading; import time; import urllib.request; from collections import deque; from dataclasses import dataclass; from typing import Callable, Deque, Optional; from l3_brain.prompt_format import measured_dict; from monitor import observer_v2_format as V2; from monitor import observer_v3_format as V3.

- Verdict (L70-84): Structural note: Class (no explicit base class). Declared data: t, kind, label, score, reason, note, latency_s, source, llm_label.

- Verdict.as_dict (L81-84): Structural note: Returns {'t': round(self.t, 1), 'kind': self.kind, 'label': self.label, 'score': round(self.score, 2), 'r....

- _http_post_json (L87-90): Structural note: Returns json.loads(r.read()). Key operations: urllib.request.Request, urllib.request.urlopen, r.read.

- observer_available (L93-99): Structural note: Returns model in names or f'{model}:latest' in names; False. Key operations: urllib.request.urlopen, json.loads(r.read()).get, r.read.

- Observer (L102-254): Source docstring: One model serving one or both input types (`kinds`).

- Observer.__init__ (L105-130): Structural note: Key operations: threading.Lock, threading.Semaphore.

- Observer.reset (L133-145): Source docstring: Forget history (e.g. after an operator re-arm) and drop old verdicts.

- Observer.feed (L147-168): Source docstring: Call once per control cycle; never blocks on the model. commanded: the ControlCommand whose result `state` is (L1's last signed command); a TELEMETRY_COMMANDED format takes no sample until there is one.

- Observer._maybe_check (L170-201): Structural note: Key operations: threading.Thread(target=self._run, args=(t, kind, user, generation), daemon=True).start, threading.Thread.

- Observer._run (L204-239): Structural note: Key operations: self._http_post.

- Observer.suspicion (L242-248): Source docstring: Advisory suspicion for Keel: proposal-side labels only (see module docstring).

- Observer.snapshot (L250-254): Structural note: Returns {'model': self.model, 'calls': self.calls, 'failures': self.failures, 'suspicion': round(self.sus....

- _first_installed (L257-258): Structural note: Returns next(((f, m, c) for f, m, c in chain if m not in skip and available(m)), None).

- SplitObserver (L261-330): Source docstring: Proposals and telemetry served by separate models (module docstring). Same interface the engine uses for a single Observer: feed / suspicion / last / reset / snapshot, plus fallback() for the per-path chains.

- SplitObserver.__init__ (L269-274): Structural note: Key operations: threading.Semaphore.

- SplitObserver._build (L276-283): Structural note: Returns Observer(fmt=fmt, model=model, num_ctx=num_ctx, kinds=(kind,), telemetry_specialist=self.telemetr...; None.

- SplitObserver.available (L286-287): Structural note: Returns any(self.paths.values()).

- SplitObserver.model (L289-290): Structural note: Returns self.paths[kind].model if self.paths[kind] else None.

- SplitObserver.feed (L292-295): Structural note: Coordinates the statements shown in the source companion.

- SplitObserver.last (L298-299): Structural note: Returns {k: o.last[k] for k, o in self.paths.items() if o is not None and k in o.last}.

- SplitObserver.suspicion (L301-304): Source docstring: Proposal path only: telemetry verdicts never reach authority.

- SplitObserver.reset (L306-309): Structural note: Key operations: o.reset.

- SplitObserver.fallback (L311-320): Source docstring: Move each path whose model keeps erroring down its own chain; returns (kind, failed model, new model or None) for every switch made.

- SplitObserver.snapshot (L322-330): Structural note: Returns {'models': {k: self.model(k) for k in KINDS}, 'telemetry_specialist': self.telemetry_specialist i....

- make_split_observer (L333-336): Source docstring: Proposals -> v2, telemetry -> v3 (each with its fallback chain); None if no model is installed.

### monitor/observer_v2_format.py

Exact v2 chat/telemetry/proposal schema and verdict parser. Proposal formatting is reused by v3; tests verify parity with saved examples.

Snapshot: 6,395 bytes; 94 lines.

Dependencies: import json; import math; from typing import Optional, Sequence, Tuple.

- _r (L39-40): Structural note: Returns None if x is None else round(x, nd).

- telemetry_to_json (L43-51): Source docstring: samples: the last WINDOW_N measured dicts, oldest first (pressure, level, flows, a_in_purge as a mole fraction, valve positions, scrammed). window_s: seconds from the first sample to the last.

- proposal_dict (L54-57): Source docstring: One proposal: setpoints (SupervisoryTargets or dict; None = hold) + tag + rationale.

- proposals_to_json (L60-62): Source docstring: proposals: the last HISTORY_N proposal_dict()s, oldest first.

- messages (L65-66): Structural note: Returns [{'role': 'system', 'content': SYSTEM_PROMPT}, {'role': 'user', 'content': user}].

- parse (L69-94): Source docstring: Model output -> ({label, score, reason}, "ok") or (None, why). Tolerates a fenced reply or text around the object (same extraction as the operator's l3_brain.policy.parse_llm_targets); rejects unknown labels and non-numbers, clamps score to [0, 1].

### monitor/observer_v3_format.py

Longer measured telemetry windows with all flows and command/position pairs. Shares proposal format/labels with v2.

Snapshot: 4,202 bytes; 84 lines.

Dependencies: import json; from typing import Optional, Sequence; from monitor import observer_v2_format as V2.

- _r (L53-54): Structural note: Returns None if x is None else round(x, nd).

- telemetry_to_json (L57-69): Source docstring: samples: the last WINDOW_N measured dicts, oldest first (pressure, level, the four flows, a_in_purge as a mole fraction, <valve>_valve_pos, scrammed). commanded: the matching {f1, f2, purge, product} positions L1 sent. window_s: first -> last sample.

- messages (L72-76): Structural note: Returns m.

- verdict_to_json (L79-84): Source docstring: Same key order and score convention as v2's stored assistant turns.

### monitor/physics_detector.py

Checks enabled policy, release-gate result and evidence hashes, then uses the physics forest to correct advisory telemetry while retaining llm_label.

Snapshot: 1,689 bytes; 46 lines.

Dependencies: import hashlib; import json; from pathlib import Path; from monitor.telemetry_classifier import TelemetryClassifier.

- PhysicsDetector (L13-20): Structural note: Class (TelemetryClassifier). Groups related methods/state.

- PhysicsDetector.correct (L14-20): Structural note: Returns {**candidate, 'source': 'llm+physics-detector', 'llm_label': verdict.get('label')}. Key operations: self.predict.

- approved_physics_detector (L23-46): Structural note: Returns PhysicsDetector(DEST / 'model.json'); None. Key operations: policy_path.read_text, report_path.read_text, hashlib.sha256(path.read_bytes()).hexdigest, path.read_bytes.

### monitor/physics_features.py

Measured process-consistency features: command/position gaps, valve/flow residuals, species/inventory balances, quantization tolerances and pressure trends.

Snapshot: 5,688 bytes; 150 lines.

Dependencies: import math; from monitor.telemetry_classifier import _stats; from monitor.telemetry_classifier import features as validate_window.

- _average (L16-17): Structural note: Returns (0.5 * xs[0] + sum(xs[1:-1]) + 0.5 * xs[-1]) / (len(xs) - 1).

- _balances (L20-69): Structural note: Returns [interval_distance(nv_rate + 2 * nl_rate, total_flux, total_error), interval_distance(a_rate + nl...; max(0.0, low - observed, observed - high) / scale.

- _balances.interval_distance (L47-56): Structural note: Returns max(0.0, low - observed, observed - high) / scale.

- physics_features (L72-150): Structural note: Returns output. Key operations: math.copysign.

### monitor/sequential_monitor.py

Accumulated proposal drift, directional runs, lexical rationale screening and Keel-event corroboration. Audits intent before authority blending.

Snapshot: 8,052 bytes; 175 lines.

Dependencies: import re; from collections import deque; from dataclasses import dataclass; from typing import Deque, Dict, Iterable, List, Optional, Tuple; from contracts import PlantState, SupervisoryTargets.

- Suspicion (L59-66): Structural note: Class (no explicit base class). Declared data: t, score, reason, source.

- Suspicion.as_dict (L65-66): Structural note: Returns {'t': self.t, 'score': round(self.score, 3), 'reason': self.reason, 'source': self.source}.

- _Chan (L70-78): Structural note: Class (no explicit base class). Declared data: k, h, eps, last, s_pos, s_neg, run_sign, run_len.

- SequentialMonitor (L81-175): Structural note: Class (no explicit base class). Groups related methods/state.

- SequentialMonitor.__init__ (L82-93): Structural note: Updates (self.leak, self.run_alarm, self.min_run), self.decay_half_life_s, self.ch, self._pat.

- SequentialMonitor.observe (L95-154): Source docstring: One cycle. `state` is accepted for interface symmetry / future measured-only detectors; the current detectors use the targets.

- SequentialMonitor.reset_channel (L156-160): Source docstring: Call after a human-approved setpoint change so legitimate intent doesn't linger.

- SequentialMonitor.reset_all (L162-169): Source docstring: Clear every channel's CUSUM and run state (e.g. after an operator re-arm). Also forget the last setpoint: with `baseline` (e.g. the design setpoints) the next setpoint is measured from it, otherwise it becomes a fresh baseline rather than a 'move' from the pre-trip value.

- SequentialMonitor._rationale (L171-175): Structural note: Returns (min(1.0, sum((w for w, _ in hits))), f'rationale matches {len(hits)} injection pattern(s)'); (0.0, '').

### monitor/telemetry_classifier.py

Input validation, statistical features and exported-tree inference. Old correction preserves existing alarms; approved_specialist prefers the release-gated physics detector.

Snapshot: 5,728 bytes; 121 lines.

Dependencies: import hashlib; import json; import math; from itertools import pairwise; from pathlib import Path.

- _stats (L21-29): Structural note: Returns [xs[0], xs[-1], mean, min(xs), max(xs), max(xs) - min(xs), math.sqrt(variance), xs[-1] - xs[0], m....

- features (L32-61): Structural note: Returns values.

- TelemetryClassifier (L64-102): Structural note: Class (no explicit base class). Groups related methods/state.

- TelemetryClassifier.__init__ (L65-68): Structural note: Key operations: path.read_text.

- TelemetryClassifier.predict (L70-90): Structural note: Returns {'label': label, 'confidence': round(probabilities[index], 4), 'score': round(1 - probabilities[s....

- TelemetryClassifier.correct (L92-102): Source docstring: Only add a confident fault finding to an otherwise normal LLM verdict. Existing alarms are preserved. This never changes proposal evidence or authority.

- approved_specialist (L105-120): Structural note: Returns TelemetryClassifier(); physics; None. Key operations: policy.read_text, hashlib.sha256(DEFAULT_MODEL.read_bytes()).hexdigest, DEFAULT_MODEL.read_bytes.

### packaging/build-simulation-deb.sh

Compiles the local simulator, stages web/service files, substitutes a Git-derived version and builds the Debian package. Separate from active Compose.

Snapshot: 2,772 bytes; 80 lines.

### packaging/simulation/DEBIAN/control

Debian package metadata and dependency declarations.

Snapshot: 438 bytes; 10 lines.

### packaging/simulation/DEBIAN/postinst

Debian package lifecycle shell hook, enabling/starting or stopping/removing services as appropriate.

Snapshot: 717 bytes; 23 lines.

### packaging/simulation/DEBIAN/prerm

Debian package lifecycle shell hook, enabling/starting or stopping/removing services as appropriate.

Snapshot: 448 bytes; 12 lines.

### packaging/simulation/nginx/grfics-simulation

Nginx site configuration for the Debian/VM visualization and PHP route.

Snapshot: 327 bytes; 17 lines.

### packaging/simulation/systemd/grfics-modbus.service

Debian/VM systemd unit declaring service startup, dependencies and restart behavior for the named simulator/Modbus/init service.

Snapshot: 292 bytes; 14 lines.

### packaging/simulation/systemd/grfics-simulation-init.service

Debian/VM systemd unit declaring service startup, dependencies and restart behavior for the named simulator/Modbus/init service.

Snapshot: 245 bytes; 12 lines.

### packaging/simulation/systemd/grfics-simulation.service

Debian/VM systemd unit declaring service startup, dependencies and restart behavior for the named simulator/Modbus/init service.

Snapshot: 281 bytes; 13 lines.

### packaging/simulation/usr/lib/grfics/simulation-init.sh

Debian/VM initialization support, including network aliases/routing used by inherited Modbus devices; separate from the Python live application.

Snapshot: 821 bytes; 21 lines.

### packaging/simulation/www/vm-overlay.js

VM-oriented web overlay injected during Debian packaging; adapts inherited visualization presentation.

Snapshot: 934 bytes; 24 lines.

### pytest.ini

Pytest discovery and execution configuration; distinguish the explicitly excluded live integration tests when running offline.

Snapshot: 27 bytes; 2 lines.

### reference/sim_cpp_unused/README.md

Historical shelved simulator/reference material. Not wired into root Compose or python -m live. Compare against the active local source only when investigating project history.

Snapshot: 755 bytes; 14 lines.

### reference/sim_cpp_unused/TE_process.cc

Historical shelved simulator/reference material. Not wired into root Compose or python -m live. Compare against the active local source only when investigating project history.

Snapshot: 24,946 bytes; 629 lines.

Code landmarks: L88: TE::TE() {; L156: void TE::steady_state() {; L225: void TE::update(Json::Value inputs) {; L539: void TE::print_outputs() {; L561: Json::Value TE::get_state_json() {.

### reference/sim_cpp_unused/TE_process.h

Historical shelved simulator/reference material. Not wired into root Compose or python -m live. Compare against the active local source only when investigating project history.

Snapshot: 5,083 bytes; 132 lines.

### reference/sim_cpp_unused/main.cc

Historical shelved simulator/reference material. Not wired into root Compose or python -m live. Compare against the active local source only when investigating project history.

Snapshot: 7,773 bytes; 237 lines.

### reference/sim_cpp_unused/makefile

Historical shelved simulator/reference material. Not wired into root Compose or python -m live. Compare against the active local source only when investigating project history.

Snapshot: 105 bytes; 2 lines.

### requirements-dev.txt

Runtime plus test/lint dependencies. Browser packages are installed separately in the CI workflow.

Snapshot: 61 bytes; 4 lines.

### requirements-eval.txt

Numpy/scikit-learn dependencies for CPU training/evaluation; the exported model runtime avoids them.

Snapshot: 131 bytes; 3 lines.

### requirements-train.txt

GPU fine-tuning dependencies; separate from ordinary app requirements and from the CPU evaluation stack.

Snapshot: 277 bytes; 9 lines.

### requirements.txt

Pinned runtime Python dependencies for FastAPI, Uvicorn and Pydantic; most control-layer code uses the standard library.

Snapshot: 265 bytes; 8 lines.

### run_demo.py

Minimal historical end-to-end entry point wiring baseline L3, L1 stub and L0. It is not the full live control room.

Snapshot: 3,696 bytes; 90 lines.

Dependencies: import time; from l0_plant.plant_service import PlantService; from l3_brain.operator import AIOperator; from l1_stub import L1ControlStub; from scripts.reset_plant import reset_and_settle.

- main (L35-86): Structural note: Key operations: PlantService().start, reset_and_settle, plant.read, l1.regulate, plant.apply.

### scripts/__init__.py

Package initializer. Establishes the import namespace; inspect any exports below. An empty initializer contains no control logic.

Snapshot: 0 bytes; 0 lines.

### scripts/check_simulator.py

Starts a separate local compiled simulator on a free port and checks protocol/validation; does not use the normal application plant.

Snapshot: 2,740 bytes; 67 lines.

Dependencies: import json; import os; import socket; import subprocess; import sys; import time; from pathlib import Path.

- main (L15-63): Structural note: Key operations: subprocess.Popen, stream.readline.

### scripts/collect_accuracy_holdout.py

Collects isolated accelerated simulator trajectories, constructs measured windows and records native versus synthetic fault provenance in sealed holdout evidence.

Snapshot: 11,731 bytes; 343 lines.

Dependencies: import argparse; import hashlib; import json; import os; import random; import socket; import subprocess; import time; from pathlib import Path; from monitor import observer_v3_format as F; from training import build_observer_dataset as B.

- IsolatedPlant (L24-76): Structural note: Class (no explicit base class). Groups related methods/state.

- IsolatedPlant.__init__ (L25-45): Structural note: Key operations: subprocess.Popen.

- IsolatedPlant.write (L47-64): Structural note: Returns json.loads(self.file.readline()). Key operations: self.file.write, (json.dumps({'request': 'write', 'data': {'inputs': {**{f'{v}_valve_sp': x for v, x in valves.items()}, **(faults or {})}}}) + '\n').encode, self.file.readline.

- IsolatedPlant.close (L66-76): Structural note: Coordinates the statements shown in the source companion.

- window (L79-143): Structural note: Returns json.loads(F.telemetry_to_json(measured, cmd, duration)). Key operations: plant.write.

- collect (L146-325): Structural note: Key operations: destination.write_text, destination.with_suffix('.manifest.json').write_text.

- collect.add (L150-160): Structural note: Updates user.

### scripts/demo_authority.py

Reads one live snapshot and demonstrates authority 1, 0.5 and 0 without driving the plant.

Snapshot: 1,573 bytes; 46 lines.

Dependencies: from l0_plant.plant_service import PlantService; from l3_brain.operator import AIOperator.

- show (L20-30): Structural note: Updates op, targets.

- main (L33-42): Structural note: Key operations: PlantService().start, plant.read.

### scripts/reset_plant.py

Restarts the simulator, waits for connectivity, applies the corrected 0.3926% design purge and confirms stable pressure/level. A reset is an active state-changing operation.

Snapshot: 9,555 bytes; 230 lines.

Dependencies: import argparse; import math; import socket; import subprocess; import sys; import time; from dataclasses import dataclass; from pathlib import Path; from typing import Optional.

- SettledPoint (L61-71): Structural note: Class (no explicit base class). Declared data: pressure, level, product_flow, f1_valve_pos, f2_valve_pos, purge_valve_pos, product_valve_pos, cycles_to_settle, pressure_range, level_range.

- restart_container (L74-79): Source docstring: `docker compose restart <service>`. Raises on failure.

- wait_reachable (L82-93): Source docstring: Block until the simulator accepts a TCP connection, or raise TimeoutError.

- wait_settled (L96-167): Source docstring: Poll read-only (sends no writes, so it doesn't disturb whatever it's measuring) until pressure and level have both stayed within tolerance for `stable_cycles` consecutive reads, or raise TimeoutError.

- wait_settled.read_once (L109-122): Source docstring: One request on a fresh connection; None on any transient failure (reconnecting after a restart can race the container coming up).

- set_design_purge (L170-192): Source docstring: Write the corrected design purge opening (see DESIGN_PURGE_VALVE_PCT) and confirm the simulator reports it. Retries: right after a restart Docker's port proxy accepts connections before the simulator inside is listening, and drops what is sent.

- reset_and_settle (L195-202): Source docstring: Restart the simulator, apply the corrected design purge, wait until settled.

- main (L205-226): Structural note: Returns 0; 1. Key operations: reset_and_settle.

### scripts/review_findings.py

Focused regression probes for previously fixed behavior using fakes; related assertions are in quality-hardening tests.

Snapshot: 2,246 bytes; 62 lines.

Dependencies: import json; import threading; from dataclasses import replace; from fastapi import HTTPException; from contracts import ControlCommand; from l0_plant.provenance_gate import CommandSigner, ProvenanceGate; from l0_plant.safety import SafeHold, SafetyInterlock; from monitor.observer import Observer; from sim_app.server import Plant.

- main (L18-58): Structural note: Returns {'message': {'content': json.dumps({'label': 'rationale_mismatch', 'score': 0.9, 'reason': 'old r...; {'state': {'e_stop': inputs.get('e_stop', 0)}, 'outputs': {'pressure': 2700, 'liquid_level': 45}}. Key operations: sis.evaluate, threading.Thread, worker.start, obs.reset, CommandSigner(key).sign, threading.Event, CommandSigner.

- main.FakeClient (L28-30): Structural note: Class (no explicit base class). Groups related methods/state.

- main.FakeClient.write_inputs (L29-30): Structural note: Returns {'state': {'e_stop': inputs.get('e_stop', 0)}, 'outputs': {'pressure': 2700, 'liquid_level': 45}}.

- main.post (L39-42): Structural note: Returns {'message': {'content': json.dumps({'label': 'rationale_mismatch', 'score': 0.9, 'reason': 'old r....

### sim_app/README.md

Directory-specific setup, background or saved-model documentation. Read in context of the current source and the historical distinctions in this guide.

Snapshot: 6,914 bytes; 91 lines.

### sim_app/__init__.py

Package initializer. Establishes the import namespace; inspect any exports below. An empty initializer contains no control logic.

Snapshot: 71 bytes; 1 lines.

Source documentation: Clean TE reactor operator sim (no interlock): python -m sim_app.

### sim_app/__main__.py

Manual studio entry point on port 8770; checks/starts the simulator and launches the separate FastAPI app.

Snapshot: 1,521 bytes; 49 lines.

Dependencies: import argparse; import socket; import subprocess; import threading; import time; import webbrowser; from pathlib import Path; import uvicorn.

- plant_up (L18-23): Structural note: Returns True; False.

- main (L26-45): Structural note: Returns 0; 1. Key operations: threading.Timer(1.5, webbrowser.open, args=(url,)).start, threading.Timer.

### sim_app/ai.py

Grounded multi-action command parser plus a separate trained-operator rescue controller. Run identity and cancellation guards prevent late writes after stop/E-stop.

Snapshot: 26,631 bytes; 484 lines.

Dependencies: import json; import math; import re; import threading; import time; import urllib.request; from collections import deque; from typing import Callable, Optional; from contracts import PlantState, SupervisoryTargets; from l3_brain.policy import OllamaOperator; from l3_brain.prompt_format import DESIGN_POINT; from scripts.reset_plant import DESIGN_PURGE_VALVE_PCT.

- _direction (L89-93): Source docstring: +1 / -1 if the sentence only uses opening / closing words, 0 if it uses both or neither (e.g. "open the purge to lower the pressure": the goal is not the valve).

- _post (L96-99): Structural note: Returns json.loads(r.read()). Key operations: urllib.request.Request, urllib.request.urlopen, r.read.

- _check (L102-134): Source docstring: Validate one parsed action and settle what a 1.5B model mixes up, using the words of its own clause: "to/at N" = set, "by N" = adjust, and the sign of an adjust when the clause only uses opening or only closing words. Returns (action, valve, amount, corrections).

- _ask (L137-145): Structural note: Returns ((resp.get('message') or {}).get('content', ''), round(time.monotonic() - t0, 2)). Key operations: post.

- parse_command (L148-158): Source docstring: Plain English -> ONE action {action, valve, amount, model_output, corrections, latency_s}.

- _ground_action (L209-218): Source docstring: An actuator must be explicitly named by the user, never supplied by the model.

- _clause_for (L221-233): Source docstring: The words to grammar-check an action against: the model's clause if it is really part of the command, else the command segment that names this valve; with a single action, the whole command.

- parse_commands (L236-272): Source docstring: Plain English -> several actions, in order: {actions: [{clause, action, valve, amount, corrections}], model_output, latency_s}.

- _clamp (L289-290): Structural note: Returns max(0.0, min(100.0, v)).

- regulate (L293-312): Source docstring: Setpoints -> valve positions (absolute %). None = the model holds.

- plant_state (L315-325): Structural note: Returns PlantState(pressure=m.get('pressure', 0.0), level=m.get('liquid_level', 0.0), f1_flow=m.get('f1_f....

- Activity (L328-341): Source docstring: Bounded feed of what the AI did, read by the page.

- Activity.__init__ (L331-332): Structural note: Key operations: threading.Lock.

- Activity.add (L334-337): Structural note: Coordinates the statements shown in the source companion.

- Activity.since (L339-341): Structural note: Returns [x for x in self.items if x['id'] > i].

- Rescue (L344-484): Source docstring: Closed loop: trained model -> regulate() -> valves, every TICK_S. Each engagement gets its own stop event and run id, so a quick Stop -> Save cannot leave an old loop running beside the new one, and an old loop can never change the state of a newer one when it exits.

- Rescue.__init__ (L351-357): Structural note: Key operations: threading.Lock, threading.RLock.

- Rescue.start (L359-367): Structural note: Key operations: threading.Thread(target=self._run, args=(run_id, stop), name=f'ai-rescue-{run_id}', daemon=True).start, threading.Event, threading.Thread.

- Rescue.stop (L369-376): Structural note: Coordinates the statements shown in the source companion.

- Rescue._apply (L378-383): Structural note: Returns True; False. Key operations: self.plant.apply_valves.

- Rescue._finish (L385-391): Source docstring: End this run, unless it was already stopped or superseded by a newer run.

- Rescue._run (L393-484): Structural note: Key operations: regulate, self.plant.read, outcome.startswith, self._apply.

### sim_app/server.py

Direct-control Plant and FastAPI routes, serialized actuation, polling, rupture/E-stop latches, reset and command/rescue coordination.

Snapshot: 17,665 bytes; 409 lines.

Dependencies: import math; import threading; from contextlib import asynccontextmanager; from functools import wraps; import time; from collections import deque; from pathlib import Path; from typing import Literal, Optional; from fastapi import FastAPI, HTTPException; from fastapi.responses import FileResponse; from fastapi.staticfiles import StaticFiles; from pydantic import BaseModel, model_validator; from l0_plant.grfics_client import GrficsClient; from scripts.reset_plant import reset_and_settle; from sim_app.ai import Activity, Rescue, parse_commands.

- _num (L55-61): Source docstring: A plant reading as a float; null/missing/non-finite reads as 0.0.

- _serialized (L65-70): Structural note: Returns guarded; fn(self, *args, **kwargs).

- _serialized.guarded (L67-69): Structural note: Returns fn(self, *args, **kwargs).

- Plant (L73-280): Source docstring: Owns the simulator connection, the trend history and the rupture latch.

- Plant.__init__ (L76-95): Structural note: Key operations: threading.Lock, threading.RLock, threading.Event.

- Plant._txn (L98-108): Structural note: Returns fn(self._client).

- Plant.read (L110-111): Structural note: Returns self._txn(lambda c: c.read()). Key operations: c.read.

- Plant.write (L113-114): Structural note: Returns self._txn(lambda c: c.write_inputs(inputs)). Key operations: c.write_inputs.

- Plant._clear_rupture (L117-118): Structural note: Updates (self.ruptured, self.ruptured_t, self.rupture_pressure, self.peak_p....

- Plant.start (L121-127): Structural note: Returns self. Key operations: threading.Thread, self._poll_thread.start, self._poll_thread.is_alive.

- Plant.stop (L129-138): Structural note: Key operations: self._poll_thread.join.

- Plant._poll (L140-151): Structural note: Key operations: self.read, self.write.

- Plant._ingest (L153-170): Structural note: Updates (o, s), t, p.

- Plant.snapshot (L173-193): Structural note: Returns {'connected': self.connected, 'resetting': self.resetting, 't': round(time.monotonic() - self.t0,....

- Plant._check_writable (L195-204): Structural note: Coordinates the statements shown in the source companion.

- Plant.apply_valves (L207-216): Source docstring: Write several valve setpoints at once (clamped to 0-100).

- Plant.manipulate (L219-252): Structural note: Returns {'variable': variable, 'setpoint': new}; {'variable': 'e_stop', 'value': on}. Key operations: self.write.

- Plant.reset (L254-280): Structural note: Returns {'pressure': point.pressure, 'level': point.level, 'cycles_to_settle': point.cycles_to_settle}. Key operations: self._reset_lock.acquire, reset_and_settle, self._reset_lock.release, self.write, self.read.

- Manipulation (L283-294): Structural note: Class (BaseModel). Declared data: variable, delta, value.

- Manipulation.one_of (L289-294): Structural note: Returns self.

- lifespan (L301-306): Structural note: Key operations: plant.start.

- get_state (L313-315): Structural note: Returns {**plant.snapshot(since), 'ai': {'active': plant.rescue.active, 'activity': plant.activity.since(....

- manipulate (L319-320): Structural note: Returns plant.manipulate(m.variable, m.delta, m.value). Key operations: app.post.

- Command (L323-324): Structural note: Class (BaseModel). Declared data: text.

- command (L328-372): Source docstring: Plain English -> one or more actions (stock qwen2.5:1.5b), applied in the order given, each exactly like a manual move. Each action's outcome is reported on its own; one refused action does not stop the others.

- rescue (L376-380): Structural note: Returns {'active': True}. Key operations: app.post, plant.rescue.start.

- stop_ai (L384-386): Structural note: Returns {'active': False}. Key operations: app.post.

- reset (L390-391): Structural note: Returns plant.reset(). Key operations: app.post, plant.reset.

- index (L398-399): Structural note: Returns FileResponse(STATIC / 'index.html', headers=NO_CACHE).

- _FrontendFiles (L402-406): Structural note: Class (StaticFiles). Groups related methods/state.

- _FrontendFiles.get_response (L403-406): Structural note: Returns response.

### sim_app/static/app.js

Manual studio browser client: polling, gauge/valve widgets, activity-to-card conversion, charts, command queue, rescue/E-stop/reset controls and 3D sizing.

Snapshot: 26,375 bytes; 572 lines.

Code landmarks: L77: // ---------- helpers; L94: function fmt(v, digits = 1) {; L98: function fmtClock(/** @type {number} */ secs) {; L111: function zone(p, ruptured) {; L119: // ---------- page state; L131: // ---------- requests; L134: async function fetchWithTimeout(url, init = {}) {; L142: async function post(/** @type {string} */ url, /** @type {object} */ body = {}) {; L155: function toast(/** @type {string} */ msg, isError = false) {; L164: async function move(body) {; L174: // ---------- static DOM (gauge, valves, legend); L179: function buildGauge() {; L204: function buildValves() {; L227: function buildLegend() {; L231: // ---------- AI feed (backend activity -> decision cards); L234: function moves(v) {; L241: function trend() {; L248: function truthLine(/** @type {Activity} */ a) {; L254: function toFeed(a) {; L274: function renderFeed() {; L288: // ---------- render off the backend state; L290: function render() {; L358: // ---------- charts; L361: function setup(/** @type {HTMLCanvasElement} */ c) {; L376: function drawSeries(x, data, X, Y, color, fillTo) {; L388: function drawGraphs() {; L438: // ---------- 3D display: GRFICS rendered at desktop size, scaled to fill the screen,; L441: function fitView() {; L449: // ---------- events; L451: function wireEvents() {; L515: function sendLabel() {; L518: async function runQueue() {; L531: // ---------- poll; L533: async function poll() {.

### sim_app/static/index.html

Manual studio page structure, controls, status/AI panes and embedded visualization, bound by app.js.

Snapshot: 4,202 bytes; 101 lines.

Code landmarks: L27: <section class="studio-heading"><div><span class="studio-eyebrow">WORKSPACE / MANUAL OPERATIONS</span><h1>Reactor studio</h1><p...; L30: <section class="card view">; L45: <section class="card hero">; L58: <section class="card valves">; L65: <section class="card ai">; L78: <section class="card graphs">; L99: <script src="/static/app.js"></script>.

### sim_app/static/nocturne.css

Presentation stylesheet: layout, typography, color, component states and responsive rules. It does not make control decisions. Cascade/load order in the matching HTML determines overrides.

Snapshot: 5,826 bytes; 19 lines.

### sim_app/static/style.css

Presentation stylesheet: layout, typography, color, component states and responsive rules. It does not make control decisions. Cascade/load order in the matching HTML determines overrides.

Snapshot: 14,118 bytes; 206 lines.

### sim_app/static/tsconfig.json

Static JavaScript/JSDoc type-checking options for the studio frontend; no generated application bundle is required.

Snapshot: 371 bytes; 14 lines.

### sim_app/static/workspace.css

Presentation stylesheet: layout, typography, color, component states and responsive rules. It does not make control decisions. Cascade/load order in the matching HTML determines overrides.

Snapshot: 10,650 bytes; 26 lines.

### simulation/Dockerfile

Alternative local two-stage image build with C++ compilation, web assets, PHP/nginx, supervisor and Modbus dependencies. Not used by root Compose.

Snapshot: 2,576 bytes; 85 lines.

### simulation/README.md

Directory-specific setup, background or saved-model documentation. Read in context of the current source and the historical distinctions in this guide.

Snapshot: 2,304 bytes; 51 lines.

### simulation/entrypoint.sh

Image bootstrap: detects the plant subnet interface, creates network aliases/routes and starts the supplied service command.

Snapshot: 1,570 bytes; 41 lines.

### simulation/interfaces

Container network-interface configuration for the inherited GRFICS subnet/aliases.

Snapshot: 381 bytes; 12 lines.

### simulation/nginx_config

Nginx web/PHP configuration for inherited visualization endpoints.

Snapshot: 2,418 bytes; 73 lines.

### simulation/simulation/TE_process.cc

Basic local reactor implementation: LAPACK steady-state solution, wall-clock Euler integration, species balances, pressure/flow equations, E-stop and JSON outputs. Does not supply the deployed measured/fault channel.

Snapshot: 9,419 bytes; 303 lines.

Code landmarks: L11: TE::TE() {; L36: void TE::steady_state() {; L107: void TE::update(Json::Value inputs) {; L253: void TE::print_outputs() {; L275: Json::Value TE::get_state_json() {.

### simulation/simulation/TE_process.h

TE class declarations: process parameters, inventories, derivatives, valve feedback, measurements, clocks and public lifecycle/state methods.

Snapshot: 2,707 bytes; 75 lines.

### simulation/simulation/main.cc

C++ TCP service using select(), per-client newline buffers, JSON request validation, bounded frames and complete-response sending. Supports isolated test-port override.

Snapshot: 9,530 bytes; 261 lines.

### simulation/simulation/makefile

C++ build rules selecting sources, compiler and link libraries. Building here does not replace the binary inside root Compose automatically.

Snapshot: 105 bytes; 2 lines.

### simulation/simulation/remote_io/modbus/analyzer.py

Inherited remote-I/O device adapter: maps the named process signal/actuator between simulator JSON and scaled Modbus registers. Disabled as a competing writer by the current simulator-only supervisor override.

Snapshot: 786 bytes; 21 lines.

Dependencies: import asyncio; import json; import modbusdevice.

- handleanalyzer (L5-17): Structural note: Key operations: modbusdevice.readData.

### simulation/simulation/remote_io/modbus/feed1.py

Inherited remote-I/O device adapter: maps the named process signal/actuator between simulator JSON and scaled Modbus registers. Disabled as a competing writer by the current simulator-only supervisor override.

Snapshot: 934 bytes; 29 lines.

Dependencies: import asyncio; import json; import modbusdevice.

- handlefeed1 (L5-25): Structural note: Key operations: modbusdevice.writeData, modbusdevice.readData.

### simulation/simulation/remote_io/modbus/feed2.py

Inherited remote-I/O device adapter: maps the named process signal/actuator between simulator JSON and scaled Modbus registers. Disabled as a competing writer by the current simulator-only supervisor override.

Snapshot: 937 bytes; 29 lines.

Dependencies: import asyncio; import json; import modbusdevice.

- handlefeed2 (L5-25): Structural note: Key operations: modbusdevice.writeData, modbusdevice.readData.

### simulation/simulation/remote_io/modbus/helper.py

Inherited simulator/Modbus support helpers; inspect callers in the remote-I/O directory rather than assuming current live usage.

Snapshot: 3,711 bytes; 133 lines.

Dependencies: import argparse; import logging; import os; from typing import Any; from pymodbus import pymodbus_apply_logging_config.

- get_commandline (L20-116): Source docstring: Read and check command line arguments.

- get_certificate (L119-133): Source docstring: Get example certificate.

### simulation/simulation/remote_io/modbus/modbusdevice.py

Async Modbus server infrastructure and simulator JSON read/write helpers. Device callbacks map registers to individual process signals.

Snapshot: 3,868 bytes; 112 lines.

Dependencies: import asyncio; import json; import socket; from pymodbus.server import StartAsyncTcpServer; from pymodbus.device import ModbusDeviceIdentification; from pymodbus.datastore import ModbusSequentialDataBlock, ModbusServerContext, ModbusSlaveContext.

- clamp_value (L8-9): Structural note: Returns max(0, min(65535, value)).

- write_with_timeout (L11-18): Structural note: Key operations: writer.write, writer.drain.

- read_with_timeout (L23-29): Structural note: Returns await asyncio.wait_for(reader.readline(), timeout=timeout). Key operations: reader.readline.

- readData (L32-43): Structural note: Returns latest. Key operations: write_with_timeout, reader.readline.

- writeData (L45-56): Structural note: Key operations: write_with_timeout, request_str.encode.

- run_device (L58-112): Structural note: Key operations: StartAsyncTcpServer, asyncio.open_connection, writer.close, writer.wait_closed.

- run_device.maintain_connection (L83-103): Structural note: Key operations: asyncio.open_connection, writer.close, writer.wait_closed.

### simulation/simulation/remote_io/modbus/product.py

Inherited remote-I/O device adapter: maps the named process signal/actuator between simulator JSON and scaled Modbus registers. Disabled as a competing writer by the current simulator-only supervisor override.

Snapshot: 957 bytes; 29 lines.

Dependencies: import asyncio; import json; import modbusdevice.

- handleproduct (L5-25): Structural note: Key operations: modbusdevice.writeData, modbusdevice.readData.

### simulation/simulation/remote_io/modbus/purge.py

Inherited remote-I/O device adapter: maps the named process signal/actuator between simulator JSON and scaled Modbus registers. Disabled as a competing writer by the current simulator-only supervisor override.

Snapshot: 973 bytes; 28 lines.

Dependencies: import asyncio; import json; import modbusdevice.

- handlepurge (L5-24): Structural note: Key operations: modbusdevice.writeData, writer.drain, modbusdevice.readData.

### simulation/simulation/remote_io/modbus/remote_io.py

Legacy Twisted/pymodbus server example with obsolete server.async import syntax. Not a Python 3.13-compatible live entry point.

Snapshot: 2,671 bytes; 65 lines.

Legacy syntax is incompatible with Python 3.13 AST: invalid syntax, line 16. The structural index substitutes only the obsolete import name for parsing; the companion retains original source.

Dependencies: from pymodbus.server.async_compat import StartTcpServer; from pymodbus.server.async_compat import StartUdpServer; from pymodbus.server.async_compat import StartSerialServer; from pymodbus.device import ModbusDeviceIdentification; from pymodbus.datastore import ModbusSequentialDataBlock; from pymodbus.datastore import ModbusSlaveContext, ModbusServerContext; from pymodbus.transaction import ModbusRtuFramer, ModbusAsciiFramer; import logging.

- run_async_server (L34-61): Structural note: Key operations: StartTcpServer.

### simulation/simulation/remote_io/modbus/run_all.sh

Inherited remote-I/O device adapter: maps the named process signal/actuator between simulator JSON and scaled Modbus registers. Disabled as a competing writer by the current simulator-only supervisor override.

Snapshot: 131 bytes; 10 lines.

### simulation/simulation/remote_io/modbus/server_async.py

Legacy asynchronous Modbus example/configuration. Retains obsolete pymodbus imports and belongs to the inherited lab path.

Snapshot: 9,127 bytes; 219 lines.

Dependencies: import asyncio; import logging; import sys; from collections.abc import Callable; from typing import Any; from pymodbus import __version__ as pymodbus_version; from pymodbus.datastore import ModbusSequentialDataBlock, ModbusServerContext, ModbusSlaveContext, ModbusSparseDataBlock; from pymodbus.device import ModbusDeviceIdentification; from pymodbus.server import StartAsyncSerialServer, StartAsyncTcpServer, StartAsyncTlsServer, StartAsyncUdpServer.

- setup_server (L70-136): Source docstring: Run server setup.

- run_async_server (L139-208): Source docstring: Run server.

- async_helper (L211-215): Source docstring: Combine setup and run.

### simulation/simulation/remote_io/modbus/tank.py

Inherited remote-I/O device adapter: maps the named process signal/actuator between simulator JSON and scaled Modbus registers. Disabled as a competing writer by the current simulator-only supervisor override.

Snapshot: 786 bytes; 21 lines.

Dependencies: import asyncio; import json; import modbusdevice.

- handletank (L5-18): Structural note: Key operations: modbusdevice.readData.

### simulation/supervisord.conf

Supervisor process definitions for the image. Root Compose mounts a different simulator-only override.

Snapshot: 426 bytes; 16 lines.

### simulation/web_visualization/Build/ChemicalPlant.json

Unity build manifest naming player code/data resources and runtime settings. Referenced binaries must be supplied by the relevant image/build.

Snapshot: 592 bytes; 17 lines.

Data structure: companyName, productName, productVersion, dataUrl, wasmCodeUrl, wasmFrameworkUrl, wasmSymbolsUrl, graphicsAPI, webglContextAttributes, splashScreenStyle, backgroundColor, cacheControl, developmentBuild, multithreading, unityVersion.

### simulation/web_visualization/Build/UnityLoader.js

Generated third-party Unity bootstrap/runtime loader. Loads the built player; it is not authored SCRAM policy or original Unity scene source.

Snapshot: 159,918 bytes; 4 lines.

### simulation/web_visualization/LowQuality.mp4

Visual asset: Unity/browser template artwork or recorded plant video. Referenced by web pages/templates, not the control algorithm.

Snapshot: 28,064,373 bytes; binary asset.

### simulation/web_visualization/TemplateData/D_lock.png

Visual asset: Unity/browser template artwork or recorded plant video. Referenced by web pages/templates, not the control algorithm.

Snapshot: 19,481 bytes; binary asset.

### simulation/web_visualization/TemplateData/UnityProgress.js

Unity loading-progress DOM updates and progress-bar visibility logic.

Snapshot: 1,212 bytes; 24 lines.

Code landmarks: L1: function UnityProgress(unityInstance, progress) {.

### simulation/web_visualization/TemplateData/favicon.ico

Visual asset: Unity/browser template artwork or recorded plant video. Referenced by web pages/templates, not the control algorithm.

Snapshot: 13,275 bytes; binary asset.

### simulation/web_visualization/TemplateData/fullscreen.png

Visual asset: Unity/browser template artwork or recorded plant video. Referenced by web pages/templates, not the control algorithm.

Snapshot: 345 bytes; binary asset.

### simulation/web_visualization/TemplateData/progressEmpty.Dark.png

Visual asset: Unity/browser template artwork or recorded plant video. Referenced by web pages/templates, not the control algorithm.

Snapshot: 155 bytes; binary asset.

### simulation/web_visualization/TemplateData/progressEmpty.Light.png

Visual asset: Unity/browser template artwork or recorded plant video. Referenced by web pages/templates, not the control algorithm.

Snapshot: 159 bytes; binary asset.

### simulation/web_visualization/TemplateData/progressFull.Dark.png

Visual asset: Unity/browser template artwork or recorded plant video. Referenced by web pages/templates, not the control algorithm.

Snapshot: 137 bytes; binary asset.

### simulation/web_visualization/TemplateData/progressFull.Light.png

Visual asset: Unity/browser template artwork or recorded plant video. Referenced by web pages/templates, not the control algorithm.

Snapshot: 142 bytes; binary asset.

### simulation/web_visualization/TemplateData/progressLogo.Dark.png

Visual asset: Unity/browser template artwork or recorded plant video. Referenced by web pages/templates, not the control algorithm.

Snapshot: 2,343 bytes; binary asset.

### simulation/web_visualization/TemplateData/progressLogo.Light.png

Visual asset: Unity/browser template artwork or recorded plant video. Referenced by web pages/templates, not the control algorithm.

Snapshot: 2,259 bytes; binary asset.

### simulation/web_visualization/TemplateData/style.css

Presentation stylesheet: layout, typography, color, component states and responsive rules. It does not make control decisions. Cascade/load order in the matching HTML determines overrides.

Snapshot: 1,668 bytes; 18 lines.

### simulation/web_visualization/TemplateData/webgl-logo.png

Visual asset: Unity/browser template artwork or recorded plant video. Referenced by web pages/templates, not the control algorithm.

Snapshot: 3,587 bytes; binary asset.

### simulation/web_visualization/data/index.php

Inherited HTTP-to-simulator socket bridge for state and E-stop. Separate from the Python API and its protection logic.

Snapshot: 661 bytes; 26 lines.

### simulation/web_visualization/index.html

Inherited visualization HTML layout and scripts. Its DOM hosts Unity/loading UI rather than Python control logic.

Snapshot: 23,504 bytes; 753 lines.

Code landmarks: L13: <script src="TemplateData/UnityProgress.js"></script>; L14: <script src="Build/UnityLoader.js"></script>; L312: <script>; L336: function openTool(name) {; L349: function getToolUrl(name) {; L355: function setStatus(text, color) {; L362: // ---- Tool status polling (stable + no flicker) ----; L376: function setToolStatus(toolName, ok, detailText) {; L396: async function checkTool(name) {; L419: function applyStabilizedResult(name, okNow) {; L443: function anyUnstable() {; L447: async function pollOnce() {; L466: // ---- About / version ----; L480: async function fetchVersionInfo() {; L491: function _statusColor(s) {; L495: function openAbout() {; L529: function closeAbout() {; L533: function copyVersionReport() {; L553: function isValidJson(text) {; L563: async function checkSimulationJson() {; L577: async function refreshSimulationStatus() {; L591: // ---- One load handler: init everything ----.

### simulation/web_visualization/version.php

Reports the installed simulator image/release version to the inherited web interface.

Snapshot: 212 bytes; 5 lines.

### simulation/web_visualization/versions.php

Inherited Docker-oriented service-version view, omitted by the Debian packaging path.

Snapshot: 1,937 bytes; 56 lines.

Code landmarks: L7: function docker_get($path) {.

### tests/frontend_smoke.cjs

Playwright browser regressions using local mock services. Checks rendering/interactions, disconnected behavior and markup handling; separate from pytest.

Snapshot: 11,129 bytes; 171 lines.

### tests/test_governance.py

Fast tests for monitor/governance.py: ceiling shape, debounce, asymmetric rates, recovery gate. Regression specification; the test names and assertions below identify the behaviors protected. Fakes/mocks isolate dependencies unless the file explicitly requires the live simulator.

Snapshot: 6,092 bytes; 134 lines.

Dependencies: from contracts import SupervisoryTargets; from monitor import governance as G; from monitor.observer import Verdict.

- test_ceiling_is_monotonic_bounded_and_floored (L12-20): Structural note: Regression case: ceiling is monotonic bounded and floored. Read its setup and assertions to see the exact invariant.

- verdict (L23-24): Structural note: Returns Verdict(t, 'proposals', label, score, 'r').

- test_one_observer_verdict_moves_nothing_two_consecutive_do (L27-34): Structural note: Regression case: one observer verdict moves nothing two consecutive do. Read its setup and assertions to see the exact invariant.

- test_a_normal_verdict_between_spikes_breaks_the_streak (L37-41): Structural note: Regression case: a normal verdict between spikes breaks the streak. Read its setup and assertions to see the exact invariant.

- test_rule_monitor_needs_two_samples_a_second_apart (L44-50): Structural note: Regression case: rule monitor needs two samples a second apart. Read its setup and assertions to see the exact invariant.

- drive (L53-58): Structural note: Returns s.

- test_drop_is_fast_recovery_slow_and_gated (L61-75): Structural note: Regression case: drop is fast recovery slow and gated. Read its setup and assertions to see the exact invariant.

- test_floor_holds_under_sustained_maximal_suspicion (L78-83): Structural note: Regression case: floor holds under sustained maximal suspicion. Read its setup and assertions to see the exact invariant.

- test_residual_rule_evidence_fades_fast_only_inside_the_envelope (L86-104): Structural note: Regression case: residual rule evidence fades fast only inside the envelope. Read its setup and assertions to see the exact invariant.

- test_residual_rule_evidence_fades_fast_only_inside_the_envelope.cusum (L87-88): Structural note: Returns 0.9 * 0.5 ** (t / 120.0).

- test_reattack_during_recovery_clamps_to_floor_fast (L107-118): Structural note: Regression case: reattack during recovery clamps to floor fast. Read its setup and assertions to see the exact invariant.

- test_per_cycle_rule_checks_are_never_discounted (L121-126): Structural note: Regression case: per cycle rule checks are never discounted. Read its setup and assertions to see the exact invariant.

- drive_src (L129-134): Structural note: Returns s.

### tests/test_interlock_truth.py

Integration test: the SCRAM interlock trips off the independent safety-instrumented sensor path even while a fault holds the basic control system's MEASURED view in-band. Requires the plant container to be running and reachable on 127.0.0.1:55555 (docker compose up -d simulation). Skipped automatically if it isn't. Scenario: 1. Freeze the pressure sensor (fault_injection.freeze) - its measured ... Regression specification; the test names and assertions below identify the behaviors protected. Fakes/mocks isolate dependencies unless the file explicitly requires the live simulator.

Snapshot: 6,070 bytes; 157 lines.

Dependencies: import socket; import time; import pytest; from contracts import ControlCommand; from l0_plant.plant_service import PlantService; from l0_plant import fault_injection as fi; from scripts.reset_plant import reset_and_settle.

- _plant_reachable (L36-41): Structural note: Returns True; False.

- plant (L51-67): Structural note: Key operations: reset_and_settle, PlantService(HOST, PORT).start, svc.client.write_inputs, svc.reset_interlock.

- test_interlock_trips_on_truth_while_measured_stays_in_band (L79-149): Structural note: Regression case: interlock trips on truth while measured stays in band. Read its setup and assertions to see the exact invariant.

- test_reset_interlock_rejected_when_not_tripped_is_noop (L152-157): Structural note: Regression case: reset interlock rejected when not tripped is noop. Read its setup and assertions to see the exact invariant.

### tests/test_keel.py

Fast pure-logic tests for enforcer/keel.py (no container, no network). Regression specification; the test names and assertions below identify the behaviors protected. Fakes/mocks isolate dependencies unless the file explicitly requires the live simulator.

Snapshot: 5,177 bytes; 128 lines.

Dependencies: import math; import random; from contracts import ControlCommand, PlantState; from enforcer.keel import EventLog, Keel, KeelLimits, SisFrame.

- state (L15-20): Structural note: Returns PlantState(pressure=p_meas, level=l_meas, f1_flow=0, f2_flow=0, purge_flow=0, product_flow=0, a_i....

- run (L23-31): Source docstring: Drive Keel with callables of t. Returns list of (t, Decision).

- test_nominal_with_noise_never_intervenes (L34-39): Structural note: Regression case: nominal with noise never intervenes. Read its setup and assertions to see the exact invariant.

- test_pressure_ramp_is_clamped_before_the_sis_trip (L42-53): Structural note: Regression case: pressure ramp is clamped before the sis trip. Read its setup and assertions to see the exact invariant.

- test_slow_level_drain_trips_load_line_before_sis (L56-63): Structural note: Regression case: slow level drain trips load line before sis. Read its setup and assertions to see the exact invariant.

- test_divergence_from_spoofed_measurement_costs_authority (L66-71): Structural note: Regression case: divergence from spoofed measurement costs authority. Read its setup and assertions to see the exact invariant.

- test_measured_view_can_never_relax_a_clamp (L74-79): Structural note: Regression case: measured view can never relax a clamp. Read its setup and assertions to see the exact invariant.

- test_safety_moves_are_not_throttled (L82-87): Structural note: Regression case: safety moves are not throttled. Read its setup and assertions to see the exact invariant.

- test_l2_alone_cannot_push_authority_below_floor (L90-94): Structural note: Regression case: l2 alone cannot push authority below floor. Read its setup and assertions to see the exact invariant.

- test_authority_recovers_slowly_when_clean (L97-103): Structural note: Regression case: authority recovers slowly when clean. Read its setup and assertions to see the exact invariant.

- test_gate_rejections_lead_to_divert (L106-111): Structural note: Regression case: gate rejections lead to divert. Read its setup and assertions to see the exact invariant.

- test_invalid_sis_reading_fails_safe (L114-118): Structural note: Regression case: invalid sis reading fails safe. Read its setup and assertions to see the exact invariant.

- test_event_log_chain_verifies_and_detects_tamper (L121-128): Structural note: Regression case: event log chain verifies and detects tamper. Read its setup and assertions to see the exact invariant.

### tests/test_l1_regulator.py

Fast tests for l1_regulator.L1Regulator against a toy TE-like plant (no container). The toy plant only has the right SIGNS and rough magnitudes of the live plant (pressure ~0.13 kPa/s per % purge and ~0.035 kPa/s per % of total feed, with a 5 s lag; level integrates product inflow minus outflow; A responds to feed 2). It exists to check loop structure - tracking, no sustained oscillation, no wi... Regression specification; the test names and assertions below identify the behaviors protected. Fakes/mocks isolate dependencies unless the file explicitly requires the live simulator.

Snapshot: 7,189 bytes; 143 lines.

Dependencies: from dataclasses import replace; from contracts import ControlCommand, PlantState, SupervisoryTargets; from l0_plant.provenance_gate import ProvenanceGate; from l1_regulator import DESIGN_F1, DESIGN_F2, DESIGN_PRODUCT, DESIGN_PURGE, L1Regulator.

- ToyPlant (L22-43): Structural note: Class (no explicit base class). Groups related methods/state.

- ToyPlant.__init__ (L23-25): Structural note: Updates (self.p, self.p_drive, self.l, self.q, self.a), self.v.

- ToyPlant.state (L27-31): Structural note: Returns PlantState(pressure=self.p, level=self.l, f1_flow=0, f2_flow=0, purge_flow=0, product_flow=self.q....

- ToyPlant.step (L33-43): Structural note: Updates self.v, feed, drive, inflow, outflow.

- run (L46-52): Structural note: Returns plant. Key operations: l1.regulate.

- fresh (L55-59): Structural note: Returns (l1, plant).

- test_holds_the_design_point (L62-66): Structural note: Regression case: holds the design point. Read its setup and assertions to see the exact invariant.

- _settles (L69-74): Source docstring: within band of target over the last `tail` samples, and no sustained oscillation (error sign changes over the tail are few).

- test_each_setpoint_step_settles_without_sustained_oscillation (L77-88): Structural note: Regression case: each setpoint step settles without sustained oscillation. Read its setup and assertions to see the exact invariant.

- test_no_windup_after_an_unreachable_setpoint (L91-101): Structural note: Regression case: no windup after an unreachable setpoint. Read its setup and assertions to see the exact invariant.

- test_a_comp_setpoint_and_measurement_are_in_the_same_units (L104-108): Structural note: Regression case: a comp setpoint and measurement are in the same units. Read its setup and assertions to see the exact invariant.

- test_l1_commands_pass_the_gate_and_tampered_ones_do_not (L111-123): Structural note: Regression case: l1 commands pass the gate and tampered ones do not. Read its setup and assertions to see the exact invariant.

- test_bumpless_on_rearm_and_on_authority_hand_back (L126-143): Structural note: Regression case: bumpless on rearm and on authority hand back. Read its setup and assertions to see the exact invariant.

### tests/test_llm_operator.py

Fast tests for l3_brain/policy.py's LLMOperator: output parser/validator and the operator's robustness behaviour. No network - the model client is a fake. Regression specification; the test names and assertions below identify the behaviors protected. Fakes/mocks isolate dependencies unless the file explicitly requires the live simulator.

Snapshot: 12,886 bytes; 313 lines.

Dependencies: import json; import threading; import time; from pathlib import Path; from types import SimpleNamespace; import pytest; from contracts import PlantState; import l3_brain.policy as policy_mod; from l3_brain.policy import SYSTEM_PROMPT, BaselineOperator, Envelope, LLMOperator, OllamaOperator, build_state_prompt, make_policy, parse_llm_targets; from l3_brain.prompt_format import DESIGN_POINT, measured_dict, state_to_json, system_prompt.

- make_state (L22-28): Structural note: Returns PlantState(**base).

- test_parses_valid_output (L33-37): Structural note: Regression case: parses valid output. Read its setup and assertions to see the exact invariant.

- test_clamps_to_envelope_and_says_so (L40-44): Structural note: Regression case: clamps to envelope and says so. Read its setup and assertions to see the exact invariant.

- test_null_and_missing_setpoints_mean_hold_that_field (L47-50): Structural note: Regression case: null and missing setpoints mean hold that field. Read its setup and assertions to see the exact invariant.

- test_tolerates_code_fence_and_surrounding_prose (L53-55): Structural note: Regression case: tolerates code fence and surrounding prose. Read its setup and assertions to see the exact invariant.

- test_custom_envelope_is_respected (L58-60): Structural note: Regression case: custom envelope is respected. Read its setup and assertions to see the exact invariant.

- test_rejects_malformed_output (L68-70): Structural note: Regression case: rejects malformed output. Read its setup and assertions to see the exact invariant.

- test_ignores_extra_keys_including_valve_positions (L73-77): Structural note: Regression case: ignores extra keys including valve positions. Read its setup and assertions to see the exact invariant.

- test_rationale_is_truncated (L80-82): Structural note: Regression case: rationale is truncated. Read its setup and assertions to see the exact invariant.

- test_prompt_uses_measured_fields_and_never_truth (L87-91): Structural note: Regression case: prompt uses measured fields and never truth. Read its setup and assertions to see the exact invariant.

- test_served_user_turn_matches_dataset_format (L96-101): Structural note: Regression case: served user turn matches dataset format. Read its setup and assertions to see the exact invariant.

- test_served_system_prompt_uses_real_design_point (L104-106): Structural note: Regression case: served system prompt uses real design point. Read its setup and assertions to see the exact invariant.

- test_design_point_constant_matches_sim_reading (L109-114): Structural note: Regression case: design point constant matches sim reading. Read its setup and assertions to see the exact invariant.

- FakeClient (L119-129): Structural note: Class (no explicit base class). Groups related methods/state.

- FakeClient.__init__ (L120-122): Structural note: Updates (self.replies, self.calls), self.messages.

- FakeClient.create (L124-129): Structural note: Returns r.

- reply (L132-133): Structural note: Returns SimpleNamespace(stop_reason=stop, content=[SimpleNamespace(type='text', text=text)]).

- make_op (L136-138): Structural note: Returns LLMOperator(client=FakeClient(replies), background=False, clock=clock or time.monotonic, **kw).

- is_hold (L141-143): Structural note: Returns t.pressure_sp is None and t.level_sp is None and (t.production_rate_sp is None) and (t.a_comp_sp ....

- test_returns_model_decision (L146-149): Structural note: Regression case: returns model decision. Read its setup and assertions to see the exact invariant.

- test_caches_between_intervals_and_refreshes_after (L152-162): Structural note: Regression case: caches between intervals and refreshes after. Read its setup and assertions to see the exact invariant.

- test_any_failure_degrades_to_hold_and_never_raises (L170-172): Structural note: Regression case: any failure degrades to hold and never raises. Read its setup and assertions to see the exact invariant.

- test_no_client_degrades_to_hold (L175-179): Structural note: Regression case: no client degrades to hold. Read its setup and assertions to see the exact invariant.

- test_failed_call_is_not_retried_every_cycle (L182-186): Structural note: Regression case: failed call is not retried every cycle. Read its setup and assertions to see the exact invariant.

- test_scrammed_plant_holds_without_calling_model (L189-192): Structural note: Regression case: scrammed plant holds without calling model. Read its setup and assertions to see the exact invariant.

- test_background_mode_never_blocks_decide (L195-213): Structural note: Regression case: background mode never blocks decide. Read its setup and assertions to see the exact invariant.

- test_background_mode_never_blocks_decide.SlowClient (L198-201): Structural note: Class (FakeClient). Groups related methods/state.

- test_background_mode_never_blocks_decide.SlowClient.create (L199-201): Structural note: Returns super().create(**kw).

- test_make_policy_defaults_to_baseline (L218-221): Structural note: Regression case: make policy defaults to baseline. Read its setup and assertions to see the exact invariant.

- test_make_policy_has_no_hosted_api_path (L224-228): Structural note: Regression case: make policy has no hosted api path. Read its setup and assertions to see the exact invariant.

- FakeOllama (L239-248): Structural note: Class (no explicit base class). Groups related methods/state.

- FakeOllama.__init__ (L240-241): Structural note: Updates (self.replies, self.requests).

- FakeOllama.__call__ (L243-248): Structural note: Returns r. Key operations: self.requests.append.

- ollama_reply (L251-253): Structural note: Returns {'model': 'scram-operator', 'message': {'role': 'assistant', 'content': text}, 'done': True, 'don....

- test_ollama_path_parses_trained_model_reply (L256-268): Structural note: Regression case: ollama path parses trained model reply. Read its setup and assertions to see the exact invariant.

- test_ollama_reply_is_clamped_to_envelope (L271-275): Structural note: Regression case: ollama reply is clamped to envelope. Read its setup and assertions to see the exact invariant.

- test_ollama_trained_hold_reply_is_a_hold (L278-281): Structural note: Regression case: ollama trained hold reply is a hold. Read its setup and assertions to see the exact invariant.

- test_ollama_failure_degrades_to_hold (L289-291): Structural note: Regression case: ollama failure degrades to hold. Read its setup and assertions to see the exact invariant.

- test_ollama_scrammed_plant_holds_without_calling_model (L294-297): Structural note: Regression case: ollama scrammed plant holds without calling model. Read its setup and assertions to see the exact invariant.

- test_make_policy_ollama_selected_by_env (L300-303): Structural note: Regression case: make policy ollama selected by env. Read its setup and assertions to see the exact invariant.

- test_make_policy_ollama_unavailable_falls_back_to_baseline (L306-309): Structural note: Regression case: make policy ollama unavailable falls back to baseline. Read its setup and assertions to see the exact invariant.

- test_ollama_available_is_false_when_server_unreachable (L312-313): Structural note: Regression case: ollama available is false when server unreachable. Read its setup and assertions to see the exact invariant.

### tests/test_observer_dataset.py

Fast tests for the v3 observer format and dataset builder (no container, no model). Regression specification; the test names and assertions below identify the behaviors protected. Fakes/mocks isolate dependencies unless the file explicitly requires the live simulator.

Snapshot: 3,894 bytes; 76 lines.

Dependencies: import json; from collections import Counter; import pytest; from monitor import observer_v2_format as V2; from monitor import observer_v3_format as V3; from training import build_observer_dataset as B.

- test_v3_prompt_changes_only_the_telemetry_paragraph (L21-25): Structural note: Regression case: v3 prompt changes only the telemetry paragraph. Read its setup and assertions to see the exact invariant.

- test_v3_telemetry_turn_has_long_window_all_flows_and_commanded_valves (L28-36): Structural note: Regression case: v3 telemetry turn has long window all flows and commanded valves. Read its setup and assertions to see the exact invariant.

- built (L40-43): Structural note: Returns (out, report).

- _read (L46-47): Structural note: Returns [json.loads(line)['messages'] for line in path.open(encoding='utf-8')]. Key operations: path.open.

- test_v2_proposal_examples_are_carried_over_byte_for_byte (L50-57): Structural note: Regression case: v2 proposal examples are carried over byte for byte. Read its setup and assertions to see the exact invariant.

- test_builder_emits_valid_jsonl_with_the_requested_telemetry_counts (L60-76): Structural note: Regression case: builder emits valid jsonl with the requested telemetry counts. Read its setup and assertions to see the exact invariant.

### tests/test_observer_v2_format.py

Parity gate: monitor/observer_v2_format rebuilds EVERY stored v2 training/val input byte-for-byte, so the served v2 observer sees exactly what it was trained on. Regression specification; the test names and assertions below identify the behaviors protected. Fakes/mocks isolate dependencies unless the file explicitly requires the live simulator.

Snapshot: 2,520 bytes; 65 lines.

Dependencies: import json; from pathlib import Path; import pytest; from monitor import observer_v2_format as V2.

- _examples (L16-21): Structural note: Key operations: f.open.

- _rebuild (L24-30): Structural note: Returns V2.proposals_to_json([V2.proposal_dict(p, p['rationale'], p['provenance']) for p in user['proposa...; V2.telemetry_to_json(samples, user['window_s']).

- test_every_stored_input_is_rebuilt_byte_for_byte (L33-45): Structural note: Regression case: every stored input is rebuilt byte for byte. Read its setup and assertions to see the exact invariant.

- test_live_floats_serialize_like_the_stored_numbers (L48-59): Structural note: Regression case: live floats serialize like the stored numbers. Read its setup and assertions to see the exact invariant.

- test_assistant_turns_parse_under_the_v2_labels (L62-65): Structural note: Regression case: assistant turns parse under the v2 labels. Read its setup and assertions to see the exact invariant.

### tests/test_observer_v3_format.py

Parity gate: monitor/observer_v3_format rebuilds EVERY stored v3 train/val/unseen input byte-for-byte, so the served v3 observer sees exactly what it was trained on. The live wrapper builds its v3 telemetry through the same module; a live-built window must pass the same gate (tests/test_observer_wrapper.py and the live sanity run check that). Regression specification; the test names and assertions below identify the behaviors protected. Fakes/mocks isolate dependencies unless the file explicitly requires the live simulator.

Snapshot: 3,248 bytes; 78 lines.

Dependencies: import json; from pathlib import Path; import pytest; from monitor import observer_v3_format as V3.

- _examples (L19-24): Structural note: Key operations: f.open.

- rebuild (L27-36): Source docstring: Re-serialize one stored (or live-built) user turn through observer_v3_format.

- telemetry_key_order (L39-45): Source docstring: Key order of a stored v3 telemetry turn (what a live window must reproduce).

- test_every_stored_v3_input_is_rebuilt_byte_for_byte (L48-60): Structural note: Regression case: every stored v3 input is rebuilt byte for byte. Read its setup and assertions to see the exact invariant.

- test_stored_telemetry_shapes_and_float_types_match_what_is_served (L63-72): Structural note: Regression case: stored telemetry shapes and float types match what is served. Read its setup and assertions to see the exact invariant.

- test_assistant_turns_parse_under_the_v3_labels (L75-78): Structural note: Regression case: assistant turns parse under the v3 labels. Read its setup and assertions to see the exact invariant.

### tests/test_observer_wrapper.py

Fast tests for monitor/observer.py: routing, flooring and degrade-to-zero (Ollama faked). Regression specification; the test names and assertions below identify the behaviors protected. Fakes/mocks isolate dependencies unless the file explicitly requires the live simulator.

Snapshot: 11,910 bytes; 266 lines.

Dependencies: import json; from contracts import PlantState, SupervisoryTargets; from monitor import observer as O; from monitor import observer_v2_format as V2; from contracts import ControlCommand; from monitor import observer_v3_format as V3; from test_observer_v3_format import rebuild.

- make (L18-28): Structural note: Returns (O.Observer(background=False, http_post=post), seen); {'message': {'content': r}} if isinstance(r, str) else r.

- make.post (L21-26): Structural note: Returns {'message': {'content': r}} if isinstance(r, str) else r.

- run (L31-35): Structural note: Updates t.

- verdict (L38-39): Structural note: Returns json.dumps({'label': label, 'score': score, 'reason': 'r'}).

- test_proposal_attack_label_reaches_keel_and_telemetry_label_does_not (L42-47): Structural note: Regression case: proposal attack label reaches keel and telemetry label does not. Read its setup and assertions to see the exact invariant.

- test_telemetry_only_alarm_never_feeds_keel (L50-53): Structural note: Regression case: telemetry only alarm never feeds keel. Read its setup and assertions to see the exact invariant.

- test_low_score_attack_is_floored_and_normal_is_zero (L56-62): Structural note: Regression case: low score attack is floored and normal is zero. Read its setup and assertions to see the exact invariant.

- test_bad_output_or_backend_failure_degrades_to_zero (L65-71): Structural note: Regression case: bad output or backend failure degrades to zero. Read its setup and assertions to see the exact invariant.

- test_proposals_wait_for_a_full_history_and_reset_clears_verdicts (L74-81): Structural note: Regression case: proposals wait for a full history and reset clears verdicts. Read its setup and assertions to see the exact invariant.

- test_live_inputs_use_the_exact_v2_format (L84-94): Structural note: Regression case: live inputs use the exact v2 format. Read its setup and assertions to see the exact invariant.

- make_v3 (L105-115): Structural note: Returns (O.Observer(fmt=V3, model='scram-observer-v3', num_ctx=3072, background=False, http_post=post, **...; {'message': {'content': r}} if isinstance(r, str) else r.

- make_v3.post (L108-113): Structural note: Returns {'message': {'content': r}} if isinstance(r, str) else r.

- run_v3 (L118-122): Structural note: Updates t.

- test_v3_live_built_telemetry_passes_the_v3_parity_gate (L125-137): Structural note: Regression case: v3 live built telemetry passes the v3 parity gate. Read its setup and assertions to see the exact invariant.

- test_v3_live_window_has_the_stored_key_order (L140-146): Structural note: Regression case: v3 live window has the stored key order. Read its setup and assertions to see the exact invariant.

- test_v3_takes_no_telemetry_sample_without_a_command (L149-152): Structural note: Regression case: v3 takes no telemetry sample without a command. Read its setup and assertions to see the exact invariant.

- test_v3_telemetry_verdicts_never_reach_authority (L155-159): Structural note: Regression case: v3 telemetry verdicts never reach authority. Read its setup and assertions to see the exact invariant.

- test_v3_proposal_side_feeds_authority_exactly_as_v2 (L162-168): Structural note: Regression case: v3 proposal side feeds authority exactly as v2. Read its setup and assertions to see the exact invariant.

- make_split (L175-185): Structural note: Returns (O.make_split_observer(available=lambda m: m in installed, background=False, http_post=post), bod...; {'message': {'content': r}} if isinstance(r, str) else r.

- make_split.post (L178-183): Structural note: Returns {'message': {'content': r}} if isinstance(r, str) else r.

- run_split (L188-192): Structural note: Updates t.

- test_split_routes_proposals_to_v2_and_telemetry_to_v3 (L195-204): Structural note: Regression case: split routes proposals to v2 and telemetry to v3. Read its setup and assertions to see the exact invariant.

- test_split_live_telemetry_still_passes_the_v3_parity_gate (L207-211): Structural note: Regression case: split live telemetry still passes the v3 parity gate. Read its setup and assertions to see the exact invariant.

- test_split_authority_comes_from_the_v2_proposal_path_only (L214-221): Structural note: Regression case: split authority comes from the v2 proposal path only. Read its setup and assertions to see the exact invariant.

- test_split_paths_share_one_in_flight_call_and_keep_the_validated_rate (L224-231): Structural note: Regression case: split paths share one in flight call and keep the validated rate. Read its setup and assertions to see the exact invariant.

- test_split_fallback_chains_per_path (L234-240): Structural note: Regression case: split fallback chains per path. Read its setup and assertions to see the exact invariant.

- test_split_runtime_fallback_when_a_model_keeps_failing (L243-253): Structural note: Regression case: split runtime fallback when a model keeps failing. Read its setup and assertions to see the exact invariant.

- test_backend_errors_count_up_and_a_reply_resets_them (L256-266): Structural note: Regression case: backend errors count up and a reply resets them. Read its setup and assertions to see the exact invariant.

### tests/test_parser_grounding.py

Models may not invent an actuator that the operator did not name. Regression specification; the test names and assertions below identify the behaviors protected. Fakes/mocks isolate dependencies unless the file explicitly requires the live simulator.

Snapshot: 2,776 bytes; 98 lines.

Dependencies: import json; import pytest; from sim_app.ai import parse_commands.

- test_hallucinated_supported_valve_is_refused (L19-40): Structural note: Regression case: hallucinated supported valve is refused. Read its setup and assertions to see the exact invariant.

- test_hallucinated_supported_valve_is_refused.post (L20-36): Structural note: Returns {'message': {'content': json.dumps({'actions': [{'clause': text, 'action': 'set', 'valve': 'f1', ....

- test_model_cannot_supply_a_forged_clause_to_ground_a_valve (L43-65): Structural note: Regression case: model cannot supply a forged clause to ground a valve. Read its setup and assertions to see the exact invariant.

- test_model_cannot_supply_a_forged_clause_to_ground_a_valve.post (L44-60): Structural note: Returns {'message': {'content': json.dumps({'actions': [{'clause': 'open feed 1 to 40%', 'action': 'set',....

- test_supported_action_survives_an_unsupported_action_in_same_command (L68-98): Structural note: Regression case: supported action survives an unsupported action in same command. Read its setup and assertions to see the exact invariant.

- test_supported_action_survives_an_unsupported_action_in_same_command.post (L71-93): Structural note: Returns {'message': {'content': json.dumps({'actions': [{'clause': 'Open coolant to 30%', 'action': 'set'....

### tests/test_physics_detector.py

Physics release integrity and advisory routing regression checks. Regression specification; the test names and assertions below identify the behaviors protected. Fakes/mocks isolate dependencies unless the file explicitly requires the live simulator.

Snapshot: 2,428 bytes; 67 lines.

Dependencies: import json; import pytest; from monitor import observer_v3_format as V3; from monitor.observer import Observer; from monitor.physics_detector import DEST, PhysicsDetector, approved_physics_detector; from monitor.physics_features import physics_features.

- normal_window (L13-20): Structural note: Returns next((json.loads(line)['window'] for line in path.read_text().splitlines() if json.loads(line)['l.... Key operations: path.read_text().splitlines, path.read_text.

- test_release_evidence_and_prediction (L23-33): Structural note: Regression case: release evidence and prediction. Read its setup and assertions to see the exact invariant.

- test_changed_model_evidence_is_rejected (L36-45): Structural note: Regression case: changed model evidence is rejected. Read its setup and assertions to see the exact invariant.

- test_correction_retains_llm_label_and_has_no_authority (L48-67): Structural note: Regression case: correction retains llm label and has no authority. Read its setup and assertions to see the exact invariant.

### tests/test_provenance_gate.py

Fast, pure-logic tests for l0_plant/provenance_gate.py and its PlantService wiring (fake plant client, no container): accept authorized, reject injected. Regression specification; the test names and assertions below identify the behaviors protected. Fakes/mocks isolate dependencies unless the file explicitly requires the live simulator.

Snapshot: 6,500 bytes; 193 lines.

Dependencies: from dataclasses import replace; import pytest; from contracts import ControlCommand; from l0_plant.plant_service import PlantService; from l0_plant.provenance_gate import CommandSigner, ProvenanceGate.

- make_gate (L19-22): Structural note: Returns g.

- test_authorized_signed_command_is_accepted (L27-29): Structural note: Regression case: authorized signed command is accepted. Read its setup and assertions to see the exact invariant.

- test_accepted_command_becomes_last_good (L32-35): Structural note: Regression case: accepted command becomes last good. Read its setup and assertions to see the exact invariant.

- test_unsigned_command_rejected_in_strict_mode (L38-42): Structural note: Regression case: unsigned command rejected in strict mode. Read its setup and assertions to see the exact invariant.

- test_unsigned_command_trusted_in_legacy_mode (L45-47): Structural note: Regression case: unsigned command trusted in legacy mode. Read its setup and assertions to see the exact invariant.

- test_wrong_key_rejected (L50-52): Structural note: Regression case: wrong key rejected. Read its setup and assertions to see the exact invariant.

- test_tampered_values_rejected (L55-58): Structural note: Regression case: tampered values rejected. Read its setup and assertions to see the exact invariant.

- test_replayed_command_rejected (L61-66): Structural note: Regression case: replayed command rejected. Read its setup and assertions to see the exact invariant.

- test_clamped_preserves_provenance_fields (L69-71): Structural note: Regression case: clamped preserves provenance fields. Read its setup and assertions to see the exact invariant.

- test_legacy_construction_still_works (L74-76): Structural note: Regression case: legacy construction still works. Read its setup and assertions to see the exact invariant.

- test_audit_clean_when_plant_matches_last_good (L81-82): Structural note: Regression case: audit clean when plant matches last good. Read its setup and assertions to see the exact invariant.

- test_audit_flags_out_of_band_valve_write (L85-87): Structural note: Regression case: audit flags out of band valve write. Read its setup and assertions to see the exact invariant.

- test_audit_flags_injected_e_stop (L90-91): Structural note: Regression case: audit flags injected e stop. Read its setup and assertions to see the exact invariant.

- test_audit_expects_e_stop_after_safe_state_note (L94-97): Structural note: Regression case: audit expects e stop after safe state note. Read its setup and assertions to see the exact invariant.

- test_audit_expects_closed_product_for_low_level_safe_state (L100-103): Structural note: Regression case: audit expects closed product for low level safe state. Read its setup and assertions to see the exact invariant.

- FakePlant (L108-130): Source docstring: Tiny stand-in for GrficsClient: holds valve state, applies writes.

- FakePlant.__init__ (L110-112): Structural note: Updates self.state, self.writes.

- FakePlant.connect (L114-114): Structural note: Returns self.

- FakePlant.close (L115-115): Structural note: Coordinates the statements shown in the source companion.

- FakePlant._raw (L117-119): Structural note: Returns {'measured': {}, 'outputs': {'pressure': 2700.0, 'liquid_level': 44.0}, 'state': dict(self.state)}.

- FakePlant.read (L121-121): Structural note: Returns self._raw().

- FakePlant.write_inputs (L123-130): Structural note: Returns self._raw(). Key operations: self.writes.append.

- make_service (L133-136): Structural note: Returns svc.

- test_service_applies_authorized_command_and_rejects_identical_unsigned_one (L139-147): Structural note: Regression case: service applies authorized command and rejects identical unsigned one. Read its setup and assertions to see the exact invariant.

- test_service_detects_out_of_band_write_and_reasserts_last_good (L150-157): Structural note: Regression case: service detects out of band write and reasserts last good. Read its setup and assertions to see the exact invariant.

- test_service_without_gate_is_unchanged_legacy_behaviour (L160-164): Structural note: Regression case: service without gate is unchanged legacy behaviour. Read its setup and assertions to see the exact invariant.

- test_clamped_refuses_non_finite (L172-174): Structural note: Regression case: clamped refuses non finite. Read its setup and assertions to see the exact invariant.

- test_gate_rejects_signed_non_finite_command (L177-179): Structural note: Regression case: gate rejects signed non finite command. Read its setup and assertions to see the exact invariant.

- test_service_never_applies_nan_valve_with_gate (L182-185): Structural note: Regression case: service never applies nan valve with gate. Read its setup and assertions to see the exact invariant.

- test_service_never_applies_nan_valve_without_gate (L188-193): Structural note: Regression case: service never applies nan valve without gate. Read its setup and assertions to see the exact invariant.

### tests/test_quality_hardening.py

Regression tests for combined hazards, cancellation races, and evidence lifetime. Regression specification; the test names and assertions below identify the behaviors protected. Fakes/mocks isolate dependencies unless the file explicitly requires the live simulator.

Snapshot: 6,479 bytes; 175 lines.

Dependencies: import json; import threading; import pytest; from fastapi import HTTPException; from test_sim_app_bugs import FakeSim, make_plant; from contracts import ControlCommand; from l0_plant.provenance_gate import CommandSigner, ProvenanceGate; from l0_plant.safety import SafeHold, SafetyInterlock; from monitor.observer import Observer, Verdict; from sim_app import ai.

- test_combined_pressure_and_low_inventory_relieves_without_draining (L17-29): Structural note: Regression case: combined pressure and low inventory relieves without draining. Read its setup and assertions to see the exact invariant.

- test_sensor_loss_after_any_trip_escalates_and_latches (L33-39): Structural note: Regression case: sensor loss after any trip escalates and latches. Read its setup and assertions to see the exact invariant.

- test_subprecision_tampering_is_rejected (L42-45): Structural note: Regression case: subprecision tampering is rejected. Read its setup and assertions to see the exact invariant.

- test_observer_discards_inflight_result_after_reset (L48-65): Structural note: Regression case: observer discards inflight result after reset. Read its setup and assertions to see the exact invariant.

- test_observer_discards_inflight_result_after_reset.post (L50-53): Structural note: Returns {'message': {'content': json.dumps({'label': 'rationale_mismatch', 'score': 0.9, 'reason': 'old'})}}.

- test_observer_suspicion_expires_even_without_a_new_model_result (L68-74): Structural note: Regression case: observer suspicion expires even without a new model result. Read its setup and assertions to see the exact invariant.

- test_estop_during_inference_prevents_all_later_ai_writes (L77-100): Structural note: Regression case: estop during inference prevents all later ai writes. Read its setup and assertions to see the exact invariant.

- test_estop_during_inference_prevents_all_later_ai_writes.SlowOperator (L79-86): Structural note: Class (no explicit base class). Groups related methods/state.

- test_estop_during_inference_prevents_all_later_ai_writes.SlowOperator.__init__ (L81-81): Structural note: Updates self.log.

- test_estop_during_inference_prevents_all_later_ai_writes.SlowOperator.decide (L82-86): Structural note: Returns SupervisoryTargets(pressure_sp=2600, level_sp=44, production_rate_sp=70).

- test_emergency_stop_serializes_with_a_pending_valve_write (L103-110): Structural note: Regression case: emergency stop serializes with a pending valve write. Read its setup and assertions to see the exact invariant.

- test_polling_start_is_idempotent_and_shutdown_joins_worker (L113-120): Structural note: Regression case: polling start is idempotent and shutdown joins worker. Read its setup and assertions to see the exact invariant.

- test_direct_nonfinite_batch_write_is_rejected (L124-128): Structural note: Regression case: direct nonfinite batch write is rejected. Read its setup and assertions to see the exact invariant.

- test_action_flood_is_bounded_without_blocking_control_thread (L131-138): Structural note: Regression case: action flood is bounded without blocking control thread. Read its setup and assertions to see the exact invariant.

- test_snapshot_marks_old_measurements_stale (L141-148): Structural note: Regression case: snapshot marks old measurements stale. Read its setup and assertions to see the exact invariant.

- test_failed_emergency_stop_is_pending_then_reasserted_on_reconnect (L151-175): Structural note: Regression case: failed emergency stop is pending then reasserted on reconnect. Read its setup and assertions to see the exact invariant.

- test_failed_emergency_stop_is_pending_then_reasserted_on_reconnect.Sim (L153-158): Structural note: Class (FakeSim). Groups related methods/state.

- test_failed_emergency_stop_is_pending_then_reasserted_on_reconnect.Sim.write_inputs (L154-158): Structural note: Returns result. Key operations: super().write_inputs.

- test_failed_emergency_stop_is_pending_then_reasserted_on_reconnect.disconnected (L161-162): Structural note: Coordinates the statements shown in the source companion.

### tests/test_recovery_console.py

SIS safe-hold + auto re-arm, operator chat, and custom-attack validation (fast: no container, no model). Regression specification; the test names and assertions below identify the behaviors protected. Fakes/mocks isolate dependencies unless the file explicitly requires the live simulator.

Snapshot: 8,052 bytes; 190 lines.

Dependencies: import types; import pytest; from contracts import PlantState; from l0_plant.provenance_gate import ProvenanceGate; from l0_plant.safety import SafeHold, SafetyInterlock, TripLimits; from l3_brain.policy import OllamaOperator; from live import engine as E; from live import commands.

- _tripped (L18-21): Structural note: Returns sis. Key operations: sis.evaluate.

- test_pressure_trip_runs_the_safe_hold_instead_of_estop (L24-28): Structural note: Regression case: pressure trip runs the safe hold instead of estop. Read its setup and assertions to see the exact invariant.

- test_safe_hold_eases_off_as_pressure_falls (L31-35): Structural note: Regression case: safe hold eases off as pressure falls. Read its setup and assertions to see the exact invariant.

- test_runaway_escalates_to_estop_and_stays_latched_until_reset (L38-42): Structural note: Regression case: runaway escalates to estop and stays latched until reset. Read its setup and assertions to see the exact invariant.

- test_sensor_fault_and_missing_readings_still_estop (L45-49): Structural note: Regression case: sensor fault and missing readings still estop. Read its setup and assertions to see the exact invariant.

- test_gate_expects_the_whole_safe_hold_lineup (L52-58): Structural note: Regression case: gate expects the whole safe hold lineup. Read its setup and assertions to see the exact invariant.

- _engine_with_trip (L62-71): Structural note: Returns eng.

- test_auto_rearm_waits_for_a_stable_band (L74-80): Structural note: Regression case: auto rearm waits for a stable band. Read its setup and assertions to see the exact invariant.

- test_no_auto_rearm_outside_the_band (L83-87): Structural note: Regression case: no auto rearm outside the band. Read its setup and assertions to see the exact invariant.

- test_auto_rearm_locks_out_after_repeated_trips (L90-96): Structural note: Regression case: auto rearm locks out after repeated trips. Read its setup and assertions to see the exact invariant.

- _state (L99-102): Structural note: Returns PlantState(pressure=2700.0, level=44.2, f1_flow=0, f2_flow=0, purge_flow=0, product_flow=100.0, a....

- _fake_ollama (L106-112): Structural note: Returns (OllamaOperator(http_post=post, background=False), sent); {'message': {'content': reply}, 'done_reason': 'stop'}.

- _fake_ollama.post (L109-111): Structural note: Returns {'message': {'content': reply}, 'done_reason': 'stop'}.

- test_note_reaches_the_model_prompt_and_is_recorded_on_the_decision (L115-125): Structural note: Regression case: note reaches the model prompt and is recorded on the decision. Read its setup and assertions to see the exact invariant.

- test_chat_with_baseline_brain_explains_instead_of_failing (L128-133): Structural note: Regression case: chat with baseline brain explains instead of failing. Read its setup and assertions to see the exact invariant.

- test_empty_chat_is_rejected_synchronously (L136-139): Structural note: Regression case: empty chat is rejected synchronously. Read its setup and assertions to see the exact invariant.

- test_bad_custom_attack_arguments_are_rejected (L152-156): Structural note: Regression case: bad custom attack arguments are rejected. Read its setup and assertions to see the exact invariant.

- test_valve_orders_become_manual_overrides (L169-170): Structural note: Regression case: valve orders become manual overrides. Read its setup and assertions to see the exact invariant.

- test_setpoint_orders_keep_the_words_and_add_explicit_targets (L173-179): Structural note: Regression case: setpoint orders keep the words and add explicit targets. Read its setup and assertions to see the exact invariant.

- test_manual_override_is_applied_and_released (L182-190): Structural note: Regression case: manual override is applied and released. Read its setup and assertions to see the exact invariant.

### tests/test_review_fixes.py

Regression tests for the 2026-10-23 code review fixes (fast: no container, no model). Regression specification; the test names and assertions below identify the behaviors protected. Fakes/mocks isolate dependencies unless the file explicitly requires the live simulator.

Snapshot: 6,990 bytes; 165 lines.

Dependencies: import json; import math; import threading; import pytest; from contracts import ControlCommand, PlantState, SupervisoryTargets; from l0_plant.plant_service import PlantService; from l0_plant.provenance_gate import ProvenanceGate; from l3_brain.operator import AIOperator; from monitor import governance as G; from monitor import observer as O; from monitor.observer import Verdict.

- FakeClient (L23-32): Structural note: Class (no explicit base class). Groups related methods/state.

- FakeClient.__init__ (L24-25): Structural note: Updates (self.raw, self.writes).

- FakeClient.read (L27-28): Structural note: Returns self.raw.

- FakeClient.write_inputs (L30-32): Structural note: Returns self.raw. Key operations: self.writes.append.

- _svc (L35-38): Structural note: Returns svc.

- test_missing_safety_channel_trips_as_sensor_fault_not_level_low (L42-45): Structural note: Regression case: missing safety channel trips as sensor fault not level low. Read its setup and assertions to see the exact invariant.

- test_rejected_command_with_no_last_good_holds_instead_of_crashing (L48-53): Structural note: Regression case: rejected command with no last good holds instead of crashing. Read its setup and assertions to see the exact invariant.

- test_reset_with_missing_safety_channel_stays_latched (L56-59): Structural note: Regression case: reset with missing safety channel stays latched. Read its setup and assertions to see the exact invariant.

- _Fixed (L63-66): Structural note: Class (no explicit base class). Groups related methods/state.

- _Fixed.decide (L64-66): Structural note: Returns SupervisoryTargets(pressure_sp=2900.0, level_sp=44.0, production_rate_sp=120.0, a_comp_sp=47.0, r....

- _state (L69-72): Structural note: Returns PlantState(pressure=2700.0, level=44.2, f1_flow=0, f2_flow=0, purge_flow=0, product_flow=100.0, a....

- test_nan_authority_holds_instead_of_granting_full_authority (L75-77): Structural note: Regression case: nan authority holds instead of granting full authority. Read its setup and assertions to see the exact invariant.

- _v (L81-82): Structural note: Returns Verdict(t, 'proposals', label, score, 'r').

- test_observer_evidence_clears_when_the_observer_disappears (L85-91): Structural note: Regression case: observer evidence clears when the observer disappears. Read its setup and assertions to see the exact invariant.

- test_stale_observer_verdict_stops_holding_the_ceiling (L94-99): Structural note: Regression case: stale observer verdict stops holding the ceiling. Read its setup and assertions to see the exact invariant.

- test_observer_releases_the_gate_when_building_a_prompt_fails (L103-116): Structural note: Regression case: observer releases the gate when building a prompt fails. Read its setup and assertions to see the exact invariant.

- test_observer_releases_the_gate_when_building_a_prompt_fails.BadFmt (L104-110): Structural note: Class (no explicit base class). Groups related methods/state.

- test_observer_releases_the_gate_when_building_a_prompt_fails.BadFmt.proposal_dict (L108-108): Structural note: Returns {}.

- test_observer_releases_the_gate_when_building_a_prompt_fails.BadFmt.proposals_to_json (L110-110): Structural note: Coordinates the statements shown in the source companion.

- test_bad_action_is_logged_not_treated_as_a_lost_connection (L120-126): Structural note: Regression case: bad action is logged not treated as a lost connection. Read its setup and assertions to see the exact invariant.

- test_sim_app_ingest_tolerates_null_valve_positions (L130-136): Structural note: Regression case: sim app ingest tolerates null valve positions. Read its setup and assertions to see the exact invariant.

- test_control_room_server_rejects_malformed_requests (L140-165): Structural note: Regression case: control room server rejects malformed requests. Read its setup and assertions to see the exact invariant.

- test_control_room_server_rejects_malformed_requests._Eng (L144-146): Structural note: Class (no explicit base class). Groups related methods/state.

- test_control_room_server_rejects_malformed_requests._Eng.read (L145-145): Structural note: Returns {}.

- test_control_room_server_rejects_malformed_requests._Eng.submit (L146-146): Structural note: Returns 'queued'.

- test_control_room_server_rejects_malformed_requests.call (L150-160): Structural note: Returns (sent['code'], h.wfile.getvalue()).

### tests/test_safety_unit.py

Fast unit test for l0_plant/safety.py: pure logic, no container, no network. Feeds SafetyInterlock.evaluate()/reset() plain pressure/level numbers and checks trip, latch, override-while-tripped, and re-arm behavior. Should run in well under a second - if it doesn't, something is talking to the network. Regression specification; the test names and assertions below identify the behaviors protected. Fakes/mocks isolate dependencies unless the file explicitly requires the live simulator.

Snapshot: 8,662 bytes; 221 lines.

Dependencies: import pytest; from l0_plant.safety import SafetyInterlock, TripLimits.

- make_interlock (L16-20): Structural note: Returns SafetyInterlock(TripLimits(pressure_high=3000.0, level_low=5.0, level_high=95.0, pressure_rearm=2....

- test_no_trip_within_normal_envelope (L25-29): Structural note: Regression case: no trip within normal envelope. Read its setup and assertions to see the exact invariant.

- test_trips_on_high_pressure (L32-36): Structural note: Regression case: trips on high pressure. Read its setup and assertions to see the exact invariant.

- test_trips_on_low_level (L39-43): Structural note: Regression case: trips on low level. Read its setup and assertions to see the exact invariant.

- test_trips_on_high_level (L46-50): Structural note: Regression case: trips on high level. Read its setup and assertions to see the exact invariant.

- test_does_not_trip_just_below_each_limit (L53-58): Structural note: Regression case: does not trip just below each limit. Read its setup and assertions to see the exact invariant.

- test_trip_latches_even_after_values_recover (L63-69): Structural note: Regression case: trip latches even after values recover. Read its setup and assertions to see the exact invariant.

- test_latched_trip_ignores_a_second_different_excursion (L72-80): Structural note: Regression case: latched trip ignores a second different excursion. Read its setup and assertions to see the exact invariant.

- test_once_tripped_every_call_reports_tripped_regardless_of_values (L85-90): Structural note: Regression case: once tripped every call reports tripped regardless of values. Read its setup and assertions to see the exact invariant.

- test_reset_refused_while_still_outside_rearm_band (L95-102): Structural note: Regression case: reset refused while still outside rearm band. Read its setup and assertions to see the exact invariant.

- test_reset_refused_just_outside_rearm_band_on_level (L105-110): Structural note: Regression case: reset refused just outside rearm band on level. Read its setup and assertions to see the exact invariant.

- test_reset_succeeds_once_inside_rearm_band (L113-119): Structural note: Regression case: reset succeeds once inside rearm band. Read its setup and assertions to see the exact invariant.

- test_reset_on_untripped_interlock_is_a_noop (L122-126): Structural note: Regression case: reset on untripped interlock is a noop. Read its setup and assertions to see the exact invariant.

- test_can_trip_again_after_a_clean_reset (L129-135): Structural note: Regression case: can trip again after a clean reset. Read its setup and assertions to see the exact invariant.

- test_low_level_trip_closes_product_and_does_not_estop (L140-148): Structural note: Regression case: low level trip closes product and does not estop. Read its setup and assertions to see the exact invariant.

- test_pressure_and_high_level_trips_still_estop (L151-155): Structural note: Regression case: pressure and high level trips still estop. Read its setup and assertions to see the exact invariant.

- test_cause_latches_with_first_trip_and_clears_on_reset (L158-164): Structural note: Regression case: cause latches with first trip and clears on reset. Read its setup and assertions to see the exact invariant.

- test_invalid_reading_trips_with_sensor_fault (L173-177): Structural note: Regression case: invalid reading trips with sensor fault. Read its setup and assertions to see the exact invariant.

- test_cannot_rearm_on_invalid_reading (L180-185): Structural note: Regression case: cannot rearm on invalid reading. Read its setup and assertions to see the exact invariant.

- test_monitor_settling_grace_mutes_only_staleness (L188-209): Structural note: Regression case: monitor settling grace mutes only staleness. Read its setup and assertions to see the exact invariant.

- test_monitor_settling_grace_mutes_only_staleness.moving (L198-199): Structural note: Returns PlantState(**{**flat.__dict__, 'product_valve_pos': 47.03 + 6.0 * (i % 2)}).

- test_monitor_settling_grace_mutes_only_staleness.frozen_flags (L201-202): Structural note: Returns [f for i in range(n) for f in m.observe(moving(i), SupervisoryTargets()) if 'frozen' in f].

- test_flat_level_at_steady_state_is_not_frozen (L212-221): Structural note: Regression case: flat level at steady state is not frozen. Read its setup and assertions to see the exact invariant.

### tests/test_sequential_monitor.py

Fast tests for monitor/sequential_monitor.py, incl. the case BehaviorMonitor misses. Regression specification; the test names and assertions below identify the behaviors protected. Fakes/mocks isolate dependencies unless the file explicitly requires the live simulator.

Snapshot: 3,722 bytes; 78 lines.

Dependencies: from contracts import PlantState, SupervisoryTargets; from monitor.behavior_monitor import BehaviorMonitor; from monitor.sequential_monitor import SequentialMonitor.

- st (L9-12): Structural note: Returns PlantState(pressure=p, level=l, f1_flow=0, f2_flow=0, purge_flow=0, product_flow=100.0, a_in_purg....

- test_staircase_evades_behavior_monitor_but_not_sequential (L15-29): Structural note: Regression case: staircase evades behavior monitor but not sequential. Read its setup and assertions to see the exact invariant.

- test_benign_wiggle_stays_low (L32-38): Structural note: Regression case: benign wiggle stays low. Read its setup and assertions to see the exact invariant.

- test_same_setpoint_reissue_is_not_a_move (L41-45): Structural note: Regression case: same setpoint reissue is not a move. Read its setup and assertions to see the exact invariant.

- test_rationale_screen_flags_injection_language (L48-53): Structural note: Regression case: rationale screen flags injection language. Read its setup and assertions to see the exact invariant.

- test_keel_events_floor_the_score (L56-59): Structural note: Regression case: keel events floor the score. Read its setup and assertions to see the exact invariant.

- test_back_off_and_return_scores_net_displacement (L62-68): Structural note: Regression case: back off and return scores net displacement. Read its setup and assertions to see the exact invariant.

- test_reversal_does_not_hide_a_net_staircase (L71-78): Structural note: Regression case: reversal does not hide a net staircase. Read its setup and assertions to see the exact invariant.

### tests/test_sim_app_ai.py

Fast tests for sim_app/ai.py: command parsing (Ollama mocked) and the rescue regulator. Regression specification; the test names and assertions below identify the behaviors protected. Fakes/mocks isolate dependencies unless the file explicitly requires the live simulator.

Snapshot: 3,470 bytes; 72 lines.

Dependencies: import json; import pytest; from contracts import SupervisoryTargets; from sim_app.ai import DESIGN_VALVES, parse_command, plant_state, regulate.

- fake (L10-14): Structural note: Returns post; {'message': {'content': json.dumps(reply)}}.

- fake.post (L11-13): Structural note: Returns {'message': {'content': json.dumps(reply)}}.

- test_parse_command (L28-32): Structural note: Regression case: parse command. Read its setup and assertions to see the exact invariant.

- test_parse_command_bad_json_is_unknown (L35-37): Structural note: Regression case: parse command bad json is unknown. Read its setup and assertions to see the exact invariant.

- state (L40-42): Structural note: Returns plant_state(raw).

- test_regulator_high_pressure_opens_outlets_and_cuts_feeds (L45-50): Structural note: Regression case: regulator high pressure opens outlets and cuts feeds. Read its setup and assertions to see the exact invariant.

- test_regulator_at_design_point_returns_design_lineup (L53-56): Structural note: Regression case: regulator at design point returns design lineup. Read its setup and assertions to see the exact invariant.

- test_regulator_low_pressure_shuts_purge_and_raises_feeds (L59-62): Structural note: Regression case: regulator low pressure shuts purge and raises feeds. Read its setup and assertions to see the exact invariant.

- test_regulator_level_high_opens_product (L65-68): Structural note: Regression case: regulator level high opens product. Read its setup and assertions to see the exact invariant.

- test_regulator_hold_when_model_holds (L71-72): Structural note: Regression case: regulator hold when model holds. Read its setup and assertions to see the exact invariant.

### tests/test_sim_app_bugs.py

Regression tests for the sim_app bug fixes (no network, no plant: fakes only). Regression specification; the test names and assertions below identify the behaviors protected. Fakes/mocks isolate dependencies unless the file explicitly requires the live simulator.

Snapshot: 18,029 bytes; 426 lines.

Dependencies: import json; import threading; import time; import pytest; from fastapi import HTTPException; import sim_app.ai as ai; import sim_app.server as server; from contracts import SupervisoryTargets.

- FakeSim (L16-48): Source docstring: GrficsClient stand-in with the simulator's e_stop semantics (TE_process.cc): e_stop forces valves to 0/0/100/100, ignores valve setpoints while on, and the forced positions persist after release.

- FakeSim.__init__ (L21-23): Structural note: Updates self.v, (self.e_stop, self.pressure, self.fail_reads).

- FakeSim._raw (L25-28): Structural note: Returns {'outputs': {'pressure': self.pressure, 'liquid_level': 44.18}, 'measured': {'pressure': self.pre....

- FakeSim.read (L30-34): Structural note: Returns self._raw().

- FakeSim.write_inputs (L36-45): Structural note: Returns self._raw().

- FakeSim.close (L47-48): Structural note: Coordinates the statements shown in the source companion.

- make_plant (L51-55): Structural note: Returns p. Key operations: p.read.

- test_estop_release_steps_from_real_valve_positions (L60-66): Structural note: Regression case: estop release steps from real valve positions. Read its setup and assertions to see the exact invariant.

- test_valve_moves_refused_while_estop_on (L69-74): Structural note: Regression case: valve moves refused while estop on. Read its setup and assertions to see the exact invariant.

- test_setpoints_follow_external_writes (L77-81): Structural note: Regression case: setpoints follow external writes. Read its setup and assertions to see the exact invariant.

- test_second_concurrent_reset_is_refused (L86-107): Structural note: Regression case: second concurrent reset is refused. Read its setup and assertions to see the exact invariant.

- test_second_concurrent_reset_is_refused.Pt (L89-90): Structural note: Class (no explicit base class). Groups related methods/state.

- test_second_concurrent_reset_is_refused.slow_reset (L92-94): Structural note: Returns Pt().

- fake_llm (L112-113): Structural note: Returns lambda u, b, t: {'message': {'content': json.dumps(reply)}}.

- test_direction_check_only_when_unambiguous (L122-125): Structural note: Regression case: direction check only when unambiguous. Read its setup and assertions to see the exact invariant.

- FakeOp (L130-143): Source docstring: OllamaOperator stand-in: fixed targets, optional delay and failure outcome.

- FakeOp.__init__ (L134-135): Structural note: Updates (self.model, self.log).

- FakeOp.decide (L137-143): Structural note: Returns SupervisoryTargets(pressure_sp=2600.6, level_sp=44.18, production_rate_sp=70.0, a_comp_sp=47.0, r...; SupervisoryTargets(rationale='hold: model unavailable').

- RecPlant (L146-163): Source docstring: Rescue-facing plant fake that records which thread wrote valves.

- RecPlant.__init__ (L149-151): Structural note: Updates (self.sim, self.ruptured, self.resetting, self.writes), self.raw.

- RecPlant.read (L153-155): Structural note: Returns self.raw. Key operations: self.sim.read.

- RecPlant.write (L157-159): Structural note: Returns self.raw. Key operations: self.sim.write_inputs.

- RecPlant.apply_valves (L161-163): Structural note: Key operations: self.writes.append, self.sim.write_inputs, threading.current_thread.

- fast (L167-170): Structural note: Updates (FakeOp.delay, FakeOp.outcome).

- wait_until (L173-179): Structural note: Returns False; True.

- rescue_threads (L182-183): Structural note: Returns [t for t in threading.enumerate() if t.name.startswith('ai-rescue-') and t.is_alive()]. Key operations: threading.enumerate, t.name.startswith.

- test_quick_stop_then_save_leaves_one_loop (L188-201): Structural note: Regression case: quick stop then save leaves one loop. Read its setup and assertions to see the exact invariant.

- test_stop_during_decision_writes_nothing_after (L206-215): Structural note: Regression case: stop during decision writes nothing after. Read its setup and assertions to see the exact invariant.

- test_transient_read_failure_is_retried (L220-227): Structural note: Regression case: transient read failure is retried. Read its setup and assertions to see the exact invariant.

- test_persistent_read_failure_disengages_loudly (L230-236): Structural note: Regression case: persistent read failure disengages loudly. Read its setup and assertions to see the exact invariant.

- test_model_failures_disengage_after_three (L241-249): Structural note: Regression case: model failures disengage after three. Read its setup and assertions to see the exact invariant.

- test_low_pressure_boost_scales_with_deficit (L254-261): Structural note: Regression case: low pressure boost scales with deficit. Read its setup and assertions to see the exact invariant.

- test_design_purge_matches_te_steady_state_equations (L266-278): Source docstring: Re-derive the purge the simulator meant to set (TE_process.cc steady_state).

- test_regulator_keeps_design_purge_open_at_setpoint (L281-284): Structural note: Regression case: regulator keeps design purge open at setpoint. Read its setup and assertions to see the exact invariant.

- test_reset_applies_design_purge (L287-307): Structural note: Regression case: reset applies design purge. Read its setup and assertions to see the exact invariant.

- test_reset_applies_design_purge.Conn (L291-300): Structural note: Class (no explicit base class). Groups related methods/state.

- test_reset_applies_design_purge.Conn.__enter__ (L292-292): Structural note: Returns self.

- test_reset_applies_design_purge.Conn.__exit__ (L293-293): Structural note: Coordinates the statements shown in the source companion.

- test_reset_applies_design_purge.Conn.makefile (L294-300): Structural note: Returns F(); json.dumps({'state': {'purge_valve_pos': sent[-1]['data']['inputs']['purge_valve_sp']}}).encode().

- test_reset_applies_design_purge.Conn.makefile.F (L295-299): Structural note: Class (no explicit base class). Groups related methods/state.

- test_reset_applies_design_purge.Conn.makefile.F.write (L296-296): Structural note: Coordinates the statements shown in the source companion.

- test_reset_applies_design_purge.Conn.makefile.F.flush (L297-297): Structural note: Coordinates the statements shown in the source companion.

- test_reset_applies_design_purge.Conn.makefile.F.readline (L298-299): Structural note: Returns json.dumps({'state': {'purge_valve_pos': sent[-1]['data']['inputs']['purge_valve_sp']}}).encode().

- test_design_purge_retries_when_the_write_is_dropped (L310-332): Source docstring: Right after a restart the port proxy accepts and then drops the connection.

- test_design_purge_retries_when_the_write_is_dropped.Conn (L316-327): Structural note: Class (no explicit base class). Groups related methods/state.

- test_design_purge_retries_when_the_write_is_dropped.Conn.__enter__ (L317-317): Structural note: Returns self.

- test_design_purge_retries_when_the_write_is_dropped.Conn.__exit__ (L318-318): Structural note: Coordinates the statements shown in the source companion.

- test_design_purge_retries_when_the_write_is_dropped.Conn.makefile (L319-327): Structural note: Returns F(); r if r is not None else json.dumps({'state': {'purge_valve_pos': rp.DESIGN_PURGE_VALVE_PCT}}).enc.... Key operations: json.dumps({'state': {'purge_valve_pos': rp.DESIGN_PURGE_VALVE_PCT}}).encode.

- test_design_purge_retries_when_the_write_is_dropped.Conn.makefile.F (L320-326): Structural note: Class (no explicit base class). Groups related methods/state.

- test_design_purge_retries_when_the_write_is_dropped.Conn.makefile.F.write (L321-321): Structural note: Coordinates the statements shown in the source companion.

- test_design_purge_retries_when_the_write_is_dropped.Conn.makefile.F.flush (L322-322): Structural note: Coordinates the statements shown in the source companion.

- test_design_purge_retries_when_the_write_is_dropped.Conn.makefile.F.readline (L323-326): Structural note: Returns r if r is not None else json.dumps({'state': {'purge_valve_pos': rp.DESIGN_PURGE_VALVE_PCT}}).enc.... Key operations: json.dumps({'state': {'purge_valve_pos': rp.DESIGN_PURGE_VALVE_PCT}}).encode.

- fake_multi (L337-338): Structural note: Returns lambda u, b, t: {'message': {'content': json.dumps({'actions': actions})}}.

- test_parse_commands_splits_and_checks_each_clause (L341-349): Structural note: Regression case: parse commands splits and checks each clause. Read its setup and assertions to see the exact invariant.

- test_parse_commands_checks_against_the_real_segment_when_clause_is_paraphrased (L352-357): Structural note: Regression case: parse commands checks against the real segment when clause is paraphrased. Read its setup and assertions to see the exact invariant.

- test_parse_commands_bad_output_is_one_unknown (L360-362): Structural note: Regression case: parse commands bad output is one unknown. Read its setup and assertions to see the exact invariant.

- test_parse_commands_caps_the_number_of_actions (L365-367): Structural note: Regression case: parse commands caps the number of actions. Read its setup and assertions to see the exact invariant.

- _client (L370-377): Structural note: Returns (TestClient(server.app), plant).

- test_command_endpoint_applies_all_actions_in_order (L380-388): Structural note: Regression case: command endpoint applies all actions in order. Read its setup and assertions to see the exact invariant.

- test_command_endpoint_reports_partial_failure_and_keeps_going (L391-396): Structural note: Regression case: command endpoint reports partial failure and keeps going. Read its setup and assertions to see the exact invariant.

- test_command_endpoint_all_unknown_is_422 (L399-401): Structural note: Regression case: command endpoint all unknown is 422. Read its setup and assertions to see the exact invariant.

- test_command_endpoint_refused_actions_are_409 (L404-408): Structural note: Regression case: command endpoint refused actions are 409. Read its setup and assertions to see the exact invariant.

- test_shut_without_number_is_set_zero_and_fully_open_is_100 (L411-416): Structural note: Regression case: shut without number is set zero and fully open is 100. Read its setup and assertions to see the exact invariant.

- test_clause_naming_two_valves_gets_both (L419-426): Structural note: Regression case: clause naming two valves gets both. Read its setup and assertions to see the exact invariant.

### tests/test_telemetry_quality.py

Deployment policy, data leakage, and telemetry-only routing checks. Regression specification; the test names and assertions below identify the behaviors protected. Fakes/mocks isolate dependencies unless the file explicitly requires the live simulator.

Snapshot: 3,641 bytes; 82 lines.

Dependencies: import hashlib; import json; from pathlib import Path; import pytest; from monitor import observer_v3_format as V3; from monitor.observer import Observer; from monitor.telemetry_classifier import TelemetryClassifier, approved_specialist, features; from training.build_clean_observer_dataset import OUT, canonical.

- test_clean_observer_split_has_no_prompt_or_recording_overlap (L20-35): Structural note: Regression case: clean observer split has no prompt or recording overlap. Read its setup and assertions to see the exact invariant.

- test_specialist_never_suppresses_an_existing_alarm (L38-42): Structural note: Regression case: specialist never suppresses an existing alarm. Read its setup and assertions to see the exact invariant.

- test_specialist_uses_confident_faults_only (L45-52): Structural note: Regression case: specialist uses confident faults only. Read its setup and assertions to see the exact invariant.

- test_bad_windows_are_not_interpreted_as_normal (L55-59): Structural note: Regression case: bad windows are not interpreted as normal. Read its setup and assertions to see the exact invariant.

- test_specialist_verdict_never_reaches_proposal_suspicion (L62-72): Structural note: Regression case: specialist verdict never reaches proposal suspicion. Read its setup and assertions to see the exact invariant.

- test_specialist_verdict_never_reaches_proposal_suspicion.Specialist (L63-65): Structural note: Class (no explicit base class). Groups related methods/state.

- test_specialist_verdict_never_reaches_proposal_suspicion.Specialist.correct (L64-65): Structural note: Returns {'source': 'llm+telemetry-specialist', 'label': 'sensor_fault', 'score': 0.9, 'reason': 'r'}.

- test_shipped_specialist_matches_approved_model_digest (L75-82): Structural note: Regression case: shipped specialist matches approved model digest. Read its setup and assertions to see the exact invariant.

### tests/test_workspace_review.py

Regression checks for the workspace review's input and session fixes. Regression specification; the test names and assertions below identify the behaviors protected. Fakes/mocks isolate dependencies unless the file explicitly requires the live simulator.

Snapshot: 1,460 bytes; 39 lines.

Dependencies: import math; import pytest; from pydantic import ValidationError; from live.engine import Engine; from sim_app.server import Manipulation.

- test_nonfinite_authority_does_not_change_operator_cap (L12-17): Structural note: Regression case: nonfinite authority does not change operator cap. Read its setup and assertions to see the exact invariant.

- test_nonfinite_manual_move_is_rejected (L22-24): Structural note: Regression case: nonfinite manual move is rejected. Read its setup and assertions to see the exact invariant.

- test_run_identity_is_stable_for_polling_and_changes_after_restart (L27-30): Structural note: Regression case: run identity is stable for polling and changes after restart. Read its setup and assertions to see the exact invariant.

- test_connection_failure_overrides_last_healthy_snapshot (L33-39): Structural note: Regression case: connection failure overrides last healthy snapshot. Read its setup and assertions to see the exact invariant.

### training/__init__.py

Package initializer. Establishes the import namespace; inspect any exports below. An empty initializer contains no control logic.

Snapshot: 0 bytes; 0 lines.

### training/benchmark_command_parser.py

Non-actuating authored-command benchmark comparing exact ordered action/valve/amount tuples from real parser inference.

Snapshot: 5,173 bytes; 88 lines.

Dependencies: import json; from collections import Counter; from pathlib import Path; from sim_app.ai import PARSER_MODEL, parse_commands.

- action (L13-14): Structural note: Returns [kind, valve, amount].

- normalized (L51-53): Structural note: Returns [action(x.get('action'), x.get('valve') if x.get('action') in ('set', 'adjust') else None, x.get(....

- main (L56-84): Structural note: Key operations: path.write_text.

### training/benchmark_observer.py

Fresh balanced held-out observer/specialist replay with response/model/input-hash recording.

Snapshot: 4,582 bytes; 91 lines.

Dependencies: import argparse; import hashlib; import json; import random; import time; import urllib.request; from collections import Counter, defaultdict; from pathlib import Path; from monitor import observer_v3_format as F; from monitor.telemetry_classifier import approved_specialist; from training.build_clean_observer_dataset import OUT.

- summarize (L23-34): Structural note: Returns {'n': len(rows), 'valid_output_rate': sum((r[field] is not None for r in rows)) / len(rows), 'acc....

- run (L37-81): Structural note: Key operations: source.read_text(encoding='utf-8').splitlines, hashlib.sha256(source.read_bytes()).hexdigest, urllib.request.Request, destination.write_text, source.read_text, urllib.request.urlopen, json.dumps({'model': 'scram-observer-v3', 'messages': messages[:2], 'format': 'json', 'stream': False, 'keep_alive': '30m', 'options': {'temperature': 0, 'num_ctx': 3072, 'num_predict': 120}}).encode, source.read_bytes, response.read.

### training/benchmark_physics_pair.py

Non-actuating paired old/new telemetry-pipeline replay on the same frozen final holdout.

Snapshot: 2,448 bytes; 69 lines.

Dependencies: import json; import urllib.request; from pathlib import Path; from monitor import observer_v3_format as V3; from monitor.physics_detector import DEST, PhysicsDetector; from monitor.telemetry_classifier import DEFAULT_MODEL, TelemetryClassifier; from training.train_physics_telemetry import evaluate.

- main (L13-65): Structural note: Key operations: Path('artifacts/accuracy-v2/paired-final.json').write_text, urllib.request.Request, Path('artifacts/accuracy-v2/paired-progress.json').write_text, evaluate, Path('artifacts/accuracy-v2/telemetry-final-holdout.jsonl').read_text().splitlines, urllib.request.urlopen, new.predict, Path('artifacts/accuracy-v2/telemetry-final-holdout.jsonl').read_text.

### training/build_clean_observer_dataset.py

Stronger whole-recording split and exact-prompt deduplication, with a reproducible clean-dataset manifest.

Snapshot: 6,795 bytes; 146 lines.

Dependencies: import argparse; import hashlib; import json; import random; from collections import Counter, defaultdict; from pathlib import Path; from monitor import observer_v3_format as F; from training import build_observer_dataset as B.

- canonical (L22-23): Structural note: Returns json.dumps(json.loads(user), sort_keys=True, separators=(',', ':')).

- build (L26-138): Structural note: Returns manifest. Key operations: (out_dir / 'manifest.json').write_text, file.write_text.

### training/build_dataset.py

Operator chat dataset builder: expert labels, duplicate removal, block-based splits, minority-rule balance and prompt-format checks.

Snapshot: 8,348 bytes; 181 lines.

Dependencies: import argparse; import json; import random; from collections import Counter, defaultdict; from pathlib import Path; from l0_plant.safety import TripLimits; from l3_brain.policy import SYSTEM_PROMPT, Envelope, parse_llm_targets; from l3_brain.prompt_format import state_to_json, system_prompt; from training.expert_policy import expert, load_design_point.

- rule_of (L45-59): Structural note: Returns '+'.join(tags) or 'other'; 'hold:tripped'; 'hold:bad_reading'; 'design_targets'. Key operations: rationale.startswith.

- histogram (L62-81): Structural note: Updates w, counts, under, peak.

- main (L84-177): Structural note: Returns 0; (out, len(design_recs)). Key operations: load_design_point, STATES.open, (HERE / f'{split}.jsonl').open, f.write, p.open.

- main.balance (L127-135): Structural note: Returns (out, len(design_recs)).

### training/build_observer_dataset.py

v3 observer dataset builder: preserves v2 proposals, creates command-aware telemetry windows, labels recorded/synthetic faults and reserves scenario holdouts.

Snapshot: 19,820 bytes; 391 lines.

Dependencies: import argparse; import json; import random; import sys; from collections import Counter, defaultdict; from pathlib import Path; from typing import Dict, List, Optional, Tuple; from monitor import observer_v3_format as F.

- load_rollouts (L91-98): Structural note: Returns dict(out). Key operations: path.open.

- windows (L101-103): Structural note: Coordinates the statements shown in the source companion.

- _sub (L106-108): Source docstring: 2 Hz records -> WINDOW_N samples at SAMPLE_S spacing.

- _cmd_of (L111-115): Source docstring: L1's commanded valves (recorded), or - where the recording predates that - the actual positions, which is what L1 commanded in normal operation.

- _slope (L118-121): Structural note: Returns sum(((i - tm) * (x - mean) for i, x in enumerate(xs))) / (sum(((i - tm) ** 2 for i in range(n))) ....

- tel (L124-125): Structural note: Returns (label, 'telemetry', F.telemetry_to_json(meas, cmd, window_s), F.verdict_to_json(label, score, re....

- _win (L128-130): Structural note: Returns ([r['measured'] for r in s], [_cmd_of(r) for r in s], s[-1]['t'] - s[0]['t']).

- reason_normal (L134-138): Structural note: Returns f'Readings are consistent with normal operation: pressure {p[-1]:.0f} kPa (range {max(p) - min(p)....

- reason_sensor (L141-153): Structural note: Returns f"{name} jumps {('up' if d > 0 else 'down')} by {abs(d):.{nd}f} with no matching change in the va...; f'{name} reading is stuck at {xs[-1]:.{nd}f} for {fault_s:.0f} s while the process keeps moving.'; f'{name} drops to 0 in {sum((x == 0 for x in xs))} of {len(xs)} sampl.

- reason_actuator (L156-159): Structural note: Returns f'{v.capitalize()} valve is commanded to {cmd[-1]:.1f}% but sits at {act[-1]:.1f}% (gap up to {ga....

- reason_capacity (L162-163): Structural note: Returns f'{v.capitalize()} valve follows its command but its flow is low for that opening; valve capacity....

- recorded_telemetry (L167-234): Structural note: Returns (pools, base).

- _scale (L238-239): Structural note: Returns {'pressure': 40.0, 'level': 0.8, 'a_in_purge': 0.01}.get(ch, 0.08 * max(sum(xs) / len(xs), 1.0)).

- synth_sensor (L242-271): Structural note: Returns tel('sensor_fault', min(0.95, score), reason_sensor(ch, mode, ys, (n - onset) * F.SAMPLE_S), out,...; None.

- synth_actuator (L274-296): Structural note: Returns tel('actuator_fault', min(0.95, 0.4 + 0.015 * gap), reason_actuator(v, cmd, act), meas, full, ws); None.

- synthesized_telemetry (L299-320): Structural note: Returns pools.

- v2_proposals (L324-330): Structural note: Returns out. Key operations: (v2_dir / f'observer_{split}.jsonl').open.

- build (L334-375): Structural note: Returns report. Key operations: (out_dir / f'observer_v3_{name}.jsonl').open, f.write.

- main (L378-387): Structural note: Returns 0.

### training/collect_observer_states.py

Collects native sensor/actuator faults with the issued command paired to each measured state. Completed rollouts are appended from temporary files.

Snapshot: 6,359 bytes; 148 lines.

Dependencies: import argparse; import json; import sys; import time; from pathlib import Path; from contracts import SupervisoryTargets; from l0_plant import fault_injection as fi; from l0_plant.plant_service import PlantService; from l1_stub import L1ControlStub; from l3_brain.prompt_format import measured_dict; from scripts.reset_plant import reset_and_settle.

- _sensor (L52-54): Structural note: Returns dict(name=f'{ch}_{mode.name.lower()}', kind='sensor_fault', channel=ch, mode=mode.name.lower(), i....

- _actuator (L57-59): Structural note: Returns dict(name=f'{valve}_{how}', kind='actuator_fault', channel=valve, mode=how, inputs=inputs).

- done_rollouts (L75-78): Structural note: Returns {json.loads(line)['rollout'] for line in OUT.open() if line.strip()}; set(). Key operations: OUT.open.

- run_rollout (L81-125): Structural note: Returns n. Key operations: svc.client.write_inputs, TMP.open, OUT.open, reset_and_settle, PlantService().start, svc.read, l1.regulate, svc.apply, dst.write.

- main (L128-144): Structural note: Returns 0.

### training/collect_states.py

Real simulator rollout collection at 2 Hz with measured observations, separate evaluation truth and design-point capture. Resets/writes the plant.

Snapshot: 12,570 bytes; 246 lines.

Dependencies: import argparse; import json; import sys; import time; from pathlib import Path; from contracts import ControlCommand, SupervisoryTargets; from l0_plant import fault_injection as fi; from l0_plant.plant_service import PlantService; from l1_stub import L1ControlStub; from l3_brain.prompt_format import measured_dict; from scripts.reset_plant import reset_and_settle; from training.expert_policy import DESIGN_POINT_PATH, expert, load_design_point.

- _ExpertBrain (L108-114): Structural note: Class (no explicit base class). Groups related methods/state.

- _ExpertBrain.__init__ (L109-110): Structural note: Updates self.design.

- _ExpertBrain.__call__ (L112-114): Structural note: Returns SupervisoryTargets(authority=1.0, rationale=why, **sp).

- write_design_point (L117-129): Structural note: Returns d. Key operations: reset_and_settle, PlantService().start, svc.client.read, DESIGN_POINT_PATH.write_text.

- done_rollouts (L132-139): Structural note: Returns names; set(). Key operations: STATES.open.

- run_rollout (L142-214): Structural note: Returns n. Key operations: TMP.open, STATES.open, reset_and_settle, PlantService().start, svc.read, svc.apply, dst.write, svc.client.write_inputs, svc.reset_interlock.

- main (L217-242): Structural note: Returns 0. Key operations: load_design_point, DESIGN_POINT_PATH.exists, write_design_point, STATES.open.

### training/design_point.json

Saved settled process targets and valve lineup. The stored purge observation is corrected by reset_plant.py/live startup for the development image bug.

Snapshot: 257 bytes; 13 lines.

Data structure: pressure, level, production, a_comp_pct, valves, source.

### training/eval_ollama.py

Evaluates deployed quantized operator models on held-out states and probes, using parser acceptance, hold correctness and setpoint error.

Snapshot: 6,360 bytes; 147 lines.

Dependencies: import argparse; import json; import time; import urllib.request; from collections import defaultdict; from pathlib import Path; from l3_brain.policy import parse_llm_targets; from l3_brain.prompt_format import state_to_json, system_prompt; from training.build_dataset import rule_of; from training.expert_policy import expert.

- ask (L40-47): Structural note: Returns json.loads(r.read())['message']['content']. Key operations: json.dumps({'model': model, 'stream': False, 'messages': [{'role': 'system', 'content': system_prompt()}, {'role': 'user', 'content': user}], 'options': {'temperature': 0, 'num_predict': 160}}).encode, urllib.request.Request, urllib.request.urlopen, r.read.

- score (L50-92): Source docstring: cases: list of (name, user_json, gold_dict).

- val_cases (L95-101): Structural note: Returns out[:limit] if limit else out. Key operations: VAL.open.

- probe_cases (L104-124): Source docstring: Real nominal val state, with the safety-relevant fields overridden.

- probe_cases.add (L110-113): Structural note: Updates s, (sp, why).

- main (L127-143): Structural note: Returns 0. Key operations: OUT.write_text.

### training/evaluate_physics_holdout.py

Frozen-candidate independent evaluation and predeclared release gate. Writes evidence, so rerunning is distinct from reading a report.

Snapshot: 4,072 bytes; 114 lines.

Dependencies: import argparse; import hashlib; import json; from collections import Counter; from pathlib import Path; from monitor.telemetry_classifier import TelemetryClassifier; from training.train_physics_telemetry import DEST, evaluate.

- main (L30-105): Structural note: Key operations: hashlib.sha256(model.read_bytes()).hexdigest, evaluate, output.write_text, (DEST / 'validation.json').read_text, hashlib.sha256((ROOT / 'monitor/physics_features.py').read_bytes()).hexdigest, hashlib.sha256((DEST / 'validation.json').read_bytes()).hexdigest, frozen.write_text, path.with_suffix('.manifest.json').read_text, hashlib.sha256(path.read_bytes()).hexdigest.

### training/evaluate_telemetry_specialist.py

Evaluates the older conservative correction policy using validation and historical replay; not fresh LLM inference.

Snapshot: 5,295 bytes; 97 lines.

Dependencies: import hashlib; import json; import math; import time; from monitor.telemetry_classifier import TelemetryClassifier; from training.build_clean_observer_dataset import OUT; from training.train_telemetry_classifier import DEST, HISTORICAL, ROOT, load, metrics.

- below_sensor_noise_floor (L16-41): Source docstring: Reject small drift/noise claims, never dropouts, freezes or physical excursions. The fixed 0.5% window effect-size floor is validated on labeled held-out sensor examples before activation. This is not a safety permissive.

- main (L44-93): Structural note: Key operations: (OUT / 'observer_v3_val.jsonl').read_text(encoding='utf-8').splitlines, (DEST / 'policy.json').write_text, (DEST / 'hybrid-evaluation.json').write_text, hashlib.sha256((DEST / 'model.json').read_bytes()).hexdigest, (ROOT / 'model/scram-observer-v3-gguf/eval_observer_test_unseen.json').read_text, hashlib.sha256(HISTORICAL.read_bytes()).hexdigest, (OUT / 'observer_v3_val.jsonl').read_text, (DEST / 'model.json').read_bytes, HISTORICAL.read_bytes.

### training/expert_policy.py

Rule-based teacher for operator imitation learning, grounded in saved design targets and production safety thresholds. Emits targets/rationale from measured state.

Snapshot: 5,758 bytes; 116 lines.

Dependencies: import json; import math; from pathlib import Path; from typing import Optional, Tuple; from l0_plant.safety import TripLimits.

- load_design_point (L45-50): Structural note: Returns json.loads(path.read_text()). Key operations: path.read_text.

- _get (L53-54): Structural note: Returns float(state[key] if isinstance(state, dict) else getattr(state, key)).

- _ramp (L57-61): Source docstring: 0 at `start`, 1 at `full` (either direction), clipped to [0, 1].

- expert (L64-116): Structural note: Returns (sp, text[0].upper() + text[1:] + '.'); (hold, 'Interlock tripped; holding all setpoints until the SIS re-arms.'); (hold, 'Pressure or level reading implausible (sensor dropout); holding setpoints.'); (sp, f'In band (P {p:.0f} kPa, L {lv:.1f}%); holding design targets.'. Key operations: load_design_point.

### training/observer_clean/manifest.json

Reproducibility/cleanup manifest: records file identity, split/collection provenance or prior housekeeping actions. It is evidence, not runtime code.

Snapshot: 2,468 bytes; 89 lines.

Data structure: version, seed, strategy, conflicting_users_excluded, duplicate_candidates_skipped, unique_pool_shortfalls, splits, cross_split_user_overlap.

### training/observer_clean/observer_v3_train.jsonl

Line-delimited chat dataset: system instructions, measured user input and labeled assistant response. Directory/name identifies train, validation or held-out split; one line is one example.

Snapshot: 13,699,193 bytes; 3,273 lines.

Data structure: messages. Records: 3,273.

### training/observer_clean/observer_v3_unseen.jsonl

Line-delimited chat dataset: system instructions, measured user input and labeled assistant response. Directory/name identifies train, validation or held-out split; one line is one example.

Snapshot: 2,134,017 bytes; 471 lines.

Data structure: messages. Records: 471.

### training/observer_clean/observer_v3_val.jsonl

Line-delimited chat dataset: system instructions, measured user input and labeled assistant response. Directory/name identifies train, validation or held-out split; one line is one example.

Snapshot: 4,448,556 bytes; 1,094 lines.

Data structure: messages. Records: 1,094.

### training/observer_states.jsonl

Recorded simulator observations/rollouts. Evaluation truth and command provenance are distinct from measured model inputs.

Snapshot: 2,107,058 bytes; 3,504 lines.

Data structure: rollout, kind, channel, mode, fault_active, t, measured, commanded, truth_eval_only. Records: 3,504.

### training/observer_v2/observer_train.jsonl

Line-delimited chat dataset: system instructions, measured user input and labeled assistant response. Directory/name identifies train, validation or held-out split; one line is one example.

Snapshot: 11,600,175 bytes; 3,924 lines.

Data structure: messages. Records: 3,924.

### training/observer_v2/observer_val.jsonl

Line-delimited chat dataset: system instructions, measured user input and labeled assistant response. Directory/name identifies train, validation or held-out split; one line is one example.

Snapshot: 3,872,069 bytes; 1,261 lines.

Data structure: messages. Records: 1,261.

### training/observer_v3_train.jsonl

Line-delimited chat dataset: system instructions, measured user input and labeled assistant response. Directory/name identifies train, validation or held-out split; one line is one example.

Snapshot: 14,473,587 bytes; 3,448 lines.

Data structure: messages. Records: 3,448.

### training/observer_v3_unseen.jsonl

Line-delimited chat dataset: system instructions, measured user input and labeled assistant response. Directory/name identifies train, validation or held-out split; one line is one example.

Snapshot: 2,169,737 bytes; 480 lines.

Data structure: messages. Records: 480.

### training/observer_v3_val.jsonl

Line-delimited chat dataset: system instructions, measured user input and labeled assistant response. Directory/name identifies train, validation or held-out split; one line is one example.

Snapshot: 4,919,500 bytes; 1,203 lines.

Data structure: messages. Records: 1,203.

### training/scram_observer_finetune.ipynb

Observer notebook: environment setup, clean dataset/format checks, training, evaluation and candidate export. Code cells are preserved in source order in the companion.

Snapshot: 17,687 bytes; 388 lines.

Data structure: cells, metadata, nbformat, nbformat_minor.

### training/states.jsonl

Recorded simulator observations/rollouts. Evaluation truth and command provenance are distinct from measured model inputs.

Snapshot: 2,656,469 bytes; 5,868 lines.

Data structure: rollout, phase, t, measured, truth_eval_only. Records: 5,868.

### training/train.jsonl

Line-delimited chat dataset: system instructions, measured user input and labeled assistant response. Directory/name identifies train, validation or held-out split; one line is one example.

Snapshot: 3,383,689 bytes; 2,190 lines.

Data structure: messages. Records: 2,190.

### training/train_local.py

Local operator QLoRA training, validation and GGUF export stages; uses Unsloth/TRL and llama.cpp tools under .tools.

Snapshot: 13,543 bytes; 299 lines.

Dependencies: import argparse; import json; import math; import re; import subprocess; import sys; import time; from collections import Counter, defaultdict; from pathlib import Path; from l3_brain.policy import parse_llm_targets; from l3_brain.prompt_format import state_to_json, system_prompt.

- load_examples (L62-73): Source docstring: Read a split and enforce train == serve against l3_brain/prompt_format.

- load_model (L76-83): Structural note: Returns (model, tok).

- train (L88-157): Structural note: Returns Dataset.from_dict({'text': texts}). Key operations: trainer.evaluate, model.save_pretrained, tok.save_pretrained, (MODEL_DIR / 'train_log.json').write_text, tok.apply_chat_template.

- train.to_ds (L103-105): Structural note: Returns Dataset.from_dict({'text': texts}). Key operations: tok.apply_chat_template.

- train.LogCB (L114-118): Structural note: Class (TrainerCallback). Groups related methods/state.

- train.LogCB.on_log (L115-118): Structural note: Coordinates the statements shown in the source companion.

- rule_of (L162-164): Structural note: Returns r(rationale).

- evaluate (L167-242): Structural note: Key operations: (MODEL_DIR / 'eval_val.json').write_text, tok.apply_chat_template.

- export (L247-275): Structural note: Key operations: model.save_pretrained_merged, (GGUF_DIR / 'Modelfile').write_text.

- main (L278-295): Structural note: Returns 0. Key operations: evaluate.

### training/train_physics_telemetry.py

Fits/selects physics-feature forests on training/validation, exports dependency-free JSON arrays and checks runtime prediction parity.

Snapshot: 6,290 bytes; 166 lines.

Dependencies: import hashlib; import json; from pathlib import Path; import numpy as np; from sklearn.ensemble import ExtraTreesClassifier, RandomForestClassifier; from monitor.physics_features import VERSION, physics_features; from monitor.telemetry_classifier import TelemetryClassifier; from training import build_observer_dataset as B; from training.build_clean_observer_dataset import OUT, canonical; from training.train_telemetry_classifier import HISTORICAL, load.

- evaluate (L23-36): Structural note: Returns {'n': len(gold), 'accuracy': sum((g == p for g, p in zip(gold, predicted))) / len(gold), 'per_cla....

- main (L39-162): Structural note: Key operations: file.write_text, (DEST / 'validation.json').write_text, (OUT / 'manifest.json').read_text, model.predict(xv).tolist, hashlib.sha256(file.read_bytes()).hexdigest, model.fit, model.predict_proba, evaluate, runtime.predict.

### training/train_telemetry_classifier.py

Earlier CPU statistical-feature forest training/export and comparison against recorded LLM predictions.

Snapshot: 5,037 bytes; 95 lines.

Dependencies: import hashlib; import json; import time; from collections import Counter; from pathlib import Path; import numpy as np; from sklearn.ensemble import ExtraTreesClassifier; from monitor.telemetry_classifier import FEATURE_VERSION, TelemetryClassifier, features; from training.build_clean_observer_dataset import OUT, canonical.

- load (L25-32): Structural note: Returns rows. Key operations: path.read_text(encoding='utf-8').splitlines, path.read_text.

- metrics (L35-49): Structural note: Returns {'n': len(rows), 'accuracy': sum((confusion[k][k] for k in confusion)) / len(rows), 'per_class_re.... Key operations: predict.

- main (L52-91): Structural note: Key operations: model.fit, path.write_text, (DEST / 'evaluation.json').write_text, hashlib.sha256((OUT / 'manifest.json').read_bytes()).hexdigest, model.predict(np.array([features(row[0]) for row in splits['val']], dtype=np.float32)).tolist, (ROOT / 'model/scram-observer-v3-gguf/eval_observer_test_unseen.json').read_text, runtime.predict, model.predict, (OUT / 'manifest.json').read_bytes.

### training/val.jsonl

Line-delimited chat dataset: system instructions, measured user input and labeled assistant response. Directory/name identifies train, validation or held-out split; one line is one example.

Snapshot: 363,420 bytes; 235 lines.

Data structure: messages. Records: 235.


## 20. Local workspace and document coverage

The following counts describe on-disk folders, including ignored local material. Dependency/tool/Git internals are counted but not reproduced as SCRAM code. This generated documentation directory is excluded.

- (root files): 27 files; 151,464 bytes.

- .git: 638 files; 43,089,198 bytes.

- .github: 4 files; 2,913 bytes.

- .local-only: 4 files; 172,035,428 bytes.

- .tools: 4,181 files; 234,203,074 bytes.

- .venv-train: 44,527 files; 5,522,690,706 bytes.

- artifacts: 34 files; 2,026,052 bytes.

- docker: 1 files; 565 bytes.

- enforcer: 3 files; 21,338 bytes.

- experiments: 31 files; 1,954,746 bytes.

- images: 10 files; 4,516,148 bytes.

- l0_plant: 8 files; 42,185 bytes.

- l3_brain: 6 files; 29,570 bytes.

- live: 12 files; 229,600 bytes.

- model: 36 files; 3,093,736,665 bytes.

- monitor: 12 files; 79,075 bytes.

- observer_merged_v2: 13 files; 87,210,702 bytes.

- packaging: 10 files; 7,275 bytes.

- reference: 5 files; 38,662 bytes.

- scripts: 6 files; 27,845 bytes.

- sim_app: 11 files; 114,344 bytes.

- simulation: 44 files; 28,352,805 bytes.

- tests: 22 files; 142,324 bytes.

- training: 31 files; 65,960,332 bytes.

The .venv-train directory is an installed training environment; .tools contains third-party llama.cpp tooling; .git contains version history/index/objects. observer_merged_v2 and ignored GGUF/adapter files are preserved local model artifacts. .local-only holds local release material. Generated logs/binaries under artifacts are outputs rather than additional application source. workspace-summary.json lists nontracked paths outside dependency/Git internals and records any scan errors.

Source commit identity: 257e8b6528a7fb9d8fdcfa73ff3e132b1e28f8f3. The inventory hashes describe actual working-tree bytes; a commit ID alone does not imply an unchanged working tree. No application source, model evidence or dataset was modified to generate these documents.
